<?php
// config.php
$host = 'localhost';
$dbname = 'espace_membre';
$username = 'root';
$password = ''; // Mot de passe vide par défaut sur XAMPP

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    echo "Connexion réussie à la base de données!";
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>