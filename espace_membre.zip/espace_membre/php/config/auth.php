<?php
// Active l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// auth.php - Système d'authentification simple
session_start();

// Configuration DB
$host = 'localhost';
$dbname = 'espace_membre';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur DB: " . $e->getMessage());
}

// Fonctions utilitaires
function redirect($url) {
    header("Location: $url");
    exit();
}

function sanitize($data) {
    return htmlspecialchars(trim($data));
}

// Gestion des actions
$action = $_GET['action'] ?? '';

switch($action) {
    case 'login':
        handleLogin();
        break;
    case 'register':
        handleRegister();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'show_register':
        displayRegisterForm();
        break;
    default:
        displayLoginPage();
}

// ==================== INSCRIPTION ====================
function handleRegister() {
    global $pdo;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $_SESSION['error'] = "Méthode non autorisée";
        redirect('auth.php?action=show_register');
    }
    
    // Récupération des données
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = sanitize($_POST['role'] ?? 'membre'); // 'admin' ou 'membre'
    
    // Validation
    $errors = [];
    
    if (strlen($username) < 3) {
        $errors[] = "Nom d'utilisateur trop court (min 3 caractères)";
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email invalide";
    }
    
    if (strlen($password) < 6) {
        $errors[] = "Mot de passe trop court (min 6 caractères)";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Les mots de passe ne correspondent pas";
    }
    
    if (!in_array($role, ['admin', 'membre'])) {
        $role = 'membre';
    }
    
    // Vérifier si utilisateur existe déjà
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        $errors[] = "Nom d'utilisateur ou email déjà utilisé";
    }
    
    // Si erreurs, afficher formulaire avec erreurs
    if (!empty($errors)) {
        displayRegisterForm(implode("<br>", $errors), $_POST);
        return;
    }
    
    // Hasher le mot de passe
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insérer l'utilisateur
    try {
        // Vérifier la structure de la table
        $stmt = $pdo->query("DESCRIBE users");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Construction de la requête dynamique
        if (in_array('role', $columns)) {
            // Si la colonne 'role' existe
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password, role, created_at, is_active) 
                VALUES (?, ?, ?, ?, NOW(), '1')
            ");
            $stmt->execute([$username, $email, $hashed_password, $role]);
        } else {
            // Si pas de colonne 'role', utiliser une valeur par défaut
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password, created_at, is_active) 
                VALUES (?, ?, ?, NOW(), '1')
            ");
            $stmt->execute([$username, $email, $hashed_password]);
            $role = 'membre'; // Valeur par défaut
        }
        
        $user_id = $pdo->lastInsertId();
        
        // Créer la session
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['role'] = $role;
        $_SESSION['is_active'] = '1'; // Stocker le statut en session
        
        // Message de succès
        $_SESSION['success'] = "Inscription réussie ! Bienvenue $username !";
        
        // Rediriger selon le rôle
        redirectUserByRole($role);
        
    } catch(PDOException $e) {
        displayRegisterForm("Erreur lors de l'inscription: " . $e->getMessage(), $_POST);
    }
}

// ==================== CONNEXION ====================
function handleLogin() {
    global $pdo;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $_SESSION['error'] = "Méthode non autorisée";
        redirect('auth.php');
    }
    
    $username_email = sanitize($_POST['username_email']);
    $password = $_POST['password'];
    
    try {
        // Vérifier la structure de la table
        $stmt = $pdo->query("DESCRIBE users");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Construire la requête dynamiquement
        $select_fields = "id, username, email, password";
        if (in_array('role', $columns)) {
            $select_fields .= ", role";
        }
        if (in_array('is_active', $columns)) {
            $select_fields .= ", is_active";
        }
        
        $sql = "SELECT $select_fields FROM users WHERE (username = ? OR email = ?)";
        
        // Ajouter la condition is_active si la colonne existe (ENUM donc chaîne '1')
        if (in_array('is_active', $columns)) {
            $sql .= " AND is_active = '1'";
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$username_email, $username_email]);
        $user = $stmt->fetch();
        
        // Vérifier le mot de passe
        if ($user && password_verify($password, $user['password'])) {
            // Vérifier si le compte est actif
            if (isset($user['is_active']) && $user['is_active'] !== '1') {
                $_SESSION['error'] = "Votre compte a été désactivé.";
                redirect('auth.php');
            }
            
            // Créer la session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'] ?? 'membre';
            $_SESSION['is_active'] = $user['is_active'] ?? '1';
            
            // Message de succès
            $_SESSION['success'] = "Connexion réussie ! Bienvenue " . $user['username'] . " !";
            
            // Rediriger selon le rôle
            redirectUserByRole($_SESSION['role']);
        } else {
            // Vérifier si l'utilisateur existe mais est désactivé
            $stmt = $pdo->prepare("
                SELECT id FROM users 
                WHERE (username = ? OR email = ?) 
                AND is_active = '0'
            ");
            $stmt->execute([$username_email, $username_email]);
            
            if ($stmt->fetch()) {
                $_SESSION['error'] = "Compte désactivé. Contactez l'administrateur.";
            } else {
                $_SESSION['error'] = "Identifiants incorrects";
            }
            
            redirect('auth.php');
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "Erreur technique: " . $e->getMessage();
        redirect('auth.php');
    }
}

// ==================== DÉCONNEXION ====================
function handleLogout() {
    session_destroy();
    $_SESSION['success'] = "Déconnexion réussie";
    redirect('auth.php');
}

// ==================== REDIRECTION PAR RÔLE ====================
function redirectUserByRole($role) {
    switch($role) {
        case 'admin':
            redirect('../admin/dashboard.php');
            break;
        case 'membre':
            redirect('../membres/dashboard.php');
            break;
        default:
            redirect('index.php');
    }
}

// ==================== PAGES D'AFFICHAGE ====================

function displayLoginPage() {
    $error = $_SESSION['error'] ?? '';
    $success = $_SESSION['success'] ?? '';
    
    // Nettoyer les messages de session
    unset($_SESSION['error']);
    unset($_SESSION['success']);
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Connexion - Réseau Social</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: Arial, sans-serif;
            }
            
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            
            .container {
                display: flex;
                max-width: 1000px;
                width: 100%;
                background: white;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            }
            
            .left-panel {
                flex: 1;
                background: linear-gradient(135deg, #4a00e0 0%, #8e2de2 100%);
                color: white;
                padding: 50px;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }
            
            .right-panel {
                flex: 1;
                padding: 50px;
            }
            
            .logo {
                font-size: 2.5em;
                font-weight: bold;
                margin-bottom: 20px;
            }
            
            .tagline {
                font-size: 1.2em;
                opacity: 0.9;
                line-height: 1.6;
            }
            
            .form-title {
                font-size: 2em;
                color: #333;
                margin-bottom: 30px;
            }
            
            .form-group {
                margin-bottom: 20px;
            }
            
            label {
                display: block;
                margin-bottom: 5px;
                color: #555;
                font-weight: bold;
            }
            
            input[type="text"],
            input[type="email"],
            input[type="password"] {
                width: 100%;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                transition: border 0.3s;
            }
            
            input:focus {
                outline: none;
                border-color: #4a00e0;
            }
            
            .btn {
                display: block;
                width: 100%;
                padding: 14px;
                background: #4a00e0;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                font-weight: bold;
                cursor: pointer;
                transition: background 0.3s;
                text-align: center;
                text-decoration: none;
            }
            
            .btn:hover {
                background: #8e2de2;
            }
            
            .switch-form {
                text-align: center;
                margin-top: 20px;
                color: #666;
            }
            
            .switch-form a {
                color: #4a00e0;
                text-decoration: none;
                font-weight: bold;
            }
            
            .switch-form a:hover {
                text-decoration: underline;
            }
            
            .error {
                background: #ffebee;
                color: #c62828;
                padding: 10px;
                border-radius: 5px;
                margin-bottom: 20px;
                border: 1px solid #ffcdd2;
            }
            
            .success {
                background: #e8f5e9;
                color: #2e7d32;
                padding: 10px;
                border-radius: 5px;
                margin-bottom: 20px;
                border: 1px solid #c8e6c9;
            }
            
            @media (max-width: 768px) {
                .container {
                    flex-direction: column;
                }
                
                .left-panel {
                    padding: 30px;
                }
                
                .right-panel {
                    padding: 30px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="left-panel">
                <div class="logo">Réseau Social</div>
                <div class="tagline">
                    Connectez-vous avec vos amis, partagez des moments,
                    créez des groupes et échangez en toute simplicité.
                </div>
            </div>
            
            <div class="right-panel">
                <h2 class="form-title">Connexion</h2>
                
                <?php if ($error): ?>
                    <div class="error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form action="auth.php?action=login" method="POST">
                    <div class="form-group">
                        <label for="username_email">Nom d'utilisateur ou Email</label>
                        <input type="text" id="username_email" name="username_email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    
                    <button type="submit" class="btn">Se connecter</button>
                </form>
                
                <div class="switch-form">
                    Pas encore de compte ? <a href="auth.php?action=show_register">S'inscrire</a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function displayRegisterForm($error = '', $old_data = []) {
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Inscription - Réseau Social</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: Arial, sans-serif;
            }
            
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            
            .container {
                max-width: 500px;
                width: 100%;
                background: white;
                border-radius: 10px;
                padding: 40px;
                box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            }
            
            .form-title {
                font-size: 2em;
                color: #333;
                margin-bottom: 30px;
                text-align: center;
            }
            
            .form-group {
                margin-bottom: 20px;
            }
            
            label {
                display: block;
                margin-bottom: 5px;
                color: #555;
                font-weight: bold;
            }
            
            input[type="text"],
            input[type="email"],
            input[type="password"],
            select {
                width: 100%;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                transition: border 0.3s;
            }
            
            input:focus,
            select:focus {
                outline: none;
                border-color: #4a00e0;
            }
            
            .btn {
                display: block;
                width: 100%;
                padding: 14px;
                background: #4a00e0;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                font-weight: bold;
                cursor: pointer;
                transition: background 0.3s;
                margin-top: 20px;
            }
            
            .btn:hover {
                background: #8e2de2;
            }
            
            .switch-form {
                text-align: center;
                margin-top: 20px;
                color: #666;
            }
            
            .switch-form a {
                color: #4a00e0;
                text-decoration: none;
                font-weight: bold;
            }
            
            .switch-form a:hover {
                text-decoration: underline;
            }
            
            .error {
                background: #ffebee;
                color: #c62828;
                padding: 10px;
                border-radius: 5px;
                margin-bottom: 20px;
                border: 1px solid #ffcdd2;
            }
            
            .role-select {
                display: flex;
                gap: 20px;
                margin-top: 10px;
            }
            
            .role-option {
                flex: 1;
                border: 2px solid #ddd;
                border-radius: 5px;
                padding: 15px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s;
            }
            
            .role-option:hover {
                border-color: #4a00e0;
            }
            
            .role-option.selected {
                border-color: #4a00e0;
                background: #f0e6ff;
            }
            
            .role-option input[type="radio"] {
                display: none;
            }
            
            .role-label {
                font-weight: bold;
                margin-bottom: 5px;
            }
            
            .role-desc {
                font-size: 12px;
                color: #666;
            }
            
            small {
                color: #666;
                font-size: 12px;
                display: block;
                margin-top: 5px;
            }
        </style>
        <script>
            function selectRole(role) {
                document.querySelectorAll('.role-option').forEach(el => {
                    el.classList.remove('selected');
                });
                event.currentTarget.classList.add('selected');
                document.getElementById('role_' + role).checked = true;
            }
            
            // Sélectionner le rôle par défaut au chargement
            document.addEventListener('DOMContentLoaded', function() {
                const defaultRole = 'membre';
                selectRole(defaultRole);
            });
        </script>
    </head>
    <body>
        <div class="container">
            <h2 class="form-title">Inscription</h2>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form action="auth.php?action=register" method="POST">
                <div class="form-group">
                    <label for="username">Nom d'utilisateur *</label>
                    <input type="text" id="username" name="username" 
                           value="<?php echo htmlspecialchars($old_data['username'] ?? ''); ?>" 
                           required autofocus>
                    <small>Minimum 3 caractères</small>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($old_data['email'] ?? ''); ?>" 
                           required>
                </div>
                
                <div class="form-group">
                    <label for="password">Mot de passe *</label>
                    <input type="password" id="password" name="password" required>
                    <small>Minimum 6 caractères</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirmer le mot de passe *</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                
                <div class="form-group">
                    <label>Rôle</label>
                    <div class="role-select">
                        <div class="role-option <?php echo ($old_data['role'] ?? 'membre') === 'membre' ? 'selected' : ''; ?>" 
                             onclick="selectRole('membre')">
                            <input type="radio" id="role_membre" name="role" value="membre" 
                                   <?php echo ($old_data['role'] ?? 'membre') === 'membre' ? 'checked' : ''; ?>>
                            <div class="role-label">Membre</div>
                            <div class="role-desc">Accès aux groupes et discussions</div>
                        </div>
                        
                        <div class="role-option <?php echo ($old_data['role'] ?? '') === 'admin' ? 'selected' : ''; ?>" 
                             onclick="selectRole('admin')">
                            <input type="radio" id="role_admin" name="role" value="admin" 
                                   <?php echo ($old_data['role'] ?? '') === 'admin' ? 'checked' : ''; ?>>
                            <div class="role-label">Administrateur</div>
                            <div class="role-desc">Gestion complète du site</div>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn">S'inscrire</button>
            </form>
            
            <div class="switch-form">
                Déjà un compte ? <a href="auth.php">Se connecter</a>
            </div>
        </div>
    </body>
    </html>
    <?php
}
?>

<!-- ==================== FICHIER DE VÉRIFICATION (check_auth.php) ==================== -->
<?php
/*
// check_auth.php - À inclure en haut de chaque page protégée
session_start();

function checkAuth() {
    // Vérifier si l'utilisateur est connecté
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../auth/auth.php');
        exit();
    }
    
    // Vérifier si le compte est toujours actif (ENUM '1')
    if (!isset($_SESSION['is_active']) || $_SESSION['is_active'] !== '1') {
        session_destroy();
        header('Location: ../auth/auth.php?error=compte_desactive');
        exit();
    }
    
    return true;
}

// Utilisation dans dashboard.php :
// require_once 'check_auth.php';
// checkAuth();
*/
?>