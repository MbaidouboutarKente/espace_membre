<?php
// Affichage des erreurs PHP (dev)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config/db.php';

// Vérification d'authentification
if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id  = $_SESSION['user_id'];
$username = $_SESSION['username'];

$conversations     = [];
$other_user        = null;
$messages          = [];
$available_friends = [];
$error             = '';
$success           = '';

// CSRF token (pour l'envoi de message)
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Récupérer la liste des conversations (fusion logique)
try {
    // Liste des contacts avec dernier message + compteur non lus
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.first_name,
            u.last_name,
            u.profile_picture,  -- AJOUT: Récupérer l'avatar
            m.content AS last_message,
            m.created_at AS last_message_time,
            SUM(CASE WHEN m.receiver_id = ? AND m.is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
            MAX(m.created_at) AS last_interaction
        FROM users u
        INNER JOIN (
            SELECT 
                CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END AS other_user_id,
                MAX(id) AS last_message_id
            FROM messages
            WHERE sender_id = ? OR receiver_id = ?
            GROUP BY CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END
        ) last_msgs ON u.id = last_msgs.other_user_id
        INNER JOIN messages m ON m.id = last_msgs.last_message_id
        GROUP BY u.id, u.username, u.first_name, u.last_name, u.profile_picture, m.content, m.created_at
        ORDER BY last_interaction DESC
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $user_id]);
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "❌ Erreur SQL (conversations) : " . $e->getMessage() .
             " (fichier: " . basename($e->getFile()) . ", ligne: " . $e->getLine() . ")";
    error_log($error);
}

// Gestion de la conversation sélectionnée
$other_user_id = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT) ?: 0;

if ($other_user_id > 0) {
    try {
        // Infos de l'autre utilisateur
        $stmt = $pdo->prepare("
            SELECT id, username, first_name, last_name, profile_picture  -- AJOUT: Récupérer l'avatar
            FROM users 
            WHERE id = ? AND id != ?
        ");
        $stmt->execute([$other_user_id, $user_id]);
        $other_user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($other_user) {
            // Messages de la conversation
            $stmt = $pdo->prepare("
                SELECT m.*,
                       u_sender.username  AS sender_username,
                       u_sender.first_name AS sender_first_name,
                       u_sender.profile_picture AS sender_profile_picture,  -- AJOUT: Avatar de l'expéditeur
                       u_receiver.username AS receiver_username,
                       u_receiver.first_name AS receiver_first_name,
                       u_receiver.profile_picture AS receiver_profile_picture  -- AJOUT: Avatar du destinataire
                FROM messages m
                LEFT JOIN users u_sender   ON m.sender_id   = u_sender.id
                LEFT JOIN users u_receiver ON m.receiver_id = u_receiver.id
                WHERE (m.sender_id = ? AND m.receiver_id = ?)
                   OR (m.sender_id = ? AND m.receiver_id = ?)
                ORDER BY m.created_at ASC
            ");
            $stmt->execute([$user_id, $other_user_id, $other_user_id, $user_id]);
            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Marquer comme lus
            $stmt = $pdo->prepare("
                UPDATE messages
                SET is_read = 1, read_at = NOW()
                WHERE receiver_id = ? AND sender_id = ? AND is_read = 0
            ");
            $stmt->execute([$user_id, $other_user_id]);
        }
    } catch (PDOException $e) {
        $error = "❌ Erreur SQL (conversation) : " . $e->getMessage() .
                 " (fichier: " . basename($e->getFile()) . ", ligne: " . $e->getLine() . ")";
        error_log($error);
    }
}

// Liste des amis disponibles pour démarrer une nouvelle conversation
try {
    $stmt = $pdo->prepare("
        SELECT DISTINCT u.*, u.profile_picture  -- AJOUT: Récupérer l'avatar
        FROM users u
        INNER JOIN friendships f ON (
            (f.user_id1 = u.id AND f.user_id2 = ?) OR 
            (f.user_id2 = u.id AND f.user_id1 = ?)
        )
        WHERE f.status = 'accepted'
          AND u.id != ?
          AND u.id NOT IN (
            SELECT DISTINCT 
                CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END
            FROM messages
            WHERE sender_id = ? OR receiver_id = ?
          )
        ORDER BY u.username
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $user_id, $user_id]);
    $available_friends = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "❌ Erreur SQL (amis) : " . $e->getMessage() .
             " (fichier: " . basename($e->getFile()) . ", ligne: " . $e->getLine() . ")";
    error_log($error);
}

// Envoi de message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_message') {
    $receiver_id = filter_input(INPUT_POST, 'receiver_id', FILTER_VALIDATE_INT);
    $content     = trim($_POST['content'] ?? '');

    // CSRF check
    $posted_token = $_POST['csrf_token'] ?? '';
    if (!$posted_token || $posted_token !== $csrf_token) {
        $error = "⚠️ Token CSRF invalide.";
    } elseif ($receiver_id <= 0) {
        $error = "⚠️ Destinataire invalide.";
    } elseif ($content === '') {
        $error = "⚠️ Le message ne peut pas être vide.";
    } elseif (strlen($content) > 2000) {
        $error = "⚠️ Message trop long (max 2000 caractères).";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO messages (sender_id, receiver_id, content, created_at, is_read)
                VALUES (?, ?, ?, NOW(), 0)
            ");
            $stmt->execute([$user_id, $receiver_id, $content]);

            header("Location: messages.php?user_id=" . $receiver_id . "&sent=1");
            exit();
        } catch (PDOException $e) {
            $error = "❌ Erreur SQL (envoi) : " . $e->getMessage() .
                     " (fichier: " . basename($e->getFile()) . ", ligne: " . $e->getLine() . ")";
            error_log($error);
        }
    }
}

// Indicateur de succès après redirection
if (isset($_GET['sent']) && $_GET['sent'] == '1') {
    $success = "✅ Message envoyé avec succès!";
}

// Fonction pour obtenir l'avatar
function getUserAvatar($user) {
    if (isset($user['profile_picture']) && !empty($user['profile_picture']) && file_exists("../uploads/avatars/" . $user['profile_picture'])) {
        return $user['profile_picture'];
    }
    return null;
}

// Fonction pour afficher l'avatar dans le HTML
function displayAvatar($user, $class = 'conversation-avatar', $size = '50px') {
    $avatar = getUserAvatar($user);
    $name = !empty($user['first_name']) ? $user['first_name'] : $user['username'];
    
    if ($avatar) {
        echo '<div class="' . $class . '" style="width: ' . $size . '; height: ' . $size . ';">';
        echo '<img src="../uploads/avatars/' . htmlspecialchars($avatar) . '" alt="' . htmlspecialchars($name) . '">';
        echo '</div>';
    } else {
        echo '<div class="' . $class . '" style="width: ' . $size . '; height: ' . $size . ';">';
        echo strtoupper(substr($user['username'], 0, 2));
        echo '</div>';
    }
}

// (Optionnel) Fonctions utilitaires
function truncateText($text, $length = 50) {
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

function formatTime($datetime) {
    if (!$datetime || $datetime == '0000-00-00 00:00:00') return '';
    try {
        $date = new DateTime($datetime);
        $now  = new DateTime();
        $interval = $now->diff($date);

        if ($interval->days === 0) return $date->format('H:i');
        if ($interval->days === 1) return 'Hier ' . $date->format('H:i');
        if ($interval->days < 7) {
            $jours = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
            return $jours[$date->format('w')] . ' ' . $date->format('H:i');
        }
        return $date->format('d/m H:i');
    } catch (Exception $e) {
        return '';
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --primary-light: #7c4dff;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light-bg: #f5f7fb;
            --message-sent: #e3f2fd;
            --message-received: #f5f5f5;
            --border: #e1e4e8;
            --text: #333;
            --text-light: #666;
            --shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: var(--light-bg);
            color: var(--text);
            height: 100vh;
            overflow: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 15px;
        }
        
        .nav-links a {
            color: var(--text-light);
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: #f0f0ff;
            color: var(--primary);
        }
        
        /* Messages Container */
        .messages-container {
            display: flex;
            flex: 1;
            overflow: hidden;
        }
        
        /* Sidebar */
        .conversations-sidebar {
            width: 350px;
            background: white;
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .conversations-header {
            padding: 20px;
            border-bottom: 1px solid var(--border);
        }
        
        .conversations-header h2 {
            color: var(--primary);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .search-conversations {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }
        
        .search-conversations:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .conversations-list {
            flex: 1;
            overflow-y: auto;
        }
        
        .no-conversations {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }
        
        .no-conversations i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #ddd;
        }
        
        .conversation-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
            transition: background 0.3s;
            position: relative;
        }
        
        .conversation-item:hover, .conversation-item.active {
            background: #f8f9ff;
        }
        
        .conversation-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            margin-right: 15px;
            flex-shrink: 0;
            overflow: hidden;
        }
        
        .conversation-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .conversation-info {
            flex: 1;
            min-width: 0;
        }
        
        .conversation-name {
            font-weight: 600;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .conversation-last-message {
            color: var(--text-light);
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .conversation-meta {
            text-align: right;
            margin-left: 10px;
        }
        
        .conversation-time {
            font-size: 0.8rem;
            color: #999;
            margin-bottom: 5px;
            white-space: nowrap;
        }
        
        .unread-badge {
            background: var(--primary);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.8rem;
            display: inline-block;
        }
        
        /* Chat Area */
        .chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: white;
        }
        
        .chat-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 15px;
            background: white;
            z-index: 10;
        }
        
        .chat-user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            overflow: hidden;
        }
        
        .chat-user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .chat-user-info h3 {
            color: var(--primary);
            margin-bottom: 4px;
        }
        
        .user-status {
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .messages-area {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #fafafa;
            display: flex;
            flex-direction: column;
        }
        
        .message-date {
            text-align: center;
            color: var(--text-light);
            font-size: 0.85rem;
            margin: 15px 0;
            padding: 5px 10px;
            background: rgba(0,0,0,0.05);
            border-radius: 10px;
            align-self: center;
        }
        
        .message {
            max-width: 75%;
            margin-bottom: 15px;
            padding: 12px 15px;
            border-radius: 15px;
            position: relative;
            word-wrap: break-word;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        
        .message.sent {
            background: var(--message-sent);
            align-self: flex-end;
            border-bottom-right-radius: 5px;
        }
        
        .message.received {
            background: var(--message-received);
            align-self: flex-start;
            border-bottom-left-radius: 5px;
        }
        
        .message-content {
            margin-bottom: 8px;
            line-height: 1.4;
        }
        
        .message-time {
            font-size: 0.75rem;
            color: var(--text-light);
            text-align: right;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 5px;
        }
        
        .read-indicator {
            color: var(--primary);
        }
        
        .chat-input-area {
            padding: 15px 20px;
            border-top: 1px solid var(--border);
            background: white;
        }
        
        .alert {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        
        .alert-error {
            background: #ffebee;
            color: var(--danger);
            border: 1px solid #ffcdd2;
        }
        
        .chat-form {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .message-input {
            flex: 1;
            padding: 12px 20px;
            border: 1px solid var(--border);
            border-radius: 25px;
            font-size: 1rem;
            resize: none;
            min-height: 50px;
            max-height: 150px;
            line-height: 1.4;
            transition: border-color 0.3s;
        }
        
        .message-input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .send-btn {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2rem;
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .send-btn:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }
        
        /* Empty state */
        .empty-chat {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: var(--text-light);
            padding: 20px;
        }
        
        .empty-chat i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .empty-chat h3 {
            margin-bottom: 10px;
            color: var(--text);
        }
        
        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.95rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: var(--text);
        }
        
        .btn-secondary:hover {
            background: #e0e0e0;
        }
        
        .new-message-btn {
            width: 100%;
            margin-bottom: 15px;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 500px;
            width: 100%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: var(--shadow);
        }
        
        .modal-content h2 {
            color: var(--primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .friends-list h4 {
            color: var(--text-light);
            margin: 20px 0 15px;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .friend-select-item {
            display: flex;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid var(--border);
            cursor: pointer;
            transition: background 0.3s;
            border-radius: 8px;
            margin-bottom: 5px;
        }
        
        .friend-select-item:hover {
            background: #f8f9ff;
        }
        
        .friend-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
            flex-shrink: 0;
            overflow: hidden;
        }
        
        .friend-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .friend-info {
            flex: 1;
            min-width: 0;
        }
        
        .friend-name {
            font-weight: 600;
            margin-bottom: 2px;
        }
        
        .friend-username, .friend-last-message {
            font-size: 0.9rem;
            color: var(--text-light);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .no-friends {
            text-align: center;
            padding: 30px 20px;
            color: var(--text-light);
        }
        
        .modal-actions {
            margin-top: 25px;
            display: flex;
            gap: 10px;
        }
        
        /* Mobile */
        .mobile-only {
            display: none;
        }
        
        .back-to-conversations {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--primary);
            cursor: pointer;
            padding: 5px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 0;
            }
            
            .header {
                padding: 10px 15px;
            }
            
            .nav-links span {
                display: none;
            }
            
            .nav-links a {
                padding: 8px 12px;
            }
            
            .conversations-sidebar {
                width: 100%;
                position: absolute;
                top: 60px;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 100;
                transform: translateX(0);
                transition: transform 0.3s;
            }
            
            .conversations-sidebar.mobile-hidden {
                transform: translateX(-100%);
            }
            
            .chat-area {
                display: none;
            }
            
            .chat-area.active {
                display: flex;
            }
            
            .mobile-only {
                display: block;
            }
            
            .messages-area {
                padding: 15px;
            }
            
            .message {
                max-width: 85%;
            }
            
            .modal-content {
                padding: 20px;
                margin: 0;
            }
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a1a1a1;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="logo">SocialSphere</div>
            <nav class="nav-links">
                <a href="dashboard.php"><i class="fas fa-home"></i> <span>Accueil</span></a>
                <a href="profile.php"><i class="fas fa-user"></i> <span>Profil</span></a>
                <a href="friends.php"><i class="fas fa-users"></i> <span>Amis</span></a>
                <a href="messages.php" class="active"><i class="fas fa-envelope"></i> <span>Messages</span></a>
                <a href="../config/auth.php?action=logout" title="Déconnexion"><i class="fas fa-sign-out-alt"></i></a>
            </nav>
        </header>
        
        <!-- Messages Container -->
        <div class="messages-container">
            <!-- Sidebar conversations -->
            <aside class="conversations-sidebar <?php echo isset($other_user_id) && $other_user_id > 0 ? 'mobile-hidden' : ''; ?>">
                <div class="conversations-header">
                    <h2><i class="fas fa-comments"></i> Messages</h2>
                    <button class="btn btn-primary new-message-btn" onclick="openNewChatModal()">
                        <i class="fas fa-plus"></i> Nouveau message
                    </button>
                    <input type="text" class="search-conversations" placeholder="Rechercher une conversation...">
                </div>
                
                <div class="conversations-list">
                    <?php if (!isset($conversations) || empty($conversations)): ?>
                        <div class="no-conversations">
                            <i class="fas fa-comments"></i>
                            <p>Aucune conversation</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($conversations as $conv): 
                            $displayName = !empty($conv['first_name']) 
                                ? htmlspecialchars($conv['first_name'] . ' ' . $conv['last_name'])
                                : htmlspecialchars($conv['username']);
                            $avatar = isset($conv['profile_picture']) ? $conv['profile_picture'] : (isset($conv['avatar']) ? $conv['avatar'] : '');
                        ?>
                        <div class="conversation-item <?php echo isset($other_user_id) && $other_user_id == $conv['id'] ? 'active' : ''; ?>" 
                             onclick="showConversation(<?php echo $conv['id']; ?>)">
                            <div class="conversation-avatar">
                                <?php if (!empty($avatar) && file_exists("../uploads/avatars/" . $avatar)): ?>
                                    <img src="../uploads/avatars/<?php echo htmlspecialchars($avatar); ?>" alt="<?php echo $displayName; ?>">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($conv['username'], 0, 2)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="conversation-info">
                                <div class="conversation-name"><?php echo $displayName; ?></div>
                                <div class="conversation-last-message">
                                    <?php 
                                    if (isset($conv['last_message'])) {
                                        $last_message = htmlspecialchars($conv['last_message']);
                                        echo strlen($last_message) > 50 ? substr($last_message, 0, 50) . '...' : $last_message;
                                    } else {
                                        echo 'Aucun message';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="conversation-meta">
                                <?php if (isset($conv['last_message_time'])): ?>
                                <div class="conversation-time">
                                    <?php 
                                    $time = strtotime($conv['last_message_time']);
                                    if (date('Y-m-d') == date('Y-m-d', $time)) {
                                        echo date('H:i', $time);
                                    } else {
                                        echo date('d/m', $time);
                                    }
                                    ?>
                                </div>
                                <?php endif; ?>
                                <?php if (isset($conv['unread_count']) && $conv['unread_count'] > 0): ?>
                                <div class="unread-badge"><?php echo $conv['unread_count']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </aside>
            
            <!-- Chat area -->
            <main class="chat-area <?php echo isset($other_user_id) && $other_user_id > 0 && !empty($other_user) ? 'active' : ''; ?>">
                <?php if (!empty($other_user)): 
                    $displayName = !empty($other_user['first_name']) 
                        ? htmlspecialchars($other_user['first_name'] . ' ' . $other_user['last_name'])
                        : htmlspecialchars($other_user['username']);
                    $avatar = isset($other_user['profile_picture']) ? $other_user['profile_picture'] : (isset($other_user['avatar']) ? $other_user['avatar'] : '');
                ?>
                    <!-- Chat header -->
                    <div class="chat-header">
                        <button class="back-to-conversations mobile-only">
                            <i class="fas fa-arrow-left"></i>
                        </button>
                        <div class="chat-user-avatar">
                            <?php if (!empty($avatar) && file_exists("../uploads/avatars/" . $avatar)): ?>
                                <img src="../uploads/avatars/<?php echo htmlspecialchars($avatar); ?>" alt="<?php echo $displayName; ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($other_user['username'], 0, 2)); ?>
                            <?php endif; ?>
                        </div>
                        <div class="chat-user-info">
                            <h3><?php echo $displayName; ?></h3>
                            <p class="user-status">En ligne</p>
                        </div>
                    </div>
                    
                    <!-- Messages -->
                    <div class="messages-area" id="messagesArea">
                        <?php if (!isset($messages) || empty($messages)): ?>
                            <div class="empty-chat">
                                <i class="fas fa-comment-alt"></i>
                                <h3>Démarrez la conversation</h3>
                                <p>Envoyez votre premier message</p>
                            </div>
                        <?php else: ?>
                            <?php 
                            $previous_date = null;
                            foreach ($messages as $msg): 
                                $msg_date = date('Y-m-d', strtotime($msg['created_at']));
                                if ($previous_date !== $msg_date):
                            ?>
                                <div class="message-date">
                                    <?php echo date('d F Y', strtotime($msg['created_at'])); ?>
                                </div>
                            <?php 
                                endif;
                                $previous_date = $msg_date;
                            ?>
                            <div class="message <?php echo isset($user_id) && $msg['sender_id'] == $user_id ? 'sent' : 'received'; ?>">
                                <div class="message-content">
                                    <?php echo isset($msg['content']) ? nl2br(htmlspecialchars($msg['content'])) : ''; ?>
                                </div>
                                <div class="message-time">
                                    <?php echo date('H:i', strtotime($msg['created_at'])); ?>
                                    <?php if (isset($user_id) && $msg['sender_id'] == $user_id && isset($msg['is_read']) && $msg['is_read']): ?>
                                        <i class="fas fa-check-double read-indicator" title="Lu"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Message input -->
                    <div class="chat-input-area">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <form method="POST" class="chat-form" id="messageForm">
                            <input type="hidden" name="action" value="send_message">
                            <input type="hidden" name="receiver_id" value="<?php echo isset($other_user_id) ? (int)$other_user_id : 0; ?>">
                            
                            <!-- Champ CSRF obligatoire -->
                            <?php if (isset($_SESSION['csrf_token'])): ?>
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <?php endif; ?>
                            
                            <textarea name="content" class="message-input" placeholder="Écrivez votre message..." 
                                    oninput="autoResize(this)" required maxlength="1000"></textarea>
                            
                            <button type="submit" class="send-btn" title="Envoyer">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>

                    </div>
                <?php else: ?>
                    <!-- No conversation selected -->
                    <div class="empty-chat">
                        <i class="fas fa-comments"></i>
                        <h3>Sélectionnez une conversation</h3>
                        <p>Choisissez une conversation dans la liste ou démarrez-en une nouvelle</p>
                        <button class="btn btn-primary" onclick="openNewChatModal()">
                            <i class="fas fa-plus"></i> Nouveau message
                        </button>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <!-- New conversation modal -->
    <div id="newChatModal" class="modal">
        <div class="modal-content">
            <h2><i class="fas fa-user-plus"></i> Nouvelle conversation</h2>
            
            <div class="friends-list">
                <?php if ((!isset($available_friends) || empty($available_friends)) && (!isset($conversations) || empty($conversations))): ?>
                    <div class="no-friends">
                        <p>Vous n'avez pas encore d'amis pour démarrer une conversation.</p>
                        <a href="friends.php" class="btn btn-primary">
                            <i class="fas fa-users"></i> Ajouter des amis
                        </a>
                    </div>
                <?php else: ?>
                    <?php if (isset($available_friends) && !empty($available_friends)): ?>
                        <h4><i class="fas fa-user-friends"></i> Nouveaux contacts</h4>
                        <?php foreach ($available_friends as $friend): 
                            $friendDisplayName = !empty($friend['first_name']) 
                                ? htmlspecialchars($friend['first_name'] . ' ' . $friend['last_name'])
                                : htmlspecialchars($friend['username']);
                            $friendAvatar = isset($friend['profile_picture']) ? $friend['profile_picture'] : (isset($friend['avatar']) ? $friend['avatar'] : '');
                        ?>
                        <div class="friend-select-item" onclick="startConversation(<?php echo $friend['id']; ?>)">
                            <div class="friend-avatar">
                                <?php if (!empty($friendAvatar) && file_exists("../uploads/avatars/" . $friendAvatar)): ?>
                                    <img src="../uploads/avatars/<?php echo htmlspecialchars($friendAvatar); ?>" alt="<?php echo $friendDisplayName; ?>">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($friend['username'], 0, 2)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="friend-info">
                                <div class="friend-name"><?php echo $friendDisplayName; ?></div>
                                <div class="friend-username">@<?php echo htmlspecialchars($friend['username']); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <?php if (isset($conversations) && !empty($conversations)): ?>
                        <h4><i class="fas fa-history"></i> Conversations existantes</h4>
                        <?php foreach ($conversations as $conv): 
                            $convDisplayName = !empty($conv['first_name']) 
                                ? htmlspecialchars($conv['first_name'] . ' ' . $conv['last_name'])
                                : htmlspecialchars($conv['username']);
                            $convAvatar = isset($conv['profile_picture']) ? $conv['profile_picture'] : (isset($conv['avatar']) ? $conv['avatar'] : '');
                        ?>
                        <div class="friend-select-item" onclick="startConversation(<?php echo $conv['id']; ?>)">
                            <div class="friend-avatar">
                                <?php if (!empty($convAvatar) && file_exists("../uploads/avatars/" . $convAvatar)): ?>
                                    <img src="../uploads/avatars/<?php echo htmlspecialchars($convAvatar); ?>" alt="<?php echo $convDisplayName; ?>">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($conv['username'], 0, 2)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="friend-info">
                                <div class="friend-name"><?php echo $convDisplayName; ?></div>
                                <div class="friend-last-message">
                                    <?php 
                                    if (isset($conv['last_message'])) {
                                        $last_msg = htmlspecialchars($conv['last_message']);
                                        echo strlen($last_msg) > 30 ? substr($last_msg, 0, 30) . '...' : $last_msg;
                                    } else {
                                        echo 'Aucun message';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeNewChatModal()">Annuler</button>
            </div>
        </div>
    </div>
    
    <script>
        // Fonctions principales
        function showConversation(userId) {
            if (window.innerWidth <= 768) {
                document.querySelector('.conversations-sidebar').classList.add('mobile-hidden');
                document.querySelector('.chat-area').classList.add('active');
            }
            window.location.href = 'messages.php?user_id=' + userId;
        }
        
        function openNewChatModal() {
            document.getElementById('newChatModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeNewChatModal() {
            document.getElementById('newChatModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        function startConversation(userId) {
            closeNewChatModal();
            showConversation(userId);
        }
        
        // Auto-resize du textarea
        function autoResize(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
        }
        
        // Scroll vers le bas des messages
        function scrollToBottom() {
            const messagesArea = document.getElementById('messagesArea');
            if (messagesArea) {
                messagesArea.scrollTop = messagesArea.scrollHeight;
            }
        }
        
        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            // Scroll initial
            scrollToBottom();
            
            // Recherche dans les conversations
            const searchInput = document.querySelector('.search-conversations');
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    const searchTerm = e.target.value.toLowerCase().trim();
                    const conversations = document.querySelectorAll('.conversation-item');
                    
                    conversations.forEach(conv => {
                        const name = conv.querySelector('.conversation-name').textContent.toLowerCase();
                        const message = conv.querySelector('.conversation-last-message').textContent.toLowerCase();
                        
                        if (name.includes(searchTerm) || message.includes(searchTerm)) {
                            conv.style.display = 'flex';
                        } else {
                            conv.style.display = 'none';
                        }
                    });
                });
            }
            
            // Gestion mobile
            const backBtn = document.querySelector('.back-to-conversations');
            if (backBtn) {
                backBtn.addEventListener('click', function() {
                    document.querySelector('.conversations-sidebar').classList.remove('mobile-hidden');
                    document.querySelector('.chat-area').classList.remove('active');
                });
            }
            
            // Fermer modal en cliquant à l'extérieur
            window.addEventListener('click', function(event) {
                const modal = document.getElementById('newChatModal');
                if (event.target === modal) {
                    closeNewChatModal();
                }
            });
            
            // Fermer modal avec Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeNewChatModal();
                }
            });
            
            // Prévention de la soumission multiple
            const messageForm = document.getElementById('messageForm');
            if (messageForm) {
                messageForm.addEventListener('submit', function() {
                    const submitBtn = this.querySelector('.send-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                    }
                });
            }
            
            // Focus sur le textarea quand on ouvre une conversation
            <?php if (isset($other_user_id) && $other_user_id > 0 && !empty($other_user)): ?>
                const messageInput = document.querySelector('.message-input');
                if (messageInput) {
                    setTimeout(() => messageInput.focus(), 100);
                }
            <?php endif; ?>
        });
    </script>
</body>
</html>