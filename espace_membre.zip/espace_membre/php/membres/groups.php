<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$error = null;
$success = null;

// Variables pour la discussion de groupe
$group = null;
$members = [];
$group_messages = [];
$member_count = 0;
$is_member = false;
$user_role = '';

// Vérifier si on est en mode discussion (view=chat)
$group_chat_id = filter_input(INPUT_GET, 'chat', FILTER_VALIDATE_INT);
$view_mode = $group_chat_id ? 'chat' : 'list';

// Initialiser les variables pour les groupes
$my_groups = [];
$suggested_groups = [];
$public_groups = [];

if ($view_mode === 'list') {
    try {
        // Vérifier si la table groups existe
        $stmt = $pdo->query("SHOW TABLES LIKE 'groups'");
        $groups_table_exists = $stmt->rowCount() > 0;
        
        if ($groups_table_exists) {
            // Groupes dont l'utilisateur est membre
            $stmt = $pdo->prepare("
                SELECT g.*, gm.role, gm.joined_at,
                       COUNT(DISTINCT gm2.user_id) as member_count
                FROM groups g
                JOIN group_members gm ON g.id = gm.group_id
                LEFT JOIN group_members gm2 ON g.id = gm2.group_id
                WHERE gm.user_id = ?
                GROUP BY g.id, gm.role, gm.joined_at
                ORDER BY gm.joined_at DESC
            ");
            $stmt->execute([$user_id]);
            $my_groups = $stmt->fetchAll();
            
            // Groupes suggérés
            $stmt = $pdo->prepare("
                SELECT g.*, 
                       COUNT(DISTINCT gm.user_id) as member_count,
                       COUNT(DISTINCT gm2.user_id) as friends_in_group
                FROM groups g
                LEFT JOIN group_members gm ON g.id = gm.group_id
                LEFT JOIN group_members gm2 ON g.id = gm2.group_id 
                    AND gm2.user_id IN (
                        SELECT CASE 
                            WHEN f.user_id1 = ? THEN f.user_id2 
                            ELSE f.user_id1 
                        END as friend_id
                        FROM friendships f
                        WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
                        AND f.status = 'accepted'
                    )
                WHERE g.id NOT IN (
                    SELECT group_id FROM group_members WHERE user_id = ?
                )
                AND g.is_active = 1
                GROUP BY g.id
                HAVING friends_in_group > 0
                ORDER BY friends_in_group DESC, member_count DESC
                LIMIT 20
            ");
            $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
            $suggested_groups = $stmt->fetchAll();
            
            // Tous les groupes publics
            $stmt = $pdo->prepare("
                SELECT g.*, 
                       COUNT(DISTINCT gm.user_id) as member_count
                FROM groups g
                LEFT JOIN group_members gm ON g.id = gm.group_id
                WHERE g.privacy = 'public'
                AND g.is_active = 1
                AND g.id NOT IN (
                    SELECT group_id FROM group_members WHERE user_id = ?
                )
                GROUP BY g.id
                ORDER BY g.created_at DESC
                LIMIT 20
            ");
            $stmt->execute([$user_id]);
            $public_groups = $stmt->fetchAll();
        } else {
            $error = "La fonctionnalité des groupes n'est pas encore configurée. Veuillez créer les tables nécessaires.";
        }
        
    } catch (PDOException $e) {
        error_log("Erreur de base de données groupes: " . $e->getMessage());
        $error = "Erreur lors du chargement des groupes: " . $e->getMessage();
    }
    
} else if ($view_mode === 'chat' && $group_chat_id) {
    try {
        // Vérifier si l'utilisateur est membre du groupe
        $stmt = $pdo->prepare("
            SELECT g.*, gm.role, gm.joined_at
            FROM groups g
            JOIN group_members gm ON g.id = gm.group_id
            WHERE g.id = ? AND gm.user_id = ?
        ");
        $stmt->execute([$group_chat_id, $user_id]);
        $group = $stmt->fetch();
        
        if (!$group) {
            header("Location: groups.php");
            exit();
        }
        
        $is_member = true;
        $user_role = $group['role'];
        
        // Récupérer les membres du groupe
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.first_name, u.last_name, u.profile_picture, gm.role, gm.joined_at
            FROM group_members gm
            JOIN users u ON gm.user_id = u.id
            WHERE gm.group_id = ?
            ORDER BY 
                CASE gm.role 
                    WHEN 'admin' THEN 1
                    WHEN 'moderator' THEN 2
                    ELSE 3
                END,
                gm.joined_at
        ");
        $stmt->execute([$group_chat_id]);
        $members = $stmt->fetchAll();
        
        // Récupérer les messages du groupe (si la table existe)
        try {
            $stmt = $pdo->prepare("
                SELECT gm.*, 
                       u.username, u.first_name, u.last_name, u.profile_picture
                FROM group_messages gm
                JOIN users u ON gm.user_id = u.id
                WHERE gm.group_id = ?
                ORDER BY gm.created_at ASC
            ");
            $stmt->execute([$group_chat_id]);
            $group_messages = $stmt->fetchAll();
        } catch (PDOException $e) {
            // Table group_messages n'existe pas encore
            $group_messages = [];
        }
        
        // Compter le nombre de membres
        $member_count = count($members);
        
    } catch (PDOException $e) {
        error_log("Erreur discussion groupe: " . $e->getMessage());
        $error = "Erreur lors du chargement de la discussion: " . $e->getMessage();
    }
}

// Traiter les actions POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action_group_id = $_POST['group_id'] ?? 0;
        
        try {
            // Vérifier si les tables nécessaires existent
            $stmt = $pdo->query("SHOW TABLES LIKE 'groups'");
            $tables_exist = $stmt->rowCount() > 0;
            
            if (!$tables_exist) {
                throw new Exception("Les tables des groupes n'existent pas encore.");
            }
            
            if ($_POST['action'] === 'join_group') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM group_members WHERE group_id = ? AND user_id = ?");
                $stmt->execute([$action_group_id, $user_id]);
                $is_member = $stmt->fetchColumn();
                
                if ($is_member == 0) {
                    $stmt = $pdo->prepare("
                        INSERT INTO group_members (group_id, user_id, role, joined_at)
                        VALUES (?, ?, 'member', NOW())
                    ");
                    $stmt->execute([$action_group_id, $user_id]);
                    $success = "Vous avez rejoint le groupe avec succès !";
                } else {
                    $error = "Vous êtes déjà membre de ce groupe.";
                }
                
            } elseif ($_POST['action'] === 'leave_group') {
                $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
                $stmt->execute([$action_group_id, $user_id]);
                $role = $stmt->fetchColumn();
                
                if ($role !== 'admin') {
                    $stmt = $pdo->prepare("
                        DELETE FROM group_members 
                        WHERE group_id = ? AND user_id = ?
                    ");
                    $stmt->execute([$action_group_id, $user_id]);
                    $success = "Vous avez quitté le groupe.";
                } else {
                    $error = "Les administrateurs ne peuvent pas quitter le groupe. Transférez d'abord l'administration.";
                }
                
            } elseif ($_POST['action'] === 'create_group') {
                $name = trim($_POST['name'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $privacy = in_array($_POST['privacy'] ?? '', ['public', 'private']) ? $_POST['privacy'] : 'public';
                
                if (empty($name)) {
                    $error = "Le nom du groupe est obligatoire.";
                } elseif (strlen($name) > 100) {
                    $error = "Le nom du groupe ne peut pas dépasser 100 caractères.";
                } else {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM groups WHERE name = ?");
                    $stmt->execute([$name]);
                    $exists = $stmt->fetchColumn();
                    
                    if ($exists > 0) {
                        $error = "Un groupe avec ce nom existe déjà.";
                    } else {
                        // Créer le groupe
                        $stmt = $pdo->prepare("
                            INSERT INTO groups (name, description, created_by, privacy, created_at, is_active)
                            VALUES (?, ?, ?, ?, NOW(), 1)
                        ");
                        $stmt->execute([$name, $description, $user_id, $privacy]);
                        
                        $new_group_id = $pdo->lastInsertId();
                        
                        // Ajouter le créateur comme admin
                        $stmt = $pdo->prepare("
                            INSERT INTO group_members (group_id, user_id, role, joined_at)
                            VALUES (?, ?, 'admin', NOW())
                        ");
                        $stmt->execute([$new_group_id, $user_id]);
                        
                        $success = "Groupe créé avec succès !";
                        $_SESSION['success'] = $success;
                        
                        header("Location: groups.php?chat=" . $new_group_id);
                        exit();
                    }
                }
                
            } elseif ($_POST['action'] === 'send_group_message' && $group_chat_id) {
                $content = trim(filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING));
                
                if (!empty($content) && strlen($content) <= 2000) {
                    // Vérifier si la table group_messages existe
                    $stmt = $pdo->query("SHOW TABLES LIKE 'group_messages'");
                    if ($stmt->rowCount() > 0) {
                        $stmt = $pdo->prepare("
                            INSERT INTO group_messages (group_id, user_id, content, created_at)
                            VALUES (?, ?, ?, NOW())
                        ");
                        $stmt->execute([$group_chat_id, $user_id, $content]);
                    }
                    
                    header("Location: groups.php?chat=" . $group_chat_id);
                    exit();
                }
            }
            
            if ($_POST['action'] !== 'create_group') {
                header("Location: groups.php" . ($view_mode === 'chat' ? "?chat=$group_chat_id" : ""));
                exit();
            }
            
        } catch (Exception $e) {
            error_log("Erreur action groupe: " . $e->getMessage());
            $error = "Une erreur est survenue : " . $e->getMessage();
        }
    }
}

if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $view_mode === 'chat' ? htmlspecialchars($group['name']) . ' - ' : ''; ?>Groupes - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
            height: 100vh;
            overflow: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid #eee;
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 15px;
        }
        
        .nav-links a {
            color: #666;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: #f0f0ff;
            color: var(--primary);
        }
        
        .main-content {
            flex: 1;
            display: flex;
            overflow: hidden;
        }
        
        /* Styles pour la liste des groupes */
        .groups-container {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: <?php echo $view_mode === 'list' ? 'block' : 'none'; ?>;
        }
        
        .groups-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .groups-header h1 {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .create-group-btn {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 20px auto;
        }
        
        .create-group-btn:hover {
            transform: translateY(-2px);
        }
        
        .groups-tabs {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .tab-btn {
            padding: 12px 24px;
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .tab-btn:hover, .tab-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .groups-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .group-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        
        .group-card:hover {
            transform: translateY(-5px);
        }
        
        .group-cover {
            height: 150px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .group-info {
            padding: 20px;
            position: relative;
        }
        
        .group-icon {
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary);
            position: absolute;
            top: -30px;
            left: 20px;
            border: 3px solid white;
        }
        
        .group-name {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 10px;
            padding-top: 10px;
        }
        
        .group-description {
            color: #666;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .group-meta {
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 15px;
        }
        
        .group-meta span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .privacy-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .privacy-public {
            background: #e8f5e9;
            color: var(--success);
        }
        
        .privacy-private {
            background: #fff3cd;
            color: var(--warning);
        }
        
        .group-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
            flex: 1;
            justify-content: center;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .search-box {
            max-width: 600px;
            margin: 30px auto;
        }
        
        .search-box input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 30px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        /* Styles pour la discussion de groupe */
        .chat-container {
            flex: 1;
            display: <?php echo $view_mode === 'chat' ? 'flex' : 'none'; ?>;
            flex-direction: column;
            background: white;
        }
        
        .chat-header {
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: white;
            flex-shrink: 0;
        }
        
        .chat-header-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .back-to-groups {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--primary);
            cursor: pointer;
            padding: 5px;
            margin-right: 10px;
        }
        
        .group-chat-avatar {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .group-chat-info h3 {
            color: var(--primary);
            margin-bottom: 5px;
        }
        
        .group-chat-meta {
            color: #666;
            font-size: 0.9rem;
            display: flex;
            gap: 15px;
        }
        
        .chat-content {
            flex: 1;
            display: flex;
            overflow: hidden;
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #fafafa;
            display: flex;
            flex-direction: column;
        }
        
        .chat-members {
            width: 300px;
            border-left: 1px solid #eee;
            padding: 20px;
            overflow-y: auto;
            background: white;
            display: flex;
            flex-direction: column;
        }
        
        .members-title {
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .member-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 8px;
            transition: background 0.3s;
        }
        
        .member-item:hover {
            background: #f5f5f5;
        }
        
        .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .member-info {
            flex: 1;
        }
        
        .member-name {
            font-weight: 600;
            margin-bottom: 2px;
        }
        
        .member-role {
            font-size: 0.8rem;
            color: #666;
        }
        
        .role-admin {
            color: var(--success);
            font-weight: 600;
        }
        
        .message {
            max-width: 70%;
            margin-bottom: 15px;
            padding: 12px 15px;
            border-radius: 15px;
            position: relative;
            word-wrap: break-word;
        }
        
        .message.sent {
            background: #e3f2fd;
            align-self: flex-end;
            border-bottom-right-radius: 5px;
        }
        
        .message.received {
            background: #f5f5f5;
            align-self: flex-start;
            border-bottom-left-radius: 5px;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 0.85rem;
        }
        
        .message-sender {
            font-weight: 600;
            color: var(--primary);
        }
        
        .message-time {
            color: #999;
        }
        
        .message-content {
            line-height: 1.4;
        }
        
        .chat-input-area {
            padding: 15px 20px;
            border-top: 1px solid #eee;
            background: white;
            flex-shrink: 0;
        }
        
        .chat-form {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .message-input {
            flex: 1;
            padding: 12px 20px;
            border: 1px solid #ddd;
            border-radius: 25px;
            font-size: 1rem;
            resize: none;
            min-height: 50px;
            max-height: 150px;
            line-height: 1.4;
            transition: border-color 0.3s;
        }
        
        .message-input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .send-btn {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2rem;
            transition: transform 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .send-btn:hover {
            transform: scale(1.05);
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        select.form-control {
            cursor: pointer;
        }
        
        .alert {
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .groups-grid {
                grid-template-columns: 1fr;
            }
            
            .groups-tabs {
                flex-direction: column;
            }
            
            .group-actions {
                flex-direction: column;
            }
            
            .chat-members {
                display: none;
            }
            
            .message {
                max-width: 85%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">SocialSphere</div>
            <nav class="nav-links">
                <a href="dashboard.php"><i class="fas fa-home"></i> <span>Accueil</span></a>
                <a href="profile.php"><i class="fas fa-user"></i> <span>Profil</span></a>
                <a href="friends.php"><i class="fas fa-users"></i> <span>Amis</span></a>
                <a href="groups.php" class="active"><i class="fas fa-users-cog"></i> <span>Groupes</span></a>
                <a href="../config/auth.php?action=logout" title="Déconnexion"><i class="fas fa-sign-out-alt"></i></a>
            </nav>
        </div>
        
        <!-- Afficher les messages d'erreur/succès -->
        <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($success); ?>
        </div>
        <?php endif; ?>
        
        <div class="main-content">
            <!-- Container pour la liste des groupes -->
            <div class="groups-container" id="groupsList">
                <?php if ($view_mode === 'list'): ?>
                    <!-- Groups Header -->
                    <div class="groups-header">
                        <h1>Groupes</h1>
                        <p style="color: #666; margin-bottom: 20px;">
                            Rejoignez des groupes partageant vos centres d'intérêt
                        </p>
                        <button class="create-group-btn" onclick="openCreateModal()">
                            <i class="fas fa-plus-circle"></i> Créer un groupe
                        </button>
                    </div>
                    
                    <!-- Search Box -->
                    <div class="search-box">
                        <input type="text" placeholder="Rechercher des groupes...">
                    </div>
                    
                    <!-- Tabs -->
                    <div class="groups-tabs">
                        <button class="tab-btn active" onclick="showTab('my-groups')">
                            Mes groupes (<?php echo count($my_groups); ?>)
                        </button>
                        
                        <button class="tab-btn" onclick="showTab('suggested')">
                            Groupes suggérés
                        </button>
                        
                        <button class="tab-btn" onclick="showTab('public')">
                            Groupes publics
                        </button>
                    </div>
                    
                    <!-- My Groups Tab -->
                    <div id="my-groups" class="tab-content active">
                        <?php if (empty($my_groups)): ?>
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <h3>Vous n'êtes dans aucun groupe</h3>
                                <p style="color: #999; margin-bottom: 20px;">Rejoignez des groupes pour commencer !</p>
                                <button class="btn btn-primary" onclick="showTab('suggested')">
                                    <i class="fas fa-search"></i> Explorer les groupes
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="groups-grid">
                                <?php foreach ($my_groups as $group): ?>
                                <div class="group-card">
                                    <div class="group-cover"></div>
                                    <div class="group-info">
                                        <div class="group-icon">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <h3 class="group-name"><?php echo htmlspecialchars($group['name']); ?></h3>
                                        
                                        <?php if (!empty($group['description'])): ?>
                                        <div class="group-description">
                                            <?php echo substr(htmlspecialchars($group['description']), 0, 100); ?>...
                                        </div>
                                        <?php endif; ?>
                                        
                                        <div class="group-meta">
                                            <span>
                                                <i class="fas fa-users"></i>
                                                <?php echo $group['member_count']; ?> membre<?php echo $group['member_count'] > 1 ? 's' : ''; ?>
                                            </span>
                                            <span class="privacy-badge <?php echo $group['privacy'] === 'public' ? 'privacy-public' : 'privacy-private'; ?>">
                                                <?php echo $group['privacy'] === 'public' ? 'Public' : 'Privé'; ?>
                                            </span>
                                        </div>
                                        
                                        <div class="group-actions">
                                            <button class="btn btn-primary" onclick="openGroupChat(<?php echo $group['id']; ?>, '<?php echo htmlspecialchars($group['name']); ?>')">
                                                <i class="fas fa-comments"></i> Discuter
                                            </button>
                                            <?php if ($group['role'] !== 'admin'): ?>
                                            <form method="POST" style="margin: 0;">
                                                <input type="hidden" name="action" value="leave_group">
                                                <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir quitter ce groupe ?');">
                                                    <i class="fas fa-sign-out-alt"></i> Quitter
                                                </button>
                                            </form>
                                            <?php else: ?>
                                            <span class="btn btn-success">
                                                <i class="fas fa-crown"></i> Admin
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Suggested Groups Tab -->
                    <div id="suggested" class="tab-content">
                        <?php if (empty($suggested_groups)): ?>
                            <div class="empty-state">
                                <i class="fas fa-lightbulb"></i>
                                <h3>Aucune suggestion de groupe</h3>
                                <p style="color: #999;">Aucun groupe suggéré pour le moment.</p>
                            </div>
                        <?php else: ?>
                            <div class="groups-grid">
                                <?php foreach ($suggested_groups as $group): ?>
                                <div class="group-card">
                                    <div class="group-cover"></div>
                                    <div class="group-info">
                                        <div class="group-icon">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <h3 class="group-name"><?php echo htmlspecialchars($group['name']); ?></h3>
                                        
                                        <?php if (!empty($group['description'])): ?>
                                        <div class="group-description">
                                            <?php echo substr(htmlspecialchars($group['description']), 0, 100); ?>...
                                        </div>
                                        <?php endif; ?>
                                        
                                        <div class="group-meta">
                                            <span>
                                                <i class="fas fa-users"></i>
                                                <?php echo $group['member_count']; ?> membre<?php echo $group['member_count'] > 1 ? 's' : ''; ?>
                                            </span>
                                            <?php if ($group['friends_in_group'] > 0): ?>
                                            <span>
                                                <i class="fas fa-user-friends"></i>
                                                <?php echo $group['friends_in_group']; ?> ami<?php echo $group['friends_in_group'] > 1 ? 's' : ''; ?>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="group-actions">
                                            <form method="POST" style="margin: 0;">
                                                <input type="hidden" name="action" value="join_group">
                                                <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-user-plus"></i> Rejoindre
                                                </button>
                                            </form>
                                            <button class="btn btn-secondary" onclick="openGroupChat(<?php echo $group['id']; ?>, '<?php echo htmlspecialchars($group['name']); ?>', true)">
                                                <i class="fas fa-info-circle"></i> Détails
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Public Groups Tab -->
                    <div id="public" class="tab-content">
                        <?php if (empty($public_groups)): ?>
                            <div class="empty-state">
                                <i class="fas fa-globe"></i>
                                <h3>Aucun groupe public disponible</h3>
                                <p style="color: #999;">Tous les groupes publics ont déjà été rejoints.</p>
                            </div>
                        <?php else: ?>
                            <div class="groups-grid">
                                <?php foreach ($public_groups as $group): ?>
                                <div class="group-card">
                                    <div class="group-cover"></div>
                                    <div class="group-info">
                                        <div class="group-icon">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <h3 class="group-name"><?php echo htmlspecialchars($group['name']); ?></h3>
                                        
                                        <?php if (!empty($group['description'])): ?>
                                        <div class="group-description">
                                            <?php echo substr(htmlspecialchars($group['description']), 0, 100); ?>...
                                        </div>
                                        <?php endif; ?>
                                        
                                        <div class="group-meta">
                                            <span>
                                                <i class="fas fa-users"></i>
                                                <?php echo $group['member_count']; ?> membre<?php echo $group['member_count'] > 1 ? 's' : ''; ?>
                                            </span>
                                            <span class="privacy-badge privacy-public">
                                                Public
                                            </span>
                                        </div>
                                        
                                        <div class="group-actions">
                                            <form method="POST" style="margin: 0;">
                                                <input type="hidden" name="action" value="join_group">
                                                <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-user-plus"></i> Rejoindre
                                                </button>
                                            </form>
                                            <button class="btn btn-secondary" onclick="openGroupChat(<?php echo $group['id']; ?>, '<?php echo htmlspecialchars($group['name']); ?>', true)">
                                                <i class="fas fa-info-circle"></i> Détails
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Container pour la discussion de groupe -->
            <div class="chat-container" id="groupChat">
                <?php if ($view_mode === 'chat' && $group): ?>
                    <!-- Chat Header -->
                    <div class="chat-header">
                        <div class="chat-header-info">
                            <button class="back-to-groups" onclick="backToGroups()">
                                <i class="fas fa-arrow-left"></i>
                            </button>
                            <div class="group-chat-avatar">
                                <i class="fas fa-users"></i>
                            </div>
                            <div>
                                <h3><?php echo htmlspecialchars($group['name']); ?></h3>
                                <div class="group-chat-meta">
                                    <span><i class="fas fa-users"></i> <?php echo $member_count; ?> membre<?php echo $member_count > 1 ? 's' : ''; ?></span>
                                    <span class="privacy-badge <?php echo $group['privacy'] === 'public' ? 'privacy-public' : 'privacy-private'; ?>">
                                        <?php echo $group['privacy'] === 'public' ? 'Public' : 'Privé'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php if ($user_role === 'admin'): ?>
                        <span class="btn btn-success" style="width: auto; padding: 8px 16px;">
                            <i class="fas fa-crown"></i> Administrateur
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Chat Content -->
                    <div class="chat-content">
                        <!-- Messages -->
                        <div class="chat-messages" id="chatMessages">
                            <?php if (empty($group_messages)): ?>
                                <div style="text-align: center; padding: 40px; color: #999;">
                                    <i class="fas fa-comments" style="font-size: 3rem; margin-bottom: 15px;"></i>
                                    <h3>Aucun message</h3>
                                    <p>Soyez le premier à envoyer un message dans ce groupe !</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($group_messages as $message): ?>
                                <div class="message <?php echo $message['user_id'] == $user_id ? 'sent' : 'received'; ?>">
                                    <div class="message-header">
                                        <span class="message-sender">
                                            <?php 
                                            $senderName = !empty($message['first_name']) 
                                                ? htmlspecialchars($message['first_name'] . ' ' . $message['last_name'])
                                                : htmlspecialchars($message['username']);
                                            echo $senderName;
                                            ?>
                                        </span>
                                        <span class="message-time">
                                            <?php echo date('H:i', strtotime($message['created_at'])); ?>
                                        </span>
                                    </div>
                                    <div class="message-content">
                                        <?php echo nl2br(htmlspecialchars($message['content'])); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Liste des membres -->
                        <div class="chat-members">
                            <div class="members-title">
                                <i class="fas fa-users"></i> Membres (<?php echo $member_count; ?>)
                            </div>
                            <?php foreach ($members as $member): ?>
                            <div class="member-item">
                                <div class="member-avatar">
                                    <?php echo strtoupper(substr($member['username'], 0, 2)); ?>
                                </div>
                                <div class="member-info">
                                    <div class="member-name">
                                        <?php 
                                        $memberName = !empty($member['first_name']) 
                                            ? htmlspecialchars($member['first_name'] . ' ' . $member['last_name'])
                                            : htmlspecialchars($member['username']);
                                        echo $memberName;
                                        ?>
                                    </div>
                                    <div class="member-role <?php echo $member['role'] === 'admin' ? 'role-admin' : ''; ?>">
                                        <?php 
                                        if ($member['role'] === 'admin') {
                                            echo 'Administrateur';
                                        } elseif ($member['role'] === 'moderator') {
                                            echo 'Modérateur';
                                        } else {
                                            echo 'Membre';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Chat Input -->
                    <div class="chat-input-area">
                        <form method="POST" class="chat-form">
                            <input type="hidden" name="action" value="send_group_message">
                            <input type="hidden" name="group_id" value="<?php echo $group_chat_id; ?>">
                            <textarea name="content" class="message-input" placeholder="Écrivez votre message..." 
                                      oninput="autoResize(this)" required maxlength="2000"></textarea>
                            <button type="submit" class="send-btn" title="Envoyer">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Create Group Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom: 20px; color: var(--primary);">Créer un nouveau groupe</h2>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Nom du groupe *</label>
                    <input type="text" id="name" name="name" class="form-control" required 
                           placeholder="Donnez un nom à votre groupe" maxlength="100">
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control" rows="4"
                              placeholder="Décrivez votre groupe..." maxlength="500"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="privacy">Confidentialité</label>
                    <select id="privacy" name="privacy" class="form-control">
                        <option value="public">Public - Tous peuvent voir et demander à rejoindre</option>
                        <option value="private">Privé - Sur invitation seulement</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="closeCreateModal()" style="flex: 1;">
                        Annuler
                    </button>
                    <input type="hidden" name="action" value="create_group">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-plus-circle"></i> Créer le groupe
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Fonctions pour la liste des groupes
        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.getElementById(tabId).classList.add('active');
            event.currentTarget.classList.add('active');
        }
        
        // Fonctions modales
        function openCreateModal() {
            document.getElementById('createModal').style.display = 'flex';
            document.getElementById('name').focus();
        }
        
        function closeCreateModal() {
            document.getElementById('createModal').style.display = 'none';
            document.querySelector('#createModal form').reset();
        }
        
        // Ouvrir la discussion d'un groupe
        function openGroupChat(groupId, groupName, isPreview = false) {
            if (isPreview) {
                alert('Vous devez rejoindre le groupe "' + groupName + '" pour discuter.');
                return;
            }
            window.location.href = 'groups.php?chat=' + groupId;
        }
        
        // Retour à la liste des groupes
        function backToGroups() {
            window.location.href = 'groups.php';
        }
        
        // Auto-resize du textarea
        function autoResize(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
        }
        
        // Scroll vers le bas des messages
        function scrollToBottom() {
            const chatMessages = document.getElementById('chatMessages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }
        
        // Fermer modale en cliquant à l'extérieur
        window.onclick = function(event) {
            const modal = document.getElementById('createModal');
            if (event.target === modal) {
                closeCreateModal();
            }
        }
        
        // Fermer modale avec Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeCreateModal();
            }
        });
        
        // Recherche dans les groupes
        const searchInput = document.querySelector('.search-box input');
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                const searchTerm = e.target.value.toLowerCase();
                const groupCards = document.querySelectorAll('.group-card');
                
                groupCards.forEach(card => {
                    const groupName = card.querySelector('.group-name').textContent.toLowerCase();
                    const groupDescription = card.querySelector('.group-description')?.textContent.toLowerCase() || '';
                    
                    if (groupName.includes(searchTerm) || groupDescription.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        }
        
        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            // Afficher la liste des groupes par défaut
            <?php if ($view_mode === 'list'): ?>
                showTab('my-groups');
            <?php endif; ?>
            
            // Scroll vers le bas des messages si on est dans un chat
            <?php if ($view_mode === 'chat'): ?>
                scrollToBottom();
                // Focus sur le champ de message
                const messageInput = document.querySelector('.message-input');
                if (messageInput) {
                    setTimeout(() => messageInput.focus(), 100);
                }
            <?php endif; ?>
            
            // Auto-hide messages after 5 seconds
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    alert.style.opacity = '0';
                    alert.style.transition = 'opacity 0.5s';
                    setTimeout(() => alert.remove(), 500);
                });
            }, 5000);
        });
        
        // Prevent form resubmission
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>