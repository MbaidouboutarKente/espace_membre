<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Récupérer les demandes d'amitié en attente
try {
    // Amis acceptés
    $stmt = $pdo->prepare("
        SELECT u.*
        FROM users u
        WHERE u.id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        ORDER BY u.username
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $friends = $stmt->fetchAll();
    
    // Demandes reçues
    $stmt = $pdo->prepare("
        SELECT u.*, f.created_at
        FROM friendships f
        JOIN users u ON u.id = f.action_user_id
        WHERE ((f.user_id1 = ? AND f.user_id2 = u.id) OR (f.user_id2 = ? AND f.user_id1 = u.id))
        AND f.status = 'pending'
        AND f.action_user_id != ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $pending_requests = $stmt->fetchAll();
    
    // Demandes envoyées
    $stmt = $pdo->prepare("
        SELECT u.*, f.created_at
        FROM friendships f
        JOIN users u ON (u.id = f.user_id1 OR u.id = f.user_id2) AND u.id != ?
        WHERE (f.user_id1 = ? OR f.user_id2 = ?)
        AND f.status = 'pending'
        AND f.action_user_id = ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    $sent_requests = $stmt->fetchAll();
    
    // Suggestions d'amis
    $stmt = $pdo->prepare("
        SELECT u.*, COUNT(DISTINCT f2.id) as mutual_friends
        FROM users u
        LEFT JOIN friendships f1 ON (
            (f1.user_id1 = u.id OR f1.user_id2 = u.id) 
            AND f1.status = 'accepted'
        )
        LEFT JOIN friendships f2 ON (
            (f2.user_id1 = f1.user_id1 OR f2.user_id2 = f1.user_id2 OR 
             f2.user_id1 = f1.user_id2 OR f2.user_id2 = f1.user_id1)
            AND f2.status = 'accepted'
            AND (f2.user_id1 = ? OR f2.user_id2 = ?)
        )
        WHERE u.id != ?
        AND u.id NOT IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END
            FROM friendships f
            WHERE f.user_id1 = ? OR f.user_id2 = ?
        )
        GROUP BY u.id
        ORDER BY mutual_friends DESC
        LIMIT 20
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $user_id, $user_id]);
    $suggestions = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}

// Traiter les actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $friend_id = $_POST['friend_id'] ?? 0;
        
        if ($friend_id > 0) {
            try {
                if ($_POST['action'] === 'accept_request') {
                    // Accepter la demande
                    $user_id1 = min($user_id, $friend_id);
                    $user_id2 = max($user_id, $friend_id);
                    
                    $stmt = $pdo->prepare("
                        UPDATE friendships 
                        SET status = 'accepted', updated_at = NOW()
                        WHERE user_id1 = ? AND user_id2 = ?
                    ");
                    $stmt->execute([$user_id1, $user_id2]);
                    
                } elseif ($_POST['action'] === 'reject_request') {
                    // Rejeter la demande
                    $user_id1 = min($user_id, $friend_id);
                    $user_id2 = max($user_id, $friend_id);
                    
                    $stmt = $pdo->prepare("DELETE FROM friendships WHERE user_id1 = ? AND user_id2 = ?");
                    $stmt->execute([$user_id1, $user_id2]);
                    
                } elseif ($_POST['action'] === 'cancel_request') {
                    // Annuler la demande envoyée
                    $user_id1 = min($user_id, $friend_id);
                    $user_id2 = max($user_id, $friend_id);
                    
                    $stmt = $pdo->prepare("DELETE FROM friendships WHERE user_id1 = ? AND user_id2 = ?");
                    $stmt->execute([$user_id1, $user_id2]);
                    
                } elseif ($_POST['action'] === 'remove_friend') {
                    // Supprimer un ami
                    $user_id1 = min($user_id, $friend_id);
                    $user_id2 = max($user_id, $friend_id);
                    
                    $stmt = $pdo->prepare("DELETE FROM friendships WHERE user_id1 = ? AND user_id2 = ?");
                    $stmt->execute([$user_id1, $user_id2]);
                    
                } elseif ($_POST['action'] === 'send_request') {
                    // Envoyer une demande
                    $user_id1 = min($user_id, $friend_id);
                    $user_id2 = max($user_id, $friend_id);
                    
                    // Vérifier si une demande existe déjà
                    $stmt = $pdo->prepare("
                        SELECT id FROM friendships 
                        WHERE user_id1 = ? AND user_id2 = ?
                    ");
                    $stmt->execute([$user_id1, $user_id2]);
                    
                    if ($stmt->rowCount() === 0) {
                        $stmt = $pdo->prepare("
                            INSERT INTO friendships (user_id1, user_id2, status, action_user_id, created_at)
                            VALUES (?, ?, 'pending', ?, NOW())
                        ");
                        $stmt->execute([$user_id1, $user_id2, $user_id]);
                    }
                }
                
                header("Location: friends.php");
                exit();
            } catch (PDOException $e) {
                $error = "Erreur : " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amis - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: #666;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            transition: all 0.3s;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: #f0f0ff;
            color: var(--primary);
        }
        
        .friends-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .friends-header h1 {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .friends-count {
            font-size: 1.2rem;
            color: #666;
        }
        
        .friends-tabs {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .tab-btn {
            padding: 12px 24px;
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .tab-btn:hover, .tab-btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .badge {
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.8rem;
            margin-left: 5px;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .friends-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .friend-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        
        .friend-card:hover {
            transform: translateY(-5px);
        }
        
        .friend-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0 auto 15px;
            overflow: hidden;
        }
        
        .friend-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .friend-name {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }
        
        .friend-meta {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 15px;
        }
        
        .friend-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .search-box {
            max-width: 600px;
            margin: 30px auto;
        }
        
        .search-box input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 30px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .request-time {
            font-size: 0.8rem;
            color: #999;
            margin-top: 5px;
        }
        
        @media (max-width: 768px) {
            .friends-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
            
            .friends-tabs {
                flex-direction: column;
            }
        }
    </style>
    <script>
        function showTab(tabId) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabId).classList.add('active');
            event.currentTarget.classList.add('active');
        }
        
        // Show friends tab by default
        document.addEventListener('DOMContentLoaded', function() {
            showTab('friends');
        });
    </script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">SocialSphere</div>
            <div class="nav-links">
                <a href="dashboard.php"><i class="fas fa-home"></i> Accueil</a>
                <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                <a href="friends.php" class="active"><i class="fas fa-users"></i> Amis</a>
                <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
                <a href="../config/auth.php?action=logout"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
        
        <!-- Friends Header -->
        <div class="friends-header">
            <h1>Amis</h1>
            <div class="friends-count">
                <?php echo isset($friends) ? count($friends) : 0; ?> ami<?php echo isset($friends) && count($friends) > 1 ? 's' : ''; ?>
                <?php if (isset($pending_requests) && count($pending_requests) > 0): ?>
                • <span style="color: var(--danger);"><?php echo count($pending_requests); ?> demande<?php echo count($pending_requests) > 1 ? 's' : ''; ?> en attente</span>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Search Box -->
        <div class="search-box">
            <input type="text" placeholder="Rechercher des amis...">
        </div>
        
        <!-- Tabs -->
        <div class="friends-tabs">
            <button class="tab-btn active" onclick="showTab('friends')">
                Mes amis (<?php echo isset($friends) ? count($friends) : 0; ?>)
            </button>
            
            <button class="tab-btn" onclick="showTab('requests')">
                Demandes
                <?php if (isset($pending_requests) && count($pending_requests) > 0): ?>
                <span class="badge"><?php echo count($pending_requests); ?></span>
                <?php endif; ?>
            </button>
            
            <button class="tab-btn" onclick="showTab('sent')">
                Demandes envoyées (<?php echo isset($sent_requests) ? count($sent_requests) : 0; ?>)
            </button>
            
            <button class="tab-btn" onclick="showTab('suggestions')">
                Suggestions
            </button>
        </div>
        
        <!-- Friends Tab -->
        <div id="friends" class="tab-content active">
            <?php if (!isset($friends) || empty($friends)): ?>
                <div class="empty-state">
                    <i class="fas fa-users"></i>
                    <h3>Aucun ami</h3>
                    <p style="color: #999; margin-bottom: 20px;">Ajoutez des amis pour commencer !</p>
                    <button class="btn btn-primary" onclick="showTab('suggestions')">
                        <i class="fas fa-user-plus"></i> Trouver des amis
                    </button>
                </div>
            <?php else: ?>
                <div class="friends-grid">
                    <?php foreach ($friends as $friend): ?>
                    <div class="friend-card">
                        <div class="friend-avatar">
                            <?php if (isset($friend['profile_picture']) && !empty($friend['profile_picture']) && file_exists("../uploads/avatars/" . $friend['profile_picture'])): ?>
                                <img src="../uploads/avatars/<?php echo htmlspecialchars($friend['profile_picture']); ?>" 
                                     alt="<?php echo htmlspecialchars($friend['username']); ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($friend['username'], 0, 2)); ?>
                            <?php endif; ?>
                        </div>
                        <h3 class="friend-name"><?php echo htmlspecialchars($friend['username']); ?></h3>
                        <?php if (!empty($friend['first_name'])): ?>
                        <div class="friend-meta">
                            <?php echo htmlspecialchars($friend['first_name'] . ' ' . $friend['last_name']); ?>
                        </div>
                        <?php endif; ?>
                        <div class="friend-actions">
                            <a href="profile_view.php?id=<?php echo $friend['id']; ?>" class="btn btn-primary">
                                <i class="fas fa-eye"></i> Voir
                            </a>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="remove_friend">
                                <input type="hidden" name="friend_id" value="<?php echo $friend['id']; ?>">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-user-minus"></i> Retirer
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Requests Tab -->
        <div id="requests" class="tab-content">
            <?php if (!isset($pending_requests) || empty($pending_requests)): ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>Aucune demande en attente</h3>
                    <p style="color: #999;">Vous n'avez pas de nouvelles demandes d'amitié.</p>
                </div>
            <?php else: ?>
                <div class="friends-grid">
                    <?php foreach ($pending_requests as $request): ?>
                    <div class="friend-card">
                        <div class="friend-avatar">
                            <?php if (isset($request['profile_picture']) && !empty($request['profile_picture']) && file_exists("../uploads/avatars/" . $request['profile_picture'])): ?>
                                <img src="../uploads/avatars/<?php echo htmlspecialchars($request['profile_picture']); ?>" 
                                     alt="<?php echo htmlspecialchars($request['username']); ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($request['username'], 0, 2)); ?>
                            <?php endif; ?>
                        </div>
                        <h3 class="friend-name"><?php echo htmlspecialchars($request['username']); ?></h3>
                        <div class="request-time">
                            Demande reçue le <?php echo date('d/m/Y', strtotime($request['created_at'])); ?>
                        </div>
                        <div class="friend-actions">
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="accept_request">
                                <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check"></i> Accepter
                                </button>
                            </form>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="reject_request">
                                <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-times"></i> Refuser
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Sent Requests Tab -->
        <div id="sent" class="tab-content">
            <?php if (!isset($sent_requests) || empty($sent_requests)): ?>
                <div class="empty-state">
                    <i class="fas fa-paper-plane"></i>
                    <h3>Aucune demande envoyée</h3>
                    <p style="color: #999;">Vous n'avez pas envoyé de demandes d'amitié.</p>
                </div>
            <?php else: ?>
                <div class="friends-grid">
                    <?php foreach ($sent_requests as $request): ?>
                    <div class="friend-card">
                        <div class="friend-avatar">
                            <?php if (isset($request['profile_picture']) && !empty($request['profile_picture']) && file_exists("../uploads/avatars/" . $request['profile_picture'])): ?>
                                <img src="../uploads/avatars/<?php echo htmlspecialchars($request['profile_picture']); ?>" 
                                     alt="<?php echo htmlspecialchars($request['username']); ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($request['username'], 0, 2)); ?>
                            <?php endif; ?>
                        </div>
                        <h3 class="friend-name"><?php echo htmlspecialchars($request['username']); ?></h3>
                        <div class="request-time">
                            Demande envoyée le <?php echo date('d/m/Y', strtotime($request['created_at'])); ?>
                        </div>
                        <div class="friend-actions">
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="cancel_request">
                                <input type="hidden" name="friend_id" value="<?php echo $request['id']; ?>">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-times"></i> Annuler
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Suggestions Tab -->
        <div id="suggestions" class="tab-content">
            <?php if (!isset($suggestions) || empty($suggestions)): ?>
                <div class="empty-state">
                    <i class="fas fa-user-plus"></i>
                    <h3>Aucune suggestion</h3>
                    <p style="color: #999;">Aucune suggestion d'ami disponible pour le moment.</p>
                </div>
            <?php else: ?>
                <div class="friends-grid">
                    <?php foreach ($suggestions as $suggestion): ?>
                    <div class="friend-card">
                        <div class="friend-avatar">
                            <?php if (isset($suggestion['profile_picture']) && !empty($suggestion['profile_picture']) && file_exists("../uploads/avatars/" . $suggestion['profile_picture'])): ?>
                                <img src="../uploads/avatars/<?php echo htmlspecialchars($suggestion['profile_picture']); ?>" 
                                     alt="<?php echo htmlspecialchars($suggestion['username']); ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($suggestion['username'], 0, 2)); ?>
                            <?php endif; ?>
                        </div>
                        <h3 class="friend-name"><?php echo htmlspecialchars($suggestion['username']); ?></h3>
                        <?php if (isset($suggestion['mutual_friends']) && $suggestion['mutual_friends'] > 0): ?>
                        <div class="friend-meta">
                            <?php echo $suggestion['mutual_friends']; ?> ami<?php echo $suggestion['mutual_friends'] > 1 ? 's' : ''; ?> en commun
                        </div>
                        <?php endif; ?>
                        <div class="friend-actions">
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="send_request">
                                <input type="hidden" name="friend_id" value="<?php echo $suggestion['id']; ?>">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-user-plus"></i> Ajouter
                                </button>
                            </form>
                            <a href="profile_view.php?id=<?php echo $suggestion['id']; ?>" class="btn btn-secondary">
                                <i class="fas fa-eye"></i> Voir
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>