<?php
// Active l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php'; // Connexion à la base de données

if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// =========== FONCTIONS UTILITAIRES ===========
function tableExists($pdo, $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

function columnExists($pdo, $table, $column) {
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

function formatRelativeTime($date) {
    $now = new DateTime();
    $dateTime = new DateTime($date);
    $interval = $now->diff($dateTime);
    
    if ($interval->y > 0) return "il y a " . $interval->y . " an" . ($interval->y > 1 ? "s" : "");
    if ($interval->m > 0) return "il y a " . $interval->m . " mois";
    if ($interval->d > 0) return "il y a " . $interval->d . " jour" . ($interval->d > 1 ? "s" : "");
    if ($interval->h > 0) return "il y a " . $interval->h . " heure" . ($interval->h > 1 ? "s" : "");
    if ($interval->i > 0) return "il y a " . $interval->i . " minute" . ($interval->i > 1 ? "s" : "");
    return "à l'instant";
}

function getFileIcon($extension) {
    $icons = [
        'jpg' => 'fas fa-image',
        'jpeg' => 'fas fa-image',
        'png' => 'fas fa-image',
        'gif' => 'fas fa-image',
        'webp' => 'fas fa-image',
        'mp4' => 'fas fa-video',
        'mov' => 'fas fa-video',
        'avi' => 'fas fa-video',
        'pdf' => 'fas fa-file-pdf',
        'doc' => 'fas fa-file-word',
        'docx' => 'fas fa-file-word'
    ];
    return $icons[strtolower($extension)] ?? 'fas fa-file';
}

// =========== CONFIGURATION ===========
$post_types = [
    'general' => ['icon' => 'fas fa-newspaper', 'label' => 'Général', 'color' => '#4a00e0'],
    'question' => ['icon' => 'fas fa-question-circle', 'label' => 'Question', 'color' => '#17a2b8'],
    'idea' => ['icon' => 'fas fa-lightbulb', 'label' => 'Idée', 'color' => '#ffc107'],
    'event' => ['icon' => 'fas fa-calendar-alt', 'label' => 'Événement', 'color' => '#dc3545'],
    'achievement' => ['icon' => 'fas fa-trophy', 'label' => 'Réussite', 'color' => '#28a745'],
    'announcement' => ['icon' => 'fas fa-bullhorn', 'label' => 'Annonce', 'color' => '#8e2de2']
];

$privacy_levels = [
    'public' => ['icon' => 'fas fa-globe', 'label' => 'Public', 'color' => '#4a00e0'],
    'friends' => ['icon' => 'fas fa-user-friends', 'label' => 'Amis uniquement', 'color' => '#17a2b8'],
    'private' => ['icon' => 'fas fa-lock', 'label' => 'Privé', 'color' => '#dc3545']
];

$allowed_extensions = [
    'images' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    'videos' => ['mp4', 'mov', 'avi'],
    'documents' => ['pdf', 'doc', 'docx']
];

// =========== VÉRIFICATION DES TABLES ===========
$users_exists = tableExists($pdo, 'users');
$posts_exists = tableExists($pdo, 'posts');
$comments_exists = tableExists($pdo, 'comments');
$likes_exists = tableExists($pdo, 'likes');
$friendships_exists = tableExists($pdo, 'friendships');
$groups_exists = tableExists($pdo, 'groups');
$group_members_exists = tableExists($pdo, 'group_members');
$messages_exists = tableExists($pdo, 'messages');
$notifications_exists = tableExists($pdo, 'notifications');

// Vérification des colonnes spécifiques pour posts
if ($posts_exists) {
    $post_type_exists = columnExists($pdo, 'posts', 'post_type');
    $media_url_exists = columnExists($pdo, 'posts', 'media_url');
    $privacy_exists = columnExists($pdo, 'posts', 'privacy');
    $like_count_exists = columnExists($pdo, 'posts', 'like_count');
    $comment_count_exists = columnExists($pdo, 'posts', 'comment_count');
}

// =========== VARIABLES ===========
$user = [];
$friend_count = 0;
$post_count = 0;
$group_count = 0;
$all_posts = [];
$my_posts = [];
$friend_posts = [];
$my_groups = [];
$friend_suggestions = [];
$group_suggestions = [];
$unread_messages = 0;
$unread_notifications = 0;
$error = null;
$success = null;

// =========== CRÉATION DES DOSSIERS ===========
$upload_dirs = [
    '../uploads/avatars/',
    '../uploads/posts/media/',
    '../uploads/groups/'
];

foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
}

// =========== LOGIQUE PRINCIPALE ===========
try {
    // Récupérer les informations de l'utilisateur
    if ($users_exists) {
        $stmt = $pdo->prepare("SELECT u.* FROM users u WHERE u.id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            session_destroy();
            header('Location: ../config/auth.php');
            exit();
        }
        
        // Compter les amis
        if ($friendships_exists) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as count 
                FROM friendships 
                WHERE (user_id1 = ? OR user_id2 = ?) 
                AND status = 'accepted'
            ");
            $stmt->execute([$user_id, $user_id]);
            $friend_count = $stmt->fetch()['count'];
        }
        
        // Compter les publications
        if ($posts_exists) {
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM posts WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $post_count = $stmt->fetch()['count'];
        }
        
        // Compter les groupes
        if ($group_members_exists) {
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM group_members WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $group_count = $stmt->fetch()['count'];
        }
    }
    
    // Récupérer TOUTES les publications
    if ($posts_exists && $users_exists) {
        // Construire la requête en fonction des colonnes disponibles
        $select_fields = "p.*, u.username, u.profile_picture";
        
        if ($friendships_exists) {
            $query = "
                SELECT $select_fields,
                       CASE 
                           WHEN p.user_id = :user_id THEN 'my_post'
                           WHEN f.status = 'accepted' THEN 'friend_post'
                           ELSE 'other_post'
                       END as post_type
                FROM posts p
                JOIN users u ON p.user_id = u.id
                LEFT JOIN friendships f ON (
                    (f.user_id1 = :user_id AND f.user_id2 = u.id) OR 
                    (f.user_id1 = u.id AND f.user_id2 = :user_id)
                ) AND f.status = 'accepted'
                WHERE p.privacy != 'private' OR p.user_id = :user_id
                OR (p.privacy = 'friends' AND f.user_id1 IS NOT NULL)
                OR p.privacy = 'public'
                ORDER BY p.created_at DESC
                LIMIT 20
            ";
        } else {
            $query = "
                SELECT $select_fields,
                       CASE 
                           WHEN p.user_id = :user_id THEN 'my_post'
                           ELSE 'other_post'
                       END as post_type
                FROM posts p
                JOIN users u ON p.user_id = u.id
                ORDER BY p.created_at DESC
                LIMIT 20
            ";
        }
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([':user_id' => $user_id]);
        $all_posts = $stmt->fetchAll();
        
        // Séparer les posts par type
        $my_posts = array_filter($all_posts, fn($post) => $post['user_id'] == $user_id);
        $friend_posts = array_filter($all_posts, fn($post) => 
            $post['user_id'] != $user_id && isset($post['post_type']) && $post['post_type'] == 'friend_post'
        );
    }
    
    // Récupérer les groupes de l'utilisateur
    if ($groups_exists && $group_members_exists) {
        $stmt = $pdo->prepare("
            SELECT g.*
            FROM groups g
            JOIN group_members gm ON g.id = gm.group_id
            WHERE gm.user_id = ?
            ORDER BY gm.joined_at DESC
            LIMIT 5
        ");
        $stmt->execute([$user_id]);
        $my_groups = $stmt->fetchAll();
    }
    
    // Suggestions d'amis
    if ($users_exists && $friendships_exists) {
        $query = "
            SELECT u.*
            FROM users u
            WHERE u.id != ?
            AND u.id NOT IN (
                SELECT DISTINCT 
                    CASE 
                        WHEN f.user_id1 = ? THEN f.user_id2 
                        ELSE f.user_id1 
                    END
                FROM friendships f
                WHERE f.user_id1 = ? OR f.user_id2 = ?
            )
            ORDER BY RAND()
            LIMIT 5
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
        $friend_suggestions = $stmt->fetchAll();
    }
    
    // Suggestions de groupes
    if ($groups_exists && $group_members_exists) {
        $query = "
            SELECT g.*
            FROM groups g
            WHERE g.id NOT IN (
                SELECT group_id FROM group_members WHERE user_id = ?
            )
            ORDER BY RAND()
            LIMIT 5
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id]);
        $group_suggestions = $stmt->fetchAll();
    }
    
    // Messages non lus
    if ($messages_exists) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM messages WHERE receiver_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        $unread_messages = $result ? $result['count'] : 0;
    }
    
    // Notifications non lues
    if ($notifications_exists) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        $unread_notifications = $result ? $result['count'] : 0;
    }
    
    // =========== TRAITEMENT DES FORMULAIRES ===========
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create_post':
                $content = trim($_POST['content'] ?? '');
                $post_type = $_POST['post_type'] ?? 'general';
                $privacy = $_POST['privacy'] ?? 'public';
                $media_url = null;
                
                // Traitement du média uploadé
                if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = '../uploads/posts/media/';
                    $file_name = $_FILES['media']['name'];
                    $file_tmp = $_FILES['media']['tmp_name'];
                    $file_size = $_FILES['media']['size'];
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    
                    // Vérifier l'extension
                    $allowed_all = array_merge(...array_values($allowed_extensions));
                    
                    if (in_array($file_ext, $allowed_all)) {
                        // Vérifier la taille (10MB max)
                        if ($file_size <= 10 * 1024 * 1024) {
                            // Générer un nom unique
                            $new_file_name = uniqid('media_', true) . '.' . $file_ext;
                            $upload_path = $upload_dir . $new_file_name;
                            
                            if (move_uploaded_file($file_tmp, $upload_path)) {
                                $media_url = 'posts/media/' . $new_file_name;
                            } else {
                                $error = "Erreur lors de l'upload du fichier.";
                            }
                        } else {
                            $error = "Le fichier est trop volumineux (max 10MB).";
                        }
                    } else {
                        $error = "Type de fichier non autorisé.";
                    }
                }
                
                // Créer la publication si pas d'erreur
                if (!$error && (!empty($content) || !empty($media_url))) {
                    try {
                        $columns = ['user_id', 'content', 'created_at'];
                        $values = [$user_id, $content, date('Y-m-d H:i:s')];
                        
                        if ($post_type_exists) {
                            $columns[] = 'post_type';
                            $values[] = $post_type;
                        }
                        
                        if ($media_url_exists && $media_url) {
                            $columns[] = 'media_url';
                            $values[] = $media_url;
                        }
                        
                        if ($privacy_exists) {
                            $columns[] = 'privacy';
                            $values[] = $privacy;
                        }
                        
                        $placeholders = str_repeat('?,', count($values) - 1) . '?';
                        $sql = "INSERT INTO posts (" . implode(', ', $columns) . ") VALUES ($placeholders)";
                        
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute($values);
                        
                        $success = "Publication créée avec succès !";
                    } catch (PDOException $e) {
                        $error = "Erreur lors de la publication : " . $e->getMessage();
                    }
                }
                break;
                
            case 'like_post':
                $post_id = $_POST['post_id'] ?? 0;
                if ($post_id > 0 && $likes_exists) {
                    try {
                        // Vérifier si l'utilisateur a déjà liké
                        $stmt = $pdo->prepare("SELECT id FROM likes WHERE post_id = ? AND user_id = ?");
                        $stmt->execute([$post_id, $user_id]);
                        
                        if ($stmt->rowCount() === 0) {
                            $stmt = $pdo->prepare("INSERT INTO likes (post_id, user_id, created_at) VALUES (?, ?, NOW())");
                            $stmt->execute([$post_id, $user_id]);
                        } else {
                            $stmt = $pdo->prepare("DELETE FROM likes WHERE post_id = ? AND user_id = ?");
                            $stmt->execute([$post_id, $user_id]);
                        }
                    } catch (PDOException $e) {
                        $error = "Erreur : " . $e->getMessage();
                    }
                }
                break;
                
            case 'add_comment':
                $post_id = $_POST['post_id'] ?? 0;
                $comment_content = trim($_POST['comment_content'] ?? '');
                
                if ($post_id > 0 && !empty($comment_content) && $comments_exists) {
                    try {
                        $stmt = $pdo->prepare("
                            INSERT INTO comments (post_id, user_id, content, created_at)
                            VALUES (?, ?, ?, NOW())
                        ");
                        $stmt->execute([$post_id, $user_id, $comment_content]);
                    } catch (PDOException $e) {
                        $error = "Erreur : " . $e->getMessage();
                    }
                }
                break;
                
            case 'send_friend_request':
                $friend_id = $_POST['friend_id'] ?? 0;
                if ($friend_id > 0 && $friend_id != $user_id && $friendships_exists) {
                    try {
                        $user_id1 = min($user_id, $friend_id);
                        $user_id2 = max($user_id, $friend_id);
                        
                        $stmt = $pdo->prepare("
                            INSERT INTO friendships (user_id1, user_id2, status, action_user_id, created_at)
                            VALUES (?, ?, 'pending', ?, NOW())
                            ON DUPLICATE KEY UPDATE status='pending'
                        ");
                        $stmt->execute([$user_id1, $user_id2, $user_id]);
                    } catch (PDOException $e) {
                        $error = "Erreur : " . $e->getMessage();
                    }
                }
                break;
                
            case 'join_group':
                $group_id = $_POST['group_id'] ?? 0;
                if ($group_id > 0 && $group_members_exists) {
                    try {
                        $stmt = $pdo->prepare("
                            INSERT INTO group_members (group_id, user_id, joined_at)
                            VALUES (?, ?, NOW())
                            ON DUPLICATE KEY UPDATE joined_at=NOW()
                        ");
                        $stmt->execute([$group_id, $user_id]);
                    } catch (PDOException $e) {
                        $error = "Erreur : " . $e->getMessage();
                    }
                }
                break;
        }
        
        // Redirection pour éviter le rechargement du formulaire
        if (!isset($error)) {
            header("Location: dashboard.php");
            exit();
        }
    }
    
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --header-height: 70px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
            min-height: 100vh;
        }
        
        /* Header */
        .main-header {
            background: white;
            height: var(--header-height);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .search-bar {
            flex: 1;
            max-width: 500px;
            margin: 0 2rem;
        }
        
        .search-bar input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            font-size: 0.95rem;
            transition: border 0.3s;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .header-icons {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }
        
        .icon-link {
            position: relative;
            color: #666;
            text-decoration: none;
            font-size: 1.3rem;
            transition: color 0.3s;
        }
        
        .icon-link:hover {
            color: var(--primary);
        }
        
        .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            overflow: hidden;
        }
        
        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        /* Main Layout */
        .main-container {
            display: flex;
            min-height: calc(100vh - var(--header-height));
        }
        
        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: white;
            padding: 1.5rem 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.05);
            position: sticky;
            top: var(--header-height);
            height: calc(100vh - var(--header-height));
            overflow-y: auto;
        }
        
        .user-profile {
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
            text-align: center;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: bold;
            margin: 0 auto 1rem;
            overflow: hidden;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-name {
            font-weight: 600;
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
        }
        
        .stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 1.5rem;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-weight: 700;
            font-size: 1.2rem;
            display: block;
        }
        
        .stat-label {
            font-size: 0.8rem;
            color: #666;
        }
        
        .sidebar-nav {
            list-style: none;
            padding: 1rem 0;
        }
        
        .nav-item {
            margin-bottom: 0.2rem;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 1.5rem;
            color: #555;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        
        .nav-link:hover, .nav-link.active {
            background: #f0f0ff;
            color: var(--primary);
            border-left-color: var(--primary);
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        /* Content */
        .content {
            flex: 1;
            padding: 2rem;
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            align-items: start;
        }
        
        @media (max-width: 1200px) {
            .content {
                grid-template-columns: 1fr;
            }
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .post-form textarea {
            width: 100%;
            padding: 1rem;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            resize: vertical;
            min-height: 100px;
            font-size: 1rem;
            margin-bottom: 1rem;
            transition: border 0.3s;
        }
        
        .post-form textarea:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .btn {
            padding: 0.6rem 1.5rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(74, 0, 224, 0.2);
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.85rem;
            background: #f0f0f0;
            color: #333;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-sm:hover {
            background: var(--primary);
            color: white;
        }
        
        .btn-sm.primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-sm.primary:hover {
            background: var(--secondary);
        }
        
        /* Options grid */
        .options-grid {
            display: grid;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }
        
        .option-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .option-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            border: 2px solid #eee;
            transition: all 0.3s;
        }
        
        .option-label:hover {
            border-color: var(--primary);
            background: #f0f0ff;
        }
        
        .option-label.selected {
            border-color: var(--primary);
            background: rgba(74, 0, 224, 0.1);
        }
        
        /* File upload */
        .file-upload-area {
            border: 2px dashed #ccc;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 1rem;
        }
        
        .file-upload-area:hover {
            border-color: var(--primary);
            background: #f0f0ff;
        }
        
        .file-upload-area.drag-over {
            border-color: var(--primary);
            background: rgba(74, 0, 224, 0.1);
        }
        
        .media-preview {
            margin-top: 1rem;
            display: none;
        }
        
        .media-preview img,
        .media-preview video {
            max-width: 100%;
            max-height: 300px;
            border-radius: 8px;
            border: 2px solid var(--primary);
        }
        
        /* Posts Tabs */
        .posts-tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            background: white;
            padding: 0.75rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .tab-btn {
            padding: 0.5rem 1.5rem;
            border: none;
            background: transparent;
            color: #666;
            font-weight: 600;
            cursor: pointer;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .tab-btn:hover {
            background: #f0f0f0;
        }
        
        .tab-btn.active {
            background: var(--primary);
            color: white;
        }
        
        /* Posts Feed */
        .posts-feed {
            grid-column: 1;
        }
        
        .post-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            border-left: 4px solid transparent;
        }
        
        .post-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .post-card.my-post {
            border-left-color: var(--primary);
        }
        
        .post-card.friend-post {
            border-left-color: var(--success);
        }
        
        .post-card.other-post {
            border-left-color: #e0e0e0;
        }
        
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .post-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            margin-right: 1rem;
            overflow: hidden;
        }
        
        .post-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .post-info {
            flex: 1;
        }
        
        .post-author {
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .post-meta {
            color: #666;
            font-size: 0.9rem;
            margin-top: 0.25rem;
        }
        
        .post-tags {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }
        
        .post-tag {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            color: white;
            font-weight: 600;
        }
        
        .post-content {
            margin-bottom: 1rem;
            line-height: 1.6;
            padding: 0.5rem 0;
        }
        
        .post-media {
            margin-top: 1rem;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .post-media img,
        .post-media video {
            max-width: 100%;
            max-height: 500px;
            display: block;
        }
        
        .media-file {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        .post-actions {
            display: flex;
            gap: 1rem;
            border-top: 1px solid #eee;
            padding-top: 1rem;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            background: #f5f5f5;
            color: var(--primary);
        }
        
        .action-btn.liked {
            color: var(--danger);
        }
        
        .comments-section {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
        }
        
        .comment-form {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .comment-form input {
            flex: 1;
            padding: 0.8rem;
            border: 1px solid #e0e0e0;
            border-radius: 20px;
        }
        
        .comment-form input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        /* Widgets */
        .sidebar-content {
            grid-column: 2;
        }
        
        .widget {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .widget-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .suggestion-list, .group-list {
            list-style: none;
        }
        
        .suggestion-item, .group-item {
            display: flex;
            align-items: center;
            padding: 0.8rem 0;
            border-bottom: 1px solid #f5f5f5;
        }
        
        .suggestion-item:last-child, .group-item:last-child {
            border-bottom: none;
        }
        
        .suggestion-avatar, .group-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            font-weight: bold;
            overflow: hidden;
        }
        
        .suggestion-avatar img, .group-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .group-avatar {
            border-radius: 8px;
        }
        
        .suggestion-info, .group-info {
            flex: 1;
        }
        
        .suggestion-name, .group-name {
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .suggestion-meta, .group-meta {
            color: #666;
            font-size: 0.85rem;
        }
        
        /* Alerts */
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .alert-success {
            background: #e8f5e9;
            color: var(--success);
            border: 1px solid #c8e6c9;
        }
        
        .alert-error {
            background: #ffebee;
            color: var(--danger);
            border: 1px solid #ffcdd2;
        }
        
        .alert-info {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
        }
        
        /* Database Info */
        .db-info ul {
            margin-left: 20px;
            margin-top: 0.5rem;
        }
        
        .db-info li {
            margin-bottom: 0.3rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-fix {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: var(--primary);
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        
        .btn-fix:hover {
            background: var(--secondary);
            transform: translateY(-2px);
        }
        
        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stat-card .number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            display: block;
        }
        
        .stat-card .label {
            font-size: 0.8rem;
            color: #666;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #666;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #ddd;
            margin-bottom: 1rem;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .sidebar-content {
                grid-column: 1;
            }
        }
        
        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
                order: 2;
            }
            
            .search-bar {
                display: none;
            }
            
            .content {
                padding: 1rem;
            }
            
            .posts-tabs {
                overflow-x: auto;
                flex-wrap: nowrap;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="main-header">
        <div class="logo">SocialSphere</div>
        
        <div class="search-bar">
            <input type="text" placeholder="Rechercher des amis, groupes, publications...">
        </div>
        
        <div class="header-icons">
            <?php if ($notifications_exists): ?>
            <a href="notifications.php" class="icon-link">
                <i class="fas fa-bell"></i>
                <?php if ($unread_notifications > 0): ?>
                <span class="badge"><?php echo $unread_notifications; ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>
            
            <?php if ($messages_exists): ?>
            <a href="messages.php" class="icon-link">
                <i class="fas fa-envelope"></i>
                <?php if ($unread_messages > 0): ?>
                <span class="badge"><?php echo $unread_messages; ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>
            
            <a href="friends.php" class="icon-link">
                <i class="fas fa-users"></i>
            </a>
            
            <div class="user-menu" onclick="window.location.href='profile.php'">
                <div class="user-avatar">
                    <?php if (!empty($user['profile_picture']) && file_exists("../uploads/avatars/" . $user['profile_picture'])): ?>
                        <img src="../uploads/avatars/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="<?php echo htmlspecialchars($username); ?>">
                    <?php else: ?>
                        <?php echo strtoupper(substr($username, 0, 2)); ?>
                    <?php endif; ?>
                </div>
                <span><?php echo htmlspecialchars($username); ?></span>
            </div>
        </div>
    </header>
    
    <!-- Main Content -->
    <div class="main-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="user-profile">
                <div class="profile-avatar">
                    <?php if (!empty($user['profile_picture']) && file_exists("../uploads/avatars/" . $user['profile_picture'])): ?>
                        <img src="../uploads/avatars/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="<?php echo htmlspecialchars($username); ?>">
                    <?php else: ?>
                        <?php echo strtoupper(substr($username, 0, 2)); ?>
                    <?php endif; ?>
                </div>
                <h3 class="profile-name"><?php echo htmlspecialchars($username); ?></h3>
                
                <div class="stats">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $friend_count; ?></span>
                        <span class="stat-label">Amis</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $post_count; ?></span>
                        <span class="stat-label">Publications</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $group_count; ?></span>
                        <span class="stat-label">Groupes</span>
                    </div>
                </div>
            </div>
            
            <nav>
                <ul class="sidebar-nav">
                    <li class="nav-item"><a href="dashboard.php" class="nav-link active"><i class="fas fa-home"></i> Fil d'actualité</a></li>
                    <li class="nav-item"><a href="profile.php" class="nav-link"><i class="fas fa-user"></i> Mon Profil</a></li>
                    <li class="nav-item">
                        <a href="friends.php" class="nav-link">
                            <i class="fas fa-users"></i> Amis
                            <?php if ($friend_count > 0): ?>
                            <span style="margin-left: auto; background: var(--primary); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                                <?php echo $friend_count; ?>
                            </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if ($groups_exists): ?>
                    <li class="nav-item">
                        <a href="groups.php" class="nav-link">
                            <i class="fas fa-users-cog"></i> Groupes
                            <?php if ($group_count > 0): ?>
                            <span style="margin-left: auto; background: var(--info); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                                <?php echo $group_count; ?>
                            </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if ($messages_exists): ?>
                    <li class="nav-item">
                        <a href="messages.php" class="nav-link">
                            <i class="fas fa-envelope"></i> Messages
                            <?php if ($unread_messages > 0): ?>
                            <span style="margin-left: auto; background: var(--success); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                                <?php echo $unread_messages; ?>
                            </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="settings.php" class="nav-link"><i class="fas fa-cog"></i> Paramètres</a></li>
                    <li class="nav-item"><a href="../config/auth.php?action=logout" class="nav-link"><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content Area -->
        <div class="content">
            <!-- Left Column: Posts Feed -->
            <div class="posts-feed">
                <!-- Database Info -->
                <div class="card alert-info">
                    <strong><i class="fas fa-database"></i> État de la base de données :</strong>
                    <ul>
                        <li><?php echo $users_exists ? '✓ Table users' : '✗ Table users'; ?></li>
                        <li><?php echo $posts_exists ? '✓ Table posts' : '✗ Table posts'; ?></li>
                        <li><?php echo isset($post_type_exists) && $post_type_exists ? '✓ Colonne post_type' : '✗ Colonne post_type'; ?></li>
                        <li><?php echo isset($media_url_exists) && $media_url_exists ? '✓ Colonne media_url' : '✗ Colonne media_url'; ?></li>
                        <li><?php echo isset($privacy_exists) && $privacy_exists ? '✓ Colonne privacy' : '✗ Colonne privacy'; ?></li>
                        <li><?php echo $friendships_exists ? '✓ Table friendships' : '✗ Table friendships'; ?></li>
                    </ul>
                    <a href="create_tables.php" class="btn-fix"><i class="fas fa-tools"></i> Créer/mettre à jour les tables</a>
                </div>
                
                <!-- Alerts -->
                <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <!-- Statistics -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <span class="number"><?php echo $friend_count; ?></span>
                        <span class="label">Amis</span>
                    </div>
                    <div class="stat-card">
                        <span class="number"><?php echo $post_count; ?></span>
                        <span class="label">Publications</span>
                    </div>
                    <div class="stat-card">
                        <span class="number"><?php echo $group_count; ?></span>
                        <span class="label">Groupes</span>
                    </div>
                </div>
                
                <!-- Create Post Card -->
                <?php if ($posts_exists): ?>
                <div class="card">
                    <form method="POST" class="post-form" enctype="multipart/form-data" id="createPostForm">
                        <input type="hidden" name="action" value="create_post">
                        
                        <textarea name="content" placeholder="Quoi de neuf, <?php echo htmlspecialchars($username); ?> ? Partagez vos pensées..." maxlength="1000" oninput="autoResize(this)"></textarea>
                        
                        <?php if ($post_type_exists): ?>
                        <div class="options-grid">
                            <label style="font-weight: 600;"><i class="fas fa-tag"></i> Type de publication :</label>
                            <div class="option-group" id="postTypeOptions">
                                <?php foreach ($post_types as $key => $type): ?>
                                <label class="option-label <?php echo $key === 'general' ? 'selected' : ''; ?>" data-value="<?php echo $key; ?>">
                                    <input type="radio" name="post_type" value="<?php echo $key; ?>" <?php echo $key === 'general' ? 'checked' : ''; ?> hidden>
                                    <i class="<?php echo $type['icon']; ?>" style="color: <?php echo $type['color']; ?>;"></i>
                                    <span style="color: <?php echo $type['color']; ?>;"><?php echo $type['label']; ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($privacy_exists): ?>
                        <div class="options-grid">
                            <label style="font-weight: 600;"><i class="fas fa-shield-alt"></i> Confidentialité :</label>
                            <div class="option-group" id="privacyOptions">
                                <?php foreach ($privacy_levels as $key => $level): ?>
                                <label class="option-label <?php echo $key === 'public' ? 'selected' : ''; ?>" data-value="<?php echo $key; ?>">
                                    <input type="radio" name="privacy" value="<?php echo $key; ?>" <?php echo $key === 'public' ? 'checked' : ''; ?> hidden>
                                    <i class="<?php echo $level['icon']; ?>" style="color: <?php echo $level['color']; ?>;"></i>
                                    <span style="color: <?php echo $level['color']; ?>;"><?php echo $level['label']; ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($media_url_exists): ?>
                        <div class="options-grid">
                            <label style="font-weight: 600;"><i class="fas fa-paperclip"></i> Média (optionnel) :</label>
                            <div class="file-upload-area" id="fileUploadArea" onclick="document.getElementById('mediaInput').click()">
                                <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: var(--primary); margin-bottom: 1rem;"></i>
                                <p style="color: #666; margin-bottom: 0.5rem;">
                                    Glissez-déposez un fichier ou cliquez pour sélectionner
                                </p>
                                <p style="font-size: 0.8rem; color: #999;">
                                    Images, vidéos ou documents (max 10MB)
                                </p>
                                <input type="file" id="mediaInput" name="media" accept="image/*,video/*,.pdf,.doc,.docx" hidden onchange="previewMedia(event)">
                            </div>
                            <div class="media-preview" id="mediaPreview"></div>
                        </div>
                        <?php endif; ?>
                        
                        <div style="text-align: right;">
                            <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Publier</button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
                
                <!-- Posts Tabs -->
                <div class="posts-tabs">
                    <button class="tab-btn active" data-type="all" onclick="filterPosts('all')"><i class="fas fa-globe"></i> Toutes</button>
                    <button class="tab-btn" data-type="my" onclick="filterPosts('my')"><i class="fas fa-user"></i> Mes posts</button>
                    <button class="tab-btn" data-type="friend" onclick="filterPosts('friend')"><i class="fas fa-user-friends"></i> Amis</button>
                    <button class="tab-btn" data-type="other" onclick="filterPosts('other')"><i class="fas fa-users"></i> Autres</button>
                </div>
                
                <!-- Posts Feed -->
                <div id="postsContainer">
                    <?php if (!$posts_exists): ?>
                        <div class="card empty-state">
                            <i class="fas fa-exclamation-triangle"></i>
                            <h3>Table posts manquante</h3>
                            <p>La table des publications n'existe pas dans la base de données.</p>
                            <a href="create_tables.php" class="btn" style="margin-top: 1rem;"><i class="fas fa-tools"></i> Créer la table</a>
                        </div>
                    <?php elseif (empty($all_posts)): ?>
                        <div class="card empty-state">
                            <i class="fas fa-newspaper"></i>
                            <h3>Aucune publication</h3>
                            <p>Soyez le premier à publier quelque chose !</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($all_posts as $post): 
                            $post_class = isset($post['post_type']) ? $post['post_type'] : 'other_post';
                            $is_my_post = $post['user_id'] == $user_id;
                        ?>
                        <div class="post-card <?php echo $post_class; ?>">
                            <div class="post-header">
                                <div class="post-avatar">
                                    <?php if (!empty($post['profile_picture']) && file_exists("../uploads/avatars/" . $post['profile_picture'])): ?>
                                        <img src="../uploads/avatars/<?php echo htmlspecialchars($post['profile_picture']); ?>" alt="<?php echo htmlspecialchars($post['username'] ?? 'Utilisateur'); ?>">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($post['username'] ?? 'U', 0, 2)); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="post-info">
                                    <div class="post-author">
                                        <?php echo htmlspecialchars($post['username'] ?? 'Utilisateur'); ?>
                                        <?php if ($is_my_post): ?>
                                        <span class="post-tag" style="background: var(--primary);">Moi</span>
                                        <?php elseif ($post_class == 'friend_post'): ?>
                                        <span class="post-tag" style="background: var(--success);">Ami</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="post-meta">
                                        <?php echo formatRelativeTime($post['created_at'] ?? ''); ?>
                                        
                                        <?php if (isset($post['post_type']) || isset($post['privacy'])): ?>
                                        <div class="post-tags">
                                            <?php if (isset($post['post_type']) && $post['post_type'] != 'general'): 
                                                $type_info = $post_types[$post['post_type']] ?? $post_types['general'];
                                            ?>
                                            <span class="post-tag" style="background: <?php echo $type_info['color']; ?>;">
                                                <i class="<?php echo $type_info['icon']; ?>"></i>
                                                <?php echo $type_info['label']; ?>
                                            </span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($post['privacy'])): 
                                                $privacy_info = $privacy_levels[$post['privacy']] ?? $privacy_levels['public'];
                                            ?>
                                            <span class="post-tag" style="background: <?php echo $privacy_info['color']; ?>;">
                                                <i class="<?php echo $privacy_info['icon']; ?>"></i>
                                                <?php echo $privacy_info['label']; ?>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="post-content">
                                <?php echo isset($post['content']) ? nl2br(htmlspecialchars($post['content'])) : ''; ?>
                            </div>
                            
                            <?php if (!empty($post['media_url'])): 
                                $media_path = '../uploads/' . $post['media_url'];
                                $file_ext = strtolower(pathinfo($post['media_url'], PATHINFO_EXTENSION));
                                $is_image = in_array($file_ext, $allowed_extensions['images']);
                                $is_video = in_array($file_ext, $allowed_extensions['videos']);
                            ?>
                            <div class="post-media">
                                <?php if ($is_image): ?>
                                <a href="<?php echo $media_path; ?>" target="_blank">
                                    <img src="<?php echo $media_path; ?>" alt="Média">
                                </a>
                                <?php elseif ($is_video): ?>
                                <video controls>
                                    <source src="<?php echo $media_path; ?>" type="video/<?php echo $file_ext; ?>">
                                    Votre navigateur ne supporte pas la lecture vidéo.
                                </video>
                                <?php else: ?>
                                <div class="media-file">
                                    <i class="<?php echo getFileIcon($file_ext); ?>" style="font-size: 2rem; color: var(--primary);"></i>
                                    <div style="flex: 1;">
                                        <div style="font-weight: 600;">Document joint</div>
                                        <div style="font-size: 0.9rem; color: #666;"><?php echo basename($post['media_url']); ?></div>
                                    </div>
                                    <a href="<?php echo $media_path; ?>" target="_blank" class="btn-sm primary"><i class="fas fa-download"></i> Télécharger</a>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($like_count_exists || $comment_count_exists): ?>
                            <div style="display: flex; gap: 1.5rem; padding: 0.75rem 0; border-top: 1px solid #eee; border-bottom: 1px solid #eee;">
                                <?php if ($like_count_exists && isset($post['like_count'])): ?>
                                <div style="display: flex; align-items: center; gap: 0.5rem; color: #666;">
                                    <i class="fas fa-heart" style="color: #dc3545;"></i>
                                    <span><?php echo intval($post['like_count']); ?> j'aime</span>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($comment_count_exists && isset($post['comment_count'])): ?>
                                <div style="display: flex; align-items: center; gap: 0.5rem; color: #666;">
                                    <i class="fas fa-comment" style="color: #17a2b8;"></i>
                                    <span><?php echo intval($post['comment_count']); ?> commentaires</span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="post-actions">
                                <?php if ($likes_exists): ?>
                                <button class="action-btn" onclick="likePost(<?php echo $post['id']; ?>)">
                                    <i class="fas fa-heart"></i> J'aime
                                </button>
                                <?php endif; ?>
                                
                                <?php if ($comments_exists): ?>
                                <button class="action-btn" onclick="toggleComments(<?php echo $post['id']; ?>)">
                                    <i class="fas fa-comment"></i> Commenter
                                </button>
                                <?php endif; ?>
                                
                                <?php if ($is_my_post): ?>
                                <button class="action-btn" style="margin-left: auto;">
                                    <i class="fas fa-edit"></i> Modifier
                                </button>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($comments_exists): ?>
                            <div id="comments-<?php echo $post['id']; ?>" class="comments-section" style="display: none;">
                                <form method="POST" class="comment-form">
                                    <input type="hidden" name="action" value="add_comment">
                                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                    <input type="text" name="comment_content" placeholder="Écrire un commentaire..." required>
                                    <button type="submit" class="btn-sm primary">Envoyer</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column: Widgets -->
            <div class="sidebar-content">
                <!-- Friend Suggestions -->
                <?php if (!empty($friend_suggestions)): ?>
                <div class="widget">
                    <h3 class="widget-title"><i class="fas fa-user-plus"></i> Suggestions d'amis</h3>
                    <ul class="suggestion-list">
                        <?php foreach ($friend_suggestions as $suggestion): ?>
                        <li class="suggestion-item">
                            <div class="suggestion-avatar">
                                <?php if (!empty($suggestion['profile_picture']) && file_exists("../uploads/avatars/" . $suggestion['profile_picture'])): ?>
                                    <img src="../uploads/avatars/<?php echo htmlspecialchars($suggestion['profile_picture']); ?>" alt="<?php echo htmlspecialchars($suggestion['username']); ?>">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($suggestion['username'], 0, 2)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="suggestion-info">
                                <div class="suggestion-name"><?php echo htmlspecialchars($suggestion['username']); ?></div>
                            </div>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="send_friend_request">
                                <input type="hidden" name="friend_id" value="<?php echo $suggestion['id']; ?>">
                                <button type="submit" class="btn-sm"><i class="fas fa-user-plus"></i></button>
                            </form>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <!-- Group Suggestions -->
                <?php if (!empty($group_suggestions)): ?>
                <div class="widget">
                    <h3 class="widget-title"><i class="fas fa-users"></i> Groupes suggérés</h3>
                    <ul class="group-list">
                        <?php foreach ($group_suggestions as $group): ?>
                        <li class="group-item">
                            <div class="group-avatar">
                                <?php if (!empty($group['group_image']) && file_exists("../uploads/groups/" . $group['group_image'])): ?>
                                    <img src="../uploads/groups/<?php echo htmlspecialchars($group['group_image']); ?>" alt="<?php echo htmlspecialchars($group['name']); ?>">
                                <?php else: ?>
                                    <i class="fas fa-users"></i>
                                <?php endif; ?>
                            </div>
                            <div class="group-info">
                                <div class="group-name"><?php echo htmlspecialchars($group['name']); ?></div>
                            </div>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="join_group">
                                <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                                <button type="submit" class="btn-sm primary">Rejoindre</button>
                            </form>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <!-- My Groups -->
                <?php if (!empty($my_groups)): ?>
                <div class="widget">
                    <h3 class="widget-title"><i class="fas fa-star"></i> Mes groupes</h3>
                    <ul class="group-list">
                        <?php foreach ($my_groups as $group): ?>
                        <li class="group-item" onclick="window.location.href='group.php?id=<?php echo $group['id']; ?>'" style="cursor: pointer;">
                            <div class="group-avatar">
                                <?php if (!empty($group['group_image']) && file_exists("../uploads/groups/" . $group['group_image'])): ?>
                                    <img src="../uploads/groups/<?php echo htmlspecialchars($group['group_image']); ?>" alt="<?php echo htmlspecialchars($group['name']); ?>">
                                <?php else: ?>
                                    <i class="fas fa-users"></i>
                                <?php endif; ?>
                            </div>
                            <div class="group-info">
                                <div class="group-name"><?php echo htmlspecialchars($group['name']); ?></div>
                                <?php if (!empty($group['description'])): ?>
                                <div class="group-meta"><?php echo substr(htmlspecialchars($group['description']), 0, 50); ?>...</div>
                                <?php endif; ?>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <!-- Quick Links -->
                <div class="widget">
                    <h3 class="widget-title"><i class="fas fa-bolt"></i> Actions rapides</h3>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem;">
                        <a href="profile.php" class="btn-sm" style="text-align: center; text-decoration: none; padding: 0.5rem;">
                            <i class="fas fa-user-edit"></i> Modifier profil
                        </a>
                        <a href="friends.php" class="btn-sm" style="text-align: center; text-decoration: none; padding: 0.5rem;">
                            <i class="fas fa-search"></i> Trouver amis
                        </a>
                        <a href="settings.php" class="btn-sm" style="text-align: center; text-decoration: none; padding: 0.5rem;">
                            <i class="fas fa-cog"></i> Paramètres
                        </a>
                        <a href="create_tables.php" class="btn-sm" style="text-align: center; text-decoration: none; padding: 0.5rem;">
                            <i class="fas fa-database"></i> Bases de données
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer style="background: white; padding: 2rem; text-align: center; border-top: 1px solid #eee; margin-top: 2rem;">
        <div style="color: #666; font-size: 0.9rem;">
            <p>© 2025 SocialSphere. Tous droits réservés.</p>
        </div>
    </footer>
    
    <script>
        // =========== FONCTIONS UTILITAIRES ===========
        function likePost(postId) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const action = document.createElement('input');
            action.type = 'hidden';
            action.name = 'action';
            action.value = 'like_post';
            form.appendChild(action);
            
            const postIdInput = document.createElement('input');
            postIdInput.type = 'hidden';
            postIdInput.name = 'post_id';
            postIdInput.value = postId;
            form.appendChild(postIdInput);
            
            document.body.appendChild(form);
            form.submit();
        }
        
        function toggleComments(postId) {
            const comments = document.getElementById(`comments-${postId}`);
            if (comments) {
                comments.style.display = comments.style.display === 'none' ? 'block' : 'none';
            }
        }
        
        function filterPosts(type) {
            const posts = document.querySelectorAll('.post-card');
            const tabButtons = document.querySelectorAll('.tab-btn');
            
            tabButtons.forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.type === type) {
                    btn.classList.add('active');
                }
            });
            
            posts.forEach(post => {
                if (type === 'all') {
                    post.style.display = 'block';
                } else {
                    post.style.display = post.classList.contains(`${type}-post`) ? 'block' : 'none';
                }
            });
            
            const url = new URL(window.location);
            url.searchParams.set('filter', type);
            window.history.pushState({}, '', url);
        }
        
        function autoResize(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        }
        
        // =========== GESTION DES OPTIONS ===========
        document.querySelectorAll('.option-group').forEach(group => {
            group.addEventListener('click', (e) => {
                if (e.target.closest('.option-label')) {
                    const label = e.target.closest('.option-label');
                    group.querySelectorAll('.option-label').forEach(l => l.classList.remove('selected'));
                    label.classList.add('selected');
                    label.querySelector('input').checked = true;
                }
            });
        });
        
        // =========== GESTION DES FICHIERS ===========
        const fileUploadArea = document.getElementById('fileUploadArea');
        const mediaInput = document.getElementById('mediaInput');
        const mediaPreview = document.getElementById('mediaPreview');
        
        function previewMedia(event) {
            const file = event.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                let previewHTML = '';
                const fileType = file.type.split('/')[0];
                
                if (fileType === 'image') {
                    previewHTML = `<img src="${e.target.result}" alt="Preview" style="max-width: 100%; max-height: 300px; border-radius: 8px;">`;
                } else if (fileType === 'video') {
                    previewHTML = `<video controls style="max-width: 100%; max-height: 300px; border-radius: 8px;">
                        <source src="${e.target.result}" type="${file.type}">
                        Votre navigateur ne supporte pas la vidéo.
                    </video>`;
                } else {
                    previewHTML = `
                        <div style="padding: 1rem; background: #f8f9fa; border-radius: 8px; text-align: center;">
                            <i class="fas fa-file" style="font-size: 3rem; color: var(--primary);"></i>
                            <div style="margin-top: 0.5rem; font-weight: 600;">${file.name}</div>
                            <div style="color: #666; font-size: 0.9rem;">${(file.size / 1024 / 1024).toFixed(2)} MB</div>
                        </div>
                    `;
                }
                
                mediaPreview.innerHTML = `
                    ${previewHTML}
                    <button type="button" onclick="removeMedia()" style="margin-top: 0.5rem; background: var(--danger); color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer;">
                        <i class="fas fa-times"></i> Supprimer
                    </button>
                `;
                mediaPreview.style.display = 'block';
            };
            
            reader.readAsDataURL(file);
        }
        
        function removeMedia() {
            mediaInput.value = '';
            mediaPreview.style.display = 'none';
            mediaPreview.innerHTML = '';
        }
        
        // Drag and drop
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            fileUploadArea.classList.add('drag-over');
        }
        
        function unhighlight() {
            fileUploadArea.classList.remove('drag-over');
        }
        
        fileUploadArea.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length) {
                mediaInput.files = files;
                const event = new Event('change', { bubbles: true });
                mediaInput.dispatchEvent(event);
            }
        }
        
        // =========== INITIALISATION ===========
        document.addEventListener('DOMContentLoaded', function() {
            // Appliquer le filtre depuis l'URL
            const urlParams = new URLSearchParams(window.location.search);
            const filter = urlParams.get('filter');
            if (filter) {
                filterPosts(filter);
            }
            
            // Auto-hide alerts
            setTimeout(() => {
                document.querySelectorAll('.alert').forEach(alert => {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                });
            }, 5000);
        });
    </script>
</body>
</html>