<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Récupérer l'ID de l'utilisateur à afficher
$view_user_id = $_GET['id'] ?? 0;

if ($view_user_id == 0) {
    header('Location: profile.php');
    exit();
}

// Récupérer les informations de l'utilisateur à afficher
try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COUNT(DISTINCT f.id) as friend_count,
               COUNT(DISTINCT p.id) as post_count,
               COUNT(DISTINCT g.id) as group_count
        FROM users u
        LEFT JOIN friendships f ON (f.user_id1 = u.id OR f.user_id2 = u.id) AND f.status = 'accepted'
        LEFT JOIN posts p ON p.user_id = u.id
        LEFT JOIN group_members gm ON gm.user_id = u.id
        LEFT JOIN groups g ON g.id = gm.group_id
        WHERE u.id = ?
        GROUP BY u.id
    ");
    $stmt->execute([$view_user_id]);
    $view_user = $stmt->fetch();
    
    if (!$view_user) {
        header('Location: friends.php?error=user_not_found');
        exit();
    }
    
    // Vérifier si c'est un ami
    $stmt = $pdo->prepare("
        SELECT status 
        FROM friendships 
        WHERE (user_id1 = ? AND user_id2 = ?) 
           OR (user_id1 = ? AND user_id2 = ?)
    ");
    $stmt->execute([$user_id, $view_user_id, $view_user_id, $user_id]);
    $friendship = $stmt->fetch();
    
    // Récupérer les publications de l'utilisateur
    $stmt = $pdo->prepare("
        SELECT p.*, 
               COUNT(DISTINCT l.id) as like_count,
               COUNT(DISTINCT c.id) as comment_count
        FROM posts p
        LEFT JOIN likes l ON p.id = l.post_id
        LEFT JOIN comments c ON p.id = c.post_id
        WHERE p.user_id = ?
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$view_user_id]);
    $posts = $stmt->fetchAll();
    
    // Récupérer les amis communs
    $stmt = $pdo->prepare("
        SELECT u.*
        FROM users u
        WHERE u.id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        AND u.id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        AND u.id != ?
        ORDER BY u.username
        LIMIT 12
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $view_user_id, $view_user_id, $view_user_id, $user_id]);
    $mutual_friends = $stmt->fetchAll();
    
    // Récupérer les amis de l'utilisateur
    $stmt = $pdo->prepare("
        SELECT u.*
        FROM users u
        WHERE u.id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        AND u.id != ?
        ORDER BY u.username
        LIMIT 12
    ");
    $stmt->execute([$view_user_id, $view_user_id, $view_user_id, $user_id]);
    $friends = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}

// Gérer les actions d'amitié
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        try {
            if ($action === 'send_request') {
                // Envoyer une demande d'amitié
                $user_id1 = min($user_id, $view_user_id);
                $user_id2 = max($user_id, $view_user_id);
                
                $stmt = $pdo->prepare("
                    INSERT INTO friendships (user_id1, user_id2, status, created_at)
                    VALUES (?, ?, 'pending', NOW())
                    ON DUPLICATE KEY UPDATE status = 'pending'
                ");
                $stmt->execute([$user_id1, $user_id2]);
                
            } elseif ($action === 'cancel_request') {
                // Annuler la demande
                $user_id1 = min($user_id, $view_user_id);
                $user_id2 = max($user_id, $view_user_id);
                
                $stmt = $pdo->prepare("DELETE FROM friendships WHERE user_id1 = ? AND user_id2 = ? AND status = 'pending'");
                $stmt->execute([$user_id1, $user_id2]);
                
            } elseif ($action === 'remove_friend') {
                // Retirer un ami
                $user_id1 = min($user_id, $view_user_id);
                $user_id2 = max($user_id, $view_user_id);
                
                $stmt = $pdo->prepare("DELETE FROM friendships WHERE user_id1 = ? AND user_id2 = ?");
                $stmt->execute([$user_id1, $user_id2]);
                
            } elseif ($action === 'accept_request') {
                // Accepter une demande
                $user_id1 = min($user_id, $view_user_id);
                $user_id2 = max($user_id, $view_user_id);
                
                $stmt = $pdo->prepare("
                    UPDATE friendships 
                    SET status = 'accepted', updated_at = NOW()
                    WHERE user_id1 = ? AND user_id2 = ? AND status = 'pending'
                ");
                $stmt->execute([$user_id1, $user_id2]);
            }
            
            // Rediriger pour éviter la resoumission
            header("Location: profile_view.php?id=" . $view_user_id);
            exit();
            
        } catch (PDOException $e) {
            $error = "Erreur : " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($view_user['first_name'] ?? $view_user['username']) . ' - Profil'; ?> - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: #666;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            transition: all 0.3s;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: #f0f0ff;
            color: var(--primary);
        }
        
        .profile-header {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .cover-photo {
            height: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: relative;
        }
        
        .profile-info {
            padding: 30px;
            position: relative;
            margin-top: -80px;
        }
        
        .profile-avatar {
            width: 160px;
            height: 160px;
            border-radius: 50%;
            border: 5px solid white;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-name {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .profile-username {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 15px;
        }
        
        .profile-stats {
            display: flex;
            gap: 30px;
            margin: 20px 0;
        }
        
        .stat {
            text-align: center;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        
        .stat:hover {
            background: #f5f5f5;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            display: block;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .profile-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning);
            color: #333;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .friends-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        
        .friend-card {
            text-align: center;
            padding: 15px;
            border-radius: 8px;
            background: #f8f9fa;
            transition: all 0.3s;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        
        .friend-card:hover {
            background: #f0f0ff;
            transform: translateY(-5px);
        }
        
        .friend-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin: 0 auto 10px;
            overflow: hidden;
        }
        
        .friend-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .friend-name {
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 5px;
        }
        
        .friend-username {
            color: #666;
            font-size: 0.8rem;
        }
        
        .post-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .post-content {
            margin: 15px 0;
            line-height: 1.6;
        }
        
        .post-meta {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .post-actions {
            display: flex;
            gap: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #666;
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            background: #f5f5f5;
            color: var(--primary);
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #e8f5e9;
            color: var(--success);
            border: 1px solid #c8e6c9;
        }
        
        .alert-error {
            background: #ffebee;
            color: var(--danger);
            border: 1px solid #ffcdd2;
        }
        
        .message-btn {
            text-decoration: none;
            display: inline-block;
        }
        
        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .friends-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .profile-actions {
                flex-direction: column;
            }
            
            .profile-actions .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">SocialSphere</div>
            <div class="nav-links">
                <a href="dashboard.php"><i class="fas fa-home"></i> Accueil</a>
                <a href="profile.php"><i class="fas fa-user"></i> Mon Profil</a>
                <a href="friends.php"><i class="fas fa-users"></i> Amis</a>
                <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
                <a href="../config/auth.php?action=logout"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
        
        <!-- Messages d'alerte -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="cover-photo" id="coverPhoto" 
                style="<?php 
                        if (isset($view_user['cover_photo']) && !empty($view_user['cover_photo']) && file_exists("../uploads/covers/" . $view_user['cover_photo'])) {
                            echo "background: url('../uploads/covers/" . htmlspecialchars($view_user['cover_photo']) . "') center/cover no-repeat;";
                        } else {
                            echo "background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);";
                        }
                        ?> height: 250px; position: relative;">
                <!-- Couverture -->
            </div>
            <div class="profile-info">
                <div class="profile-avatar">
                    <?php if (isset($view_user['profile_picture']) && !empty($view_user['profile_picture']) && file_exists("../uploads/avatars/" . $view_user['profile_picture'])): ?>
                        <img src="../uploads/avatars/<?php echo htmlspecialchars($view_user['profile_picture']); ?>" 
                            alt="<?php echo htmlspecialchars($view_user['username']); ?>">
                    <?php else: ?>
                        <?php 
                        $display_name = !empty($view_user['first_name']) ? $view_user['first_name'] : $view_user['username'];
                        echo strtoupper(substr($display_name, 0, 1)); 
                        ?>
                    <?php endif; ?>
                </div>
                <h1 class="profile-name">
                    <?php 
                    if (!empty($view_user['first_name'])) {
                        echo htmlspecialchars($view_user['first_name'] . ' ' . $view_user['last_name']);
                    } else {
                        echo htmlspecialchars($view_user['username']);
                    }
                    ?>
                </h1>
                <div class="profile-username">
                    <i class="fas fa-at"></i> @<?php echo htmlspecialchars($view_user['username']); ?>
                </div>
                
                <?php if (!empty($view_user['bio'])): ?>
                <p style="color: #666; margin-bottom: 15px;"><?php echo htmlspecialchars($view_user['bio']); ?></p>
                <?php endif; ?>
                
                <?php if (!empty($view_user['location'])): ?>
                <p style="color: #666; margin-bottom: 10px;">
                    <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($view_user['location']); ?>
                </p>
                <?php endif; ?>
                
                <div class="profile-stats">
                    <div class="stat" onclick="window.location.href='friends.php?id=<?php echo $view_user_id; ?>'">
                        <span class="stat-number"><?php echo $view_user['friend_count'] ?? 0; ?></span>
                        <span class="stat-label">Amis</span>
                    </div>
                    <div class="stat" onclick="window.location.href='#posts'">
                        <span class="stat-number"><?php echo $view_user['post_count'] ?? 0; ?></span>
                        <span class="stat-label">Publications</span>
                    </div>
                    <div class="stat" onclick="window.location.href='groups.php?user=<?php echo $view_user_id; ?>'">
                        <span class="stat-number"><?php echo $view_user['group_count'] ?? 0; ?></span>
                        <span class="stat-label">Groupes</span>
                    </div>
                </div>
                
                <div class="profile-actions">
                    <?php if ($friendship): ?>
                        <?php if ($friendship['status'] === 'accepted'): ?>
                            <!-- Amis -->
                            <form method="POST" style="margin: 0;" onsubmit="return confirm('Êtes-vous sûr de vouloir retirer cet ami ?');">
                                <input type="hidden" name="action" value="remove_friend">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-user-minus"></i> Retirer
                                </button>
                            </form>
                            <a href="messages.php?user_id=<?php echo $view_user_id; ?>" class="btn btn-primary message-btn">
                                <i class="fas fa-envelope"></i> Message
                            </a>
                        <?php elseif ($friendship['status'] === 'pending'): ?>
                            <!-- Demande en attente -->
                            <?php 
                            // Déterminer qui a envoyé la demande
                            if (isset($pdo)) {
                                $stmt = $pdo->prepare("
                                    SELECT user_id1, user_id2 
                                    FROM friendships 
                                    WHERE ((user_id1 = ? AND user_id2 = ?) OR (user_id1 = ? AND user_id2 = ?)) 
                                    AND status = 'pending'
                                ");
                                $stmt->execute([$user_id, $view_user_id, $view_user_id, $user_id]);
                                $pending_request = $stmt->fetch();
                                
                                if ($pending_request && $pending_request['user_id1'] == $view_user_id): ?>
                                    <!-- Demande reçue -->
                                    <form method="POST" style="margin: 0;">
                                        <input type="hidden" name="action" value="accept_request">
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-check"></i> Accepter
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php } ?>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="action" value="cancel_request">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-times"></i> Annuler
                                </button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <!-- Pas d'amitié -->
                        <form method="POST" style="margin: 0;">
                            <input type="hidden" name="action" value="send_request">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-user-plus"></i> Ajouter
                            </button>
                        </form>
                    <?php endif; ?>
                    
                    <a href="dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Retour
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Column: Posts -->
            <div>
                <div class="card" id="posts">
                    <h2 class="card-title">Publications</h2>
                    
                    <?php if (!isset($posts) || empty($posts)): ?>
                        <div style="text-align: center; padding: 40px;">
                            <i class="fas fa-newspaper" style="font-size: 3rem; color: #ddd; margin-bottom: 15px;"></i>
                            <h3 style="color: #666; margin-bottom: 10px;">Aucune publication</h3>
                            <p style="color: #999;">Cet utilisateur n'a pas encore publié de contenu.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($posts as $post): ?>
                        <div class="post-card">
                            <div class="post-meta">
                                <span>
                                    <i class="far fa-clock"></i> 
                                    <?php 
                                    if (isset($post['created_at'])) {
                                        $now = new DateTime();
                                        $postTime = new DateTime($post['created_at']);
                                        $interval = $now->diff($postTime);
                                        
                                        if ($interval->y > 0) echo "il y a " . $interval->y . " an" . ($interval->y > 1 ? "s" : "");
                                        elseif ($interval->m > 0) echo "il y a " . $interval->m . " mois";
                                        elseif ($interval->d > 0) echo "il y a " . $interval->d . " jour" . ($interval->d > 1 ? "s" : "");
                                        elseif ($interval->h > 0) echo "il y a " . $interval->h . " heure" . ($interval->h > 1 ? "s" : "");
                                        elseif ($interval->i > 0) echo "il y a " . $interval->i . " minute" . ($interval->i > 1 ? "s" : "");
                                        else echo "à l'instant";
                                    }
                                    ?>
                                </span>
                            </div>
                            <div class="post-content">
                                <?php echo isset($post['content']) ? nl2br(htmlspecialchars($post['content'])) : ''; ?>
                            </div>
                            <div class="post-actions">
                                <button class="action-btn">
                                    <i class="fas fa-heart"></i>
                                    <span><?php echo $post['like_count'] ?? 0; ?></span>
                                </button>
                                <button class="action-btn">
                                    <i class="fas fa-comment"></i>
                                    <span><?php echo $post['comment_count'] ?? 0; ?></span>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column: Friends & Info -->
            <div>
                <!-- Amis communs -->
                <?php if (!empty($mutual_friends) && isset($friendship) && $friendship['status'] === 'accepted'): ?>
                <div class="card">
                    <h2 class="card-title">
                        <i class="fas fa-user-friends"></i> Amis communs
                        <span style="font-size: 0.9rem; color: #666; font-weight: normal;">
                            (<?php echo count($mutual_friends); ?>)
                        </span>
                    </h2>
                    
                    <div class="friends-grid">
                        <?php foreach ($mutual_friends as $friend): ?>
                        <a href="profile_view.php?id=<?php echo $friend['id']; ?>" class="friend-card">
                            <div class="friend-avatar">
                                <?php if (isset($friend['profile_picture']) && !empty($friend['profile_picture']) && file_exists("../uploads/avatars/" . $friend['profile_picture'])): ?>
                                    <img src="../uploads/avatars/<?php echo htmlspecialchars($friend['profile_picture']); ?>" 
                                         alt="<?php echo htmlspecialchars($friend['username']); ?>">
                                <?php else: ?>
                                    <?php echo strtoupper(substr($friend['username'], 0, 2)); ?>
                                <?php endif; ?>
                            </div>
                            <div class="friend-name">
                                <?php 
                                if (!empty($friend['first_name'])) {
                                    echo htmlspecialchars($friend['first_name']);
                                } else {
                                    echo htmlspecialchars($friend['username']);
                                }
                                ?>
                            </div>
                            <div class="friend-username">
                                @<?php echo htmlspecialchars($friend['username']); ?>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Amis -->
                <div class="card">
                    <h2 class="card-title">
                        <i class="fas fa-users"></i> Amis
                        <span style="font-size: 0.9rem; color: #666; font-weight: normal;">
                            (<?php echo isset($view_user['friend_count']) ? $view_user['friend_count'] : 0; ?>)
                        </span>
                    </h2>
                    
                    <?php if (!isset($friends) || empty($friends)): ?>
                        <div style="text-align: center; padding: 20px; color: #666;">
                            <i class="fas fa-user-friends" style="font-size: 2rem; margin-bottom: 10px;"></i>
                            <p>Aucun ami</p>
                        </div>
                    <?php else: ?>
                        <div class="friends-grid">
                            <?php foreach ($friends as $friend): ?>
                            <a href="profile_view.php?id=<?php echo $friend['id']; ?>" class="friend-card">
                                <div class="friend-avatar">
                                    <?php if (isset($friend['profile_picture']) && !empty($friend['profile_picture']) && file_exists("../uploads/avatars/" . $friend['profile_picture'])): ?>
                                        <img src="../uploads/avatars/<?php echo htmlspecialchars($friend['profile_picture']); ?>" 
                                             alt="<?php echo htmlspecialchars($friend['username']); ?>">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($friend['username'], 0, 2)); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="friend-name">
                                    <?php 
                                    if (!empty($friend['first_name'])) {
                                        echo htmlspecialchars($friend['first_name']);
                                    } else {
                                        echo htmlspecialchars($friend['username']);
                                    }
                                    ?>
                                </div>
                                <div class="friend-username">
                                    @<?php echo htmlspecialchars($friend['username']); ?>
                                </div>
                            </a>
                            <?php endforeach; ?>
                        </div>
                        <?php if (isset($view_user['friend_count']) && $view_user['friend_count'] > 12): ?>
                        <div style="text-align: center; margin-top: 15px;">
                            <a href="friends.php?id=<?php echo $view_user_id; ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-right"></i> Voir tous
                            </a>
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <!-- About Card -->
                <div class="card">
                    <h2 class="card-title">À propos</h2>
                    <div style="line-height: 1.8;">
                        <?php if (!empty($view_user['bio'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-quote-left"></i> Bio :</strong><br>
                            <?php echo htmlspecialchars($view_user['bio']); ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($view_user['location'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-map-marker-alt"></i> Localisation :</strong><br>
                            <?php echo htmlspecialchars($view_user['location']); ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($view_user['website'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-globe"></i> Site web :</strong><br>
                            <a href="<?php echo htmlspecialchars($view_user['website']); ?>" target="_blank" style="color: var(--primary);">
                                <?php echo htmlspecialchars($view_user['website']); ?>
                            </a>
                        </p>
                        <?php endif; ?>
                        
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-user-plus"></i> Membre depuis :</strong><br>
                            <?php echo isset($view_user['created_at']) ? date('d/m/Y', strtotime($view_user['created_at'])) : 'Date inconnue'; ?>
                        </p>
                        
                        <?php if (!empty($view_user['last_login'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-sign-in-alt"></i> Dernière connexion :</strong><br>
                            <?php 
                            $lastLogin = new DateTime($view_user['last_login']);
                            $now = new DateTime();
                            $interval = $now->diff($lastLogin);
                            
                            if ($interval->days == 0) {
                                echo "Aujourd'hui à " . date('H:i', strtotime($view_user['last_login']));
                            } elseif ($interval->days == 1) {
                                echo "Hier à " . date('H:i', strtotime($view_user['last_login']));
                            } else {
                                echo "Il y a " . $interval->days . " jours";
                            }
                            ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Fonction pour confirmer la suppression d'ami
        function confirmRemove() {
            return confirm("Êtes-vous sûr de vouloir retirer cet ami ?");
        }
    </script>
</body>
</html>