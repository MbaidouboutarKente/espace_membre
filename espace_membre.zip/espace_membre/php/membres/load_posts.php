<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    exit();
}

$user_id = $_SESSION['user_id'];
$page = $_GET['page'] ?? 1;
$offset = ($page - 1) * 10;

try {
    $stmt = $pdo->prepare("
        SELECT p.*, u.username, u.profile_picture,
               COUNT(DISTINCT l.id) as like_count,
               COUNT(DISTINCT c.id) as comment_count,
               EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id = p.id AND l2.user_id = ?) as liked_by_me
        FROM posts p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN likes l ON p.id = l.post_id
        LEFT JOIN comments c ON p.id = c.post_id
        WHERE p.user_id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        AND (p.deleted_at IS NULL OR p.deleted_at = '')
        AND (p.privacy = 'public' OR p.privacy = 'friends')
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT 10 OFFSET ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $offset]);
    $posts = $stmt->fetchAll();
    
    foreach ($posts as $post) {
        ?>
        <div class="post-card">
            <div class="post-header">
                <div class="post-avatar">
                    <?php echo strtoupper(substr($post['username'], 0, 2)); ?>
                </div>
                <div class="post-info">
                    <div class="post-author"><?php echo htmlspecialchars($post['username']); ?></div>
                    <div class="post-meta">
                        <?php 
                        $now = new DateTime();
                        $postTime = new DateTime($post['created_at']);
                        $interval = $now->diff($postTime);
                        
                        if ($interval->y > 0) echo "il y a " . $interval->y . " an" . ($interval->y > 1 ? "s" : "");
                        elseif ($interval->m > 0) echo "il y a " . $interval->m . " mois";
                        elseif ($interval->d > 0) echo "il y a " . $interval->d . " jour" . ($interval->d > 1 ? "s" : "");
                        elseif ($interval->h > 0) echo "il y a " . $interval->h . " heure" . ($interval->h > 1 ? "s" : "");
                        elseif ($interval->i > 0) echo "il y a " . $interval->i . " minute" . ($interval->i > 1 ? "s" : "");
                        else echo "à l'instant";
                        ?>
                    </div>
                </div>
            </div>
            
            <div class="post-content">
                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            </div>
            
            <div class="post-actions">
                <button class="action-btn <?php echo $post['liked_by_me'] ? 'liked' : ''; ?>" 
                        onclick="likePost(<?php echo $post['id']; ?>)">
                    <i class="fas fa-heart"></i>
                    <span><?php echo $post['like_count']; ?></span>
                </button>
                
                <button class="action-btn" onclick="toggleComments(<?php echo $post['id']; ?>)">
                    <i class="fas fa-comment"></i>
                    <span><?php echo $post['comment_count']; ?></span>
                </button>
            </div>
        </div>
        <?php
    }
} catch (PDOException $e) {
    // Silence is golden
}
?>