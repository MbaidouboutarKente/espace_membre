<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../config/auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$error = null;
$success = null;

// Récupérer les informations de l'utilisateur
try {
    // Modifier la requête pour récupérer l'utilisateur (ligne ~25)
    $stmt = $pdo->prepare("
        SELECT u.*, 
            COUNT(DISTINCT f.id) as friend_count,
            COUNT(DISTINCT p.id) as post_count,
            COUNT(DISTINCT g.id) as group_count
        FROM users u
        LEFT JOIN friendships f ON (f.user_id1 = u.id OR f.user_id2 = u.id) AND f.status = 'accepted'
        LEFT JOIN posts p ON p.user_id = u.id
        LEFT JOIN group_members gm ON gm.user_id = u.id
        LEFT JOIN groups g ON g.id = gm.group_id
        WHERE u.id = ?
        GROUP BY u.id
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Récupérer les publications de l'utilisateur
    $stmt = $pdo->prepare("
        SELECT p.*, 
               COUNT(DISTINCT l.id) as like_count,
               COUNT(DISTINCT c.id) as comment_count
        FROM posts p
        LEFT JOIN likes l ON p.id = l.post_id
        LEFT JOIN comments c ON p.id = c.post_id
        WHERE p.user_id = ?
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$user_id]);
    $posts = $stmt->fetchAll();
    
    // Récupérer les amis
    $stmt = $pdo->prepare("
        SELECT u.*
        FROM users u
        WHERE u.id IN (
            SELECT CASE 
                WHEN f.user_id1 = ? THEN f.user_id2 
                ELSE f.user_id1 
            END as friend_id
            FROM friendships f
            WHERE (f.user_id1 = ? OR f.user_id2 = ?) 
            AND f.status = 'accepted'
        )
        ORDER BY u.username
        LIMIT 12
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $friends = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}

// Mettre à jour le profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier le type d'action
    $action = $_POST['action'] ?? 'update_profile';
    
    if ($action === 'update_profile') {
        // Mettre à jour les informations de base
        $first_name = trim($_POST['first_name'] ?? '');
        $last_name = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $website = trim($_POST['website'] ?? '');
        
        // Validation
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "L'adresse email n'est pas valide.";
        } else {
            try {
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, bio = ?, location = ?, website = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$first_name, $last_name, $email, $bio, $location, $website, $user_id]);
                
                // Mettre à jour l'email dans la session si modifié
                if ($email !== $user['email']) {
                    $_SESSION['email'] = $email;
                }
                
                $success = "Profil mis à jour avec succès !";
                $_SESSION['success'] = $success;
                header("Location: profile.php");
                exit();
            } catch (PDOException $e) {
                $error = "Erreur lors de la mise à jour : " . $e->getMessage();
            }
        }
        
    } elseif ($action === 'update_password') {
        // Changer le mot de passe
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = "Tous les champs sont obligatoires.";
        } elseif ($new_password !== $confirm_password) {
            $error = "Les nouveaux mots de passe ne correspondent pas.";
        } elseif (strlen($new_password) < 6) {
            $error = "Le nouveau mot de passe doit contenir au moins 6 caractères.";
        } else {
            // Vérifier le mot de passe actuel
            try {
                $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user_data = $stmt->fetch();
                
                if (password_verify($current_password, $user_data['password'])) {
                    // Mettre à jour le mot de passe
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$hashed_password, $user_id]);
                    
                    $success = "Mot de passe changé avec succès !";
                    $_SESSION['success'] = $success;
                    header("Location: profile.php");
                    exit();
                } else {
                    $error = "Mot de passe actuel incorrect.";
                }
            } catch (PDOException $e) {
                $error = "Erreur lors du changement de mot de passe : " . $e->getMessage();
            }
        }
        
    } elseif ($action === 'upload_avatar') {
        // Uploader une photo de profil
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            $file_type = $_FILES['avatar']['type'];
            $file_size = $_FILES['avatar']['size'];
            $temp_file = $_FILES['avatar']['tmp_name'];
            
            // Validation
            if (!in_array($file_type, $allowed_types)) {
                $error = "Type de fichier non autorisé. Formats acceptés : JPG, PNG, GIF, WebP.";
            } elseif ($file_size > $max_size) {
                $error = "L'image est trop grande. Taille maximum : 5MB.";
            } else {
                // Créer le dossier uploads s'il n'existe pas
                $upload_dir = '../uploads/avatars/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Générer un nom de fichier unique
                $file_extension = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
                $new_filename = 'avatar_' . $user_id . '_' . time() . '.' . $file_extension;
                $destination = $upload_dir . $new_filename;
                
                // Redimensionner et uploader l'image
                if (move_uploaded_file($temp_file, $destination)) {
                    // Redimensionner l'image si nécessaire
                    list($width, $height) = getimagesize($destination);
                    $new_width = 300;
                    $new_height = 300;
                    
                    // Créer une nouvelle image
                    $new_image = imagecreatetruecolor($new_width, $new_height);
                    
                    // Charger l'image originale selon son type
                    switch($file_type) {
                        case 'image/jpeg':
                        case 'image/jpg':
                            $source = imagecreatefromjpeg($destination);
                            break;
                        case 'image/png':
                            $source = imagecreatefrompng($destination);
                            break;
                        case 'image/gif':
                            $source = imagecreatefromgif($destination);
                            break;
                        case 'image/webp':
                            $source = imagecreatefromwebp($destination);
                            break;
                        default:
                            $source = imagecreatefromjpeg($destination);
                    }
                    
                    // Redimensionner
                    imagecopyresampled($new_image, $source, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                    
                    // Sauvegarder l'image redimensionnée
                    switch($file_type) {
                        case 'image/jpeg':
                        case 'image/jpg':
                            imagejpeg($new_image, $destination, 90);
                            break;
                        case 'image/png':
                            imagepng($new_image, $destination, 9);
                            break;
                        case 'image/gif':
                            imagegif($new_image, $destination);
                            break;
                        case 'image/webp':
                            imagewebp($new_image, $destination, 90);
                            break;
                    }
                    
                    // Libérer la mémoire
                    imagedestroy($source);
                    imagedestroy($new_image);
                    
                    // Supprimer l'ancienne photo de profil si elle existe
                    if (!empty($user['profile_picture'])) {
                        $old_file = $upload_dir . $user['profile_picture'];
                        if (file_exists($old_file)) {
                            unlink($old_file);
                        }
                    }
                    
                    // Mettre à jour la base de données
                    $stmt = $pdo->prepare("UPDATE users SET profile_picture = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$new_filename, $user_id]);
                    
                    $success = "Photo de profil mise à jour avec succès !";
                    $_SESSION['success'] = $success;
                    header("Location: profile.php");
                    exit();
                } else {
                    $error = "Erreur lors de l'upload de l'image.";
                }
            }
        } else {
            $error = "Veuillez sélectionner une image valide.";
        }
    } elseif ($action === 'delete_account') {
        // Supprimer le compte
        $confirm_delete = $_POST['confirm_delete'] ?? '';
        
        if ($confirm_delete === 'DELETE') {
            try {
                // Commencer une transaction
                $pdo->beginTransaction();
                
                // Supprimer la photo de profil si elle existe
                if (!empty($user['profile_picture'])) {
                    $avatar_path = '../uploads/avatars/' . $user['profile_picture'];
                    if (file_exists($avatar_path)) {
                        unlink($avatar_path);
                    }
                }
                
                // Supprimer l'utilisateur
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                
                $pdo->commit();
                
                // Déconnecter et rediriger
                session_destroy();
                header("Location: ../index.php?message=account_deleted");
                exit();
                
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Erreur lors de la suppression du compte : " . $e->getMessage();
            }
        } else {
            $error = "Veuillez taper 'DELETE' pour confirmer la suppression.";
        }

    } elseif ($action === 'upload_cover') {
        // Uploader une photo de couverture
        if (isset($_FILES['cover_photo']) && $_FILES['cover_photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            $max_size = 10 * 1024 * 1024; // 10MB
            
            $file_type = $_FILES['cover_photo']['type'];
            $file_size = $_FILES['cover_photo']['size'];
            $temp_file = $_FILES['cover_photo']['tmp_name'];
            
            // Validation
            if (!in_array($file_type, $allowed_types)) {
                $error = "Type de fichier non autorisé. Formats acceptés : JPG, PNG, GIF, WebP.";
            } elseif ($file_size > $max_size) {
                $error = "L'image est trop grande. Taille maximum : 10MB.";
            } else {
                // Créer le dossier uploads s'il n'existe pas
                $upload_dir = '../uploads/covers/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Générer un nom de fichier unique
                $file_extension = pathinfo($_FILES['cover_photo']['name'], PATHINFO_EXTENSION);
                $new_filename = 'cover_' . $user_id . '_' . time() . '.' . $file_extension;
                $destination = $upload_dir . $new_filename;
                
                // Redimensionner et uploader l'image
                if (move_uploaded_file($temp_file, $destination)) {
                    // Redimensionner l'image pour la couverture (1200x300)
                    list($width, $height) = getimagesize($destination);
                    $new_width = 1200;
                    $new_height = 300;
                    
                    // Créer une nouvelle image
                    $new_image = imagecreatetruecolor($new_width, $new_height);
                    
                    // Charger l'image originale selon son type
                    switch($file_type) {
                        case 'image/jpeg':
                        case 'image/jpg':
                            $source = imagecreatefromjpeg($destination);
                            break;
                        case 'image/png':
                            $source = imagecreatefrompng($destination);
                            break;
                        case 'image/gif':
                            $source = imagecreatefromgif($destination);
                            break;
                        case 'image/webp':
                            $source = imagecreatefromwebp($destination);
                            break;
                        default:
                            $source = imagecreatefromjpeg($destination);
                    }
                    
                    // Redimensionner avec crop au centre
                    $src_ratio = $width / $height;
                    $dst_ratio = $new_width / $new_height;
                    
                    if ($src_ratio > $dst_ratio) {
                        // Image plus large que le ratio cible, crop horizontal
                        $src_w = $height * $dst_ratio;
                        $src_h = $height;
                        $src_x = ($width - $src_w) / 2;
                        $src_y = 0;
                    } else {
                        // Image plus haute que le ratio cible, crop vertical
                        $src_w = $width;
                        $src_h = $width / $dst_ratio;
                        $src_x = 0;
                        $src_y = ($height - $src_h) / 2;
                    }
                    
                    // Copier et redimensionner
                    imagecopyresampled($new_image, $source, 0, 0, $src_x, $src_y, $new_width, $new_height, $src_w, $src_h);
                    
                    // Sauvegarder l'image redimensionnée
                    switch($file_type) {
                        case 'image/jpeg':
                        case 'image/jpg':
                            imagejpeg($new_image, $destination, 90);
                            break;
                        case 'image/png':
                            imagepng($new_image, $destination, 9);
                            break;
                        case 'image/gif':
                            imagegif($new_image, $destination);
                            break;
                        case 'image/webp':
                            imagewebp($new_image, $destination, 90);
                            break;
                    }
                    
                    // Libérer la mémoire
                    imagedestroy($source);
                    imagedestroy($new_image);
                    
                    // Supprimer l'ancienne couverture si elle existe
                    if (!empty($user['cover_photo'])) {
                        $old_file = $upload_dir . $user['cover_photo'];
                        if (file_exists($old_file)) {
                            unlink($old_file);
                        }
                    }
                    
                    // Mettre à jour la base de données
                    $stmt = $pdo->prepare("UPDATE users SET cover_photo = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$new_filename, $user_id]);
                    
                    $success = "Photo de couverture mise à jour avec succès !";
                    $_SESSION['success'] = $success;
                    header("Location: profile.php");
                    exit();
                } else {
                    $error = "Erreur lors de l'upload de l'image.";
                }
            }
        } else {
            $error = "Veuillez sélectionner une image valide.";
        }
    }
}

// Vérifier si un message de succès existe en session
if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil - SocialSphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4a00e0;
            --primary-light: #7c4dff;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
            background: white;
            border-radius: 10px;
            padding: 15px 25px;
            box-shadow: var(--shadow);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 15px;
        }
        
        .nav-links a {
            color: #666;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 20px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: #f0f0ff;
            color: var(--primary);
        }
        
        .profile-header {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            position: relative;
        }
        
        .cover-photo {
            height: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: relative;
        }
        
        .cover-actions {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 10px;
        }
        
        .profile-info {
            padding: 30px;
            position: relative;
            margin-top: -80px;
        }
        
        .avatar-container {
            position: relative;
            display: inline-block;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 160px;
            height: 160px;
            border-radius: 50%;
            border: 5px solid white;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: bold;
            overflow: hidden;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .avatar-overlay {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: var(--primary);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .avatar-overlay:hover {
            background: var(--primary-light);
            transform: scale(1.1);
        }
        
        .profile-name {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .profile-username {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 15px;
        }
        
        .profile-bio {
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
            max-width: 600px;
        }
        
        .profile-stats {
            display: flex;
            gap: 30px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        
        .stat {
            text-align: center;
            padding: 10px 20px;
            background: #f8f9fa;
            border-radius: 10px;
            min-width: 100px;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            display: block;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .profile-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-size: 0.95rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning);
            color: #333;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .card-actions {
            display: flex;
            gap: 10px;
        }
        
        .friends-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        
        .friend-card {
            text-align: center;
            padding: 15px;
            border-radius: 8px;
            background: #f8f9fa;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .friend-card:hover {
            background: #f0f0ff;
            transform: translateY(-5px);
        }
        
        .friend-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin: 0 auto 10px;
            overflow: hidden;
        }
        
        .friend-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .friend-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .post-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .post-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
        }
        
        .post-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            overflow: hidden;
        }
        
        .post-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .post-user-info h4 {
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .post-time {
            color: #666;
            font-size: 0.85rem;
        }
        
        .post-content {
            margin: 15px 0;
            line-height: 1.6;
        }
        
        .post-actions {
            display: flex;
            gap: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #666;
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            background: #f5f5f5;
            color: var(--primary);
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 500px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: var(--shadow);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #666;
            cursor: pointer;
            padding: 5px;
        }
        
        .close-modal:hover {
            color: var(--danger);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .file-upload {
            position: relative;
            margin-bottom: 20px;
        }
        
        .file-upload input[type="file"] {
            display: none;
        }
        
        .file-upload-label {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            border: 2px dashed #ddd;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            justify-content: center;
        }
        
        .file-upload-label:hover {
            border-color: var(--primary);
            background: #f8f9ff;
        }
        
        .avatar-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 0 auto 20px;
            overflow: hidden;
            border: 3px solid #f0f0f0;
        }
        
        .avatar-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .alert {
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        .danger-zone {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
        }
        
        .danger-zone h3 {
            color: var(--danger);
            margin-bottom: 10px;
        }

        /* Pour les boutons de couverture */
        .cover-actions {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 10px;
        }

        .cover-actions .btn {
            background: rgba(255, 255, 255, 0.9);
            color: #333;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }

        .cover-actions .btn:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .friends-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .profile-stats {
                justify-content: center;
            }
            
            .nav-links {
                gap: 10px;
            }
            
            .nav-links a span {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">SocialSphere</div>
            <nav class="nav-links">
                <a href="dashboard.php"><i class="fas fa-home"></i> <span>Accueil</span></a>
                <a href="profile.php" class="active"><i class="fas fa-user"></i> <span>Profil</span></a>
                <a href="friends.php"><i class="fas fa-users"></i> <span>Amis</span></a>
                <a href="messages.php"><i class="fas fa-envelope"></i> <span>Messages</span></a>
                <a href="../config/auth.php?action=logout" title="Déconnexion"><i class="fas fa-sign-out-alt"></i></a>
            </nav>
        </div>
        
        <!-- Messages d'alerte -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <!-- Profile Header -->
        <div class="profile-header">
           
            <div class="cover-photo" id="coverPhoto" style="background: <?php echo !empty($user['cover_photo']) ? "url('../uploads/covers/" . htmlspecialchars($user['cover_photo']) . "') center/cover no-repeat" : "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"; ?>;">
                <div class="cover-actions">
                    <button class="btn btn-secondary" type="button" onclick="openCoverModal()">
                        <i class="fas fa-camera"></i> Modifier la couverture
                    </button>
                </div>
            </div>
            <div class="profile-info">
                <div class="avatar-container">
                    <div class="profile-avatar">
                        <?php if (!empty($user['profile_picture'])): ?>
                            <img src="../uploads/avatars/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                 alt="<?php echo htmlspecialchars($user['username']); ?>">
                        <?php else: ?>
                            <?php echo strtoupper(substr($user['first_name'] ?? $username, 0, 1)); ?>
                        <?php endif; ?>
                    </div>
                    <div class="avatar-overlay" onclick="openAvatarModal()">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                <h1 class="profile-name">
                    <?php echo htmlspecialchars($user['first_name'] ?? '') . ' ' . htmlspecialchars($user['last_name'] ?? ''); ?>
                    <?php if (empty($user['first_name'])): ?>
                        <?php echo htmlspecialchars($username); ?>
                    <?php endif; ?>
                </h1>
                <p class="profile-username">@<?php echo htmlspecialchars($username); ?></p>
                
                <?php if (!empty($user['bio'])): ?>
                <p class="profile-bio"><?php echo nl2br(htmlspecialchars($user['bio'])); ?></p>
                <?php endif; ?>
                
                <div class="profile-stats">
                    <div class="stat">
                        <span class="stat-number"><?php echo $user['friend_count'] ?? 0; ?></span>
                        <span class="stat-label">Amis</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number"><?php echo $user['post_count'] ?? 0; ?></span>
                        <span class="stat-label">Publications</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number"><?php echo $user['group_count'] ?? 0; ?></span>
                        <span class="stat-label">Groupes</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">
                            <?php 
                            $now = new DateTime();
                            $joinDate = new DateTime($user['created_at']);
                            $interval = $now->diff($joinDate);
                            echo $interval->y;
                            ?>
                        </span>
                        <span class="stat-label">Années</span>
                    </div>
                </div>
                
                <div class="profile-actions">
                    <button class="btn btn-primary" onclick="openEditModal()">
                        <i class="fas fa-edit"></i> Modifier le profil
                    </button>
                    <button class="btn btn-secondary" onclick="openPasswordModal()">
                        <i class="fas fa-key"></i> Changer mot de passe
                    </button>
                    <a href="dashboard.php" class="btn btn-success">
                        <i class="fas fa-newspaper"></i> Mes publications
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-grid">
            <!-- Left Column: Posts -->
            <div>
                <div class="card">
                    <div class="card-title">
                        <span>Mes dernières publications</span>
                        <a href="dashboard.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Nouvelle publication
                        </a>
                    </div>
                    
                    <?php if (empty($posts)): ?>
                        <div style="text-align: center; padding: 40px;">
                            <i class="fas fa-newspaper" style="font-size: 3rem; color: #ddd; margin-bottom: 15px;"></i>
                            <h3 style="color: #666; margin-bottom: 10px;">Aucune publication</h3>
                            <p style="color: #999;">Vous n'avez pas encore publié de contenu.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($posts as $post): ?>
                        <div class="post-card">
                            <div class="post-header">
                                <div class="post-avatar">
                                    <?php if (!empty($user['profile_picture'])): ?>
                                        <img src="../uploads/avatars/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                             alt="<?php echo htmlspecialchars($user['username']); ?>">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($user['first_name'] ?? $username, 0, 1)); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="post-user-info">
                                    <h4>
                                        <?php echo htmlspecialchars($user['first_name'] ?? '') . ' ' . htmlspecialchars($user['last_name'] ?? ''); ?>
                                        <?php if (empty($user['first_name'])): ?>
                                            <?php echo htmlspecialchars($username); ?>
                                        <?php endif; ?>
                                    </h4>
                                    <span class="post-time">
                                        <?php 
                                        $now = new DateTime();
                                        $postTime = new DateTime($post['created_at']);
                                        $interval = $now->diff($postTime);
                                        
                                        if ($interval->y > 0) echo "il y a " . $interval->y . " an" . ($interval->y > 1 ? "s" : "");
                                        elseif ($interval->m > 0) echo "il y a " . $interval->m . " mois";
                                        elseif ($interval->d > 0) echo "il y a " . $interval->d . " jour" . ($interval->d > 1 ? "s" : "");
                                        elseif ($interval->h > 0) echo "il y a " . $interval->h . " heure" . ($interval->h > 1 ? "s" : "");
                                        elseif ($interval->i > 0) echo "il y a " . $interval->i . " minute" . ($interval->i > 1 ? "s" : "");
                                        else echo "à l'instant";
                                        ?>
                                    </span>
                                </div>
                            </div>
                            <div class="post-content">
                                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
                            </div>
                            <div class="post-actions">
                                <button class="action-btn">
                                    <i class="fas fa-heart"></i>
                                    <span><?php echo $post['like_count'] ?? 0; ?></span>
                                </button>
                                <button class="action-btn">
                                    <i class="fas fa-comment"></i>
                                    <span><?php echo $post['comment_count'] ?? 0; ?></span>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column: Friends & Info -->
            <div>
                <!-- Friends Card -->
                <div class="card">
                    <div class="card-title">
                        <span>Mes amis</span>
                        <a href="friends.php" class="btn btn-secondary">Voir tous</a>
                    </div>
                    
                    <?php if (empty($friends)): ?>
                        <div style="text-align: center; padding: 30px;">
                            <i class="fas fa-users" style="font-size: 3rem; color: #ddd; margin-bottom: 15px;"></i>
                            <h3 style="color: #666; margin-bottom: 10px;">Aucun ami</h3>
                            <p style="color: #999;">Ajoutez des amis pour commencer !</p>
                        </div>
                    <?php else: ?>
                        <div class="friends-grid">
                            <?php foreach ($friends as $friend): ?>
                            <div class="friend-card" onclick="window.location.href='profile_view.php?id=<?php echo $friend['id']; ?>'">
                                <div class="friend-avatar">
                                    <?php if (!empty($friend['profile_picture'])): ?>
                                        <img src="../uploads/avatars/<?php echo htmlspecialchars($friend['profile_picture']); ?>" 
                                             alt="<?php echo htmlspecialchars($friend['username']); ?>">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($friend['username'], 0, 2)); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="friend-name">
                                    <?php 
                                    $friendName = !empty($friend['first_name']) 
                                        ? htmlspecialchars($friend['first_name'])
                                        : htmlspecialchars($friend['username']);
                                    echo $friendName;
                                    ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- About Card -->
                <div class="card">
                    <h2 class="card-title">À propos</h2>
                    <div style="line-height: 1.8;">
                        <?php if (!empty($user['bio'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-quote-left"></i> Bio :</strong><br>
                            <?php echo nl2br(htmlspecialchars($user['bio'])); ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['email'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-envelope"></i> Email :</strong><br>
                            <?php echo htmlspecialchars($user['email']); ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['location'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-map-marker-alt"></i> Localisation :</strong><br>
                            <?php echo htmlspecialchars($user['location']); ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['website'])): ?>
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-globe"></i> Site web :</strong><br>
                            <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank" style="color: var(--primary);">
                                <?php echo htmlspecialchars($user['website']); ?>
                            </a>
                        </p>
                        <?php endif; ?>
                        
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-user-plus"></i> Membre depuis :</strong><br>
                            <?php echo date('d/m/Y', strtotime($user['created_at'])); ?>
                        </p>
                        
                        <p style="margin-bottom: 15px;">
                            <strong><i class="fas fa-history"></i> Dernière mise à jour :</strong><br>
                            <?php 
                            if (!empty($user['updated_at'])) {
                                echo date('d/m/Y à H:i', strtotime($user['updated_at']));
                            } else {
                                echo 'Jamais';
                            }
                            ?>
                        </p>
                    </div>
                </div>
                
                <!-- Danger Zone -->
                <div class="danger-zone">
                    <h3><i class="fas fa-exclamation-triangle"></i> Zone dangereuse</h3>
                    <p style="color: #721c24; margin-bottom: 15px;">
                        Ces actions sont irréversibles. Soyez certain de ce que vous faites.
                    </p>
                    <button class="btn btn-danger" onclick="openDeleteModal()">
                        <i class="fas fa-trash-alt"></i> Supprimer mon compte
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Profile Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title"><i class="fas fa-user-edit"></i> Modifier mon profil</h2>
                <button class="close-modal" onclick="closeEditModal()">&times;</button>
            </div>
            
            <form method="POST" action="profile.php">
                <div class="form-group">
                    <label for="first_name">Prénom</label>
                    <input type="text" id="first_name" name="first_name" class="form-control" 
                           value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" 
                           placeholder="Votre prénom">
                </div>
                
                <div class="form-group">
                    <label for="last_name">Nom</label>
                    <input type="text" id="last_name" name="last_name" class="form-control" 
                           value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>" 
                           placeholder="Votre nom">
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" class="form-control" required
                           value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" 
                           placeholder="votre@email.com">
                </div>
                
                <div class="form-group">
                    <label for="bio">Bio</label>
                    <textarea id="bio" name="bio" class="form-control" rows="4"
                              placeholder="Parlez un peu de vous..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="location">Localisation</label>
                    <input type="text" id="location" name="location" class="form-control" 
                           value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>" 
                           placeholder="Ville, Pays">
                </div>
                
                <div class="form-group">
                    <label for="website">Site web</label>
                    <input type="url" id="website" name="website" class="form-control" 
                           value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>" 
                           placeholder="https://votresite.com">
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <input type="hidden" name="action" value="update_profile">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Upload Avatar Modal -->
    <div id="avatarModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title"><i class="fas fa-camera"></i> Modifier ma photo de profil</h2>
                <button class="close-modal" onclick="closeAvatarModal()">&times;</button>
            </div>
            
            <form method="POST" action="profile.php" enctype="multipart/form-data">
                <div class="avatar-preview">
                    <?php if (!empty($user['profile_picture'])): ?>
                        <img src="../uploads/avatars/<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             id="avatarPreview" alt="Photo actuelle">
                    <?php else: ?>
                        <div id="avatarPreview" style="width:100%;height:100%;background:linear-gradient(135deg, var(--primary), var(--secondary));color:white;display:flex;align-items:center;justify-content:center;font-size:3rem;">
                            <?php echo strtoupper(substr($user['first_name'] ?? $username, 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="file-upload">
                    <input type="file" id="avatar" name="avatar" accept="image/*" onchange="previewAvatar(this)">
                    <label for="avatar" class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Choisir une image (JPG, PNG, GIF, WebP - max 5MB)</span>
                    </label>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-info-circle"></i>
                    Taille recommandée : 300x300 pixels. L'image sera automatiquement redimensionnée.
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <input type="hidden" name="action" value="upload_avatar">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-upload"></i> Uploader
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeAvatarModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Change Password Modal -->
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title"><i class="fas fa-key"></i> Changer mon mot de passe</h2>
                <button class="close-modal" onclick="closePasswordModal()">&times;</button>
            </div>
            
            <form method="POST" action="profile.php">
                <div class="form-group">
                    <label for="current_password">Mot de passe actuel *</label>
                    <input type="password" id="current_password" name="current_password" class="form-control" required
                           placeholder="Votre mot de passe actuel">
                </div>
                
                <div class="form-group">
                    <label for="new_password">Nouveau mot de passe *</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" required
                           placeholder="Nouveau mot de passe (min 6 caractères)">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirmer le nouveau mot de passe *</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required
                           placeholder="Confirmez le nouveau mot de passe">
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-circle"></i>
                    Votre mot de passe doit contenir au moins 6 caractères.
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <input type="hidden" name="action" value="update_password">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-key"></i> Changer le mot de passe
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closePasswordModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Account Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" style="color: var(--danger);">
                    <i class="fas fa-exclamation-triangle"></i> Supprimer mon compte
                </h2>
                <button class="close-modal" onclick="closeDeleteModal()">&times;</button>
            </div>
            
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <strong>Attention ! Cette action est irréversible.</strong><br>
                Toutes vos données seront définitivement supprimées.
            </div>
            
            <form method="POST" action="profile.php">
                <div class="form-group">
                    <label for="confirm_delete">
                        Pour confirmer, tapez <strong style="color: var(--danger);">DELETE</strong> ci-dessous :
                    </label>
                    <input type="text" id="confirm_delete" name="confirm_delete" class="form-control" 
                           placeholder="DELETE" required>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <input type="hidden" name="action" value="delete_account">
                    <button type="submit" class="btn btn-danger" style="flex: 1;" onclick="return confirm('Êtes-vous ABSOLUMENT sûr de vouloir supprimer votre compte ? Cette action est irréversible.')">
                        <i class="fas fa-trash-alt"></i> Supprimer définitivement
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Upload Cover Modal -->
    <div id="coverModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title"><i class="fas fa-image"></i> Modifier ma photo de couverture</h2>
                <button class="close-modal" onclick="closeCoverModal()">&times;</button>
            </div>
            
            <form method="POST" action="profile.php" enctype="multipart/form-data">
                <div class="cover-preview" style="width: 100%; height: 150px; border-radius: 8px; overflow: hidden; margin-bottom: 20px; border: 2px solid #f0f0f0;">
                    <?php if (!empty($user['cover_photo'])): ?>
                        <img src="../uploads/covers/<?php echo htmlspecialchars($user['cover_photo']); ?>" 
                            id="coverPreview" alt="Couverture actuelle" style="width:100%;height:100%;object-fit:cover;">
                    <?php else: ?>
                        <div id="coverPreview" style="width:100%;height:100%;background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);display:flex;align-items:center;justify-content:center;color:white;font-size:1.2rem;">
                            <i class="fas fa-image"></i> Aperçu de la couverture
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="file-upload">
                    <input type="file" id="cover_photo" name="cover_photo" accept="image/*" onchange="previewCover(this)">
                    <label for="cover_photo" class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Choisir une image (JPG, PNG, GIF, WebP - max 10MB)</span>
                    </label>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-info-circle"></i>
                    Taille recommandée : 1200x300 pixels. L'image sera automatiquement redimensionnée et recadrée.
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-lightbulb"></i>
                    Conseil : Choisissez une image horizontale qui représente bien votre profil.
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 25px;">
                    <input type="hidden" name="action" value="upload_cover">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-upload"></i> Uploader
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeCoverModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Modal functions
        function openEditModal() {
            document.getElementById('editModal').style.display = 'flex';
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        function openAvatarModal() {
            document.getElementById('avatarModal').style.display = 'flex';
        }
        
        function closeAvatarModal() {
            document.getElementById('avatarModal').style.display = 'none';
        }
        
        function openPasswordModal() {
            document.getElementById('passwordModal').style.display = 'flex';
        }
        
        function closePasswordModal() {
            document.getElementById('passwordModal').style.display = 'none';
        }
        
        function openDeleteModal() {
            document.getElementById('deleteModal').style.display = 'flex';
        }
        
        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }
        
        function openCoverModal() {
            alert('Fonctionnalité de modification de couverture à implémenter');
        }
        
        // Preview avatar before upload
        function previewAvatar(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                const preview = document.getElementById('avatarPreview');
                
                reader.onload = function(e) {
                    if (preview.tagName === 'IMG') {
                        preview.src = e.target.result;
                    } else {
                        // Si c'est un div, le remplacer par une image
                        const img = document.createElement('img');
                        img.id = 'avatarPreview';
                        img.src = e.target.result;
                        img.style.width = '100%';
                        img.style.height = '100%';
                        img.style.objectFit = 'cover';
                        preview.parentNode.replaceChild(img, preview);
                    }
                };
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Fonctions pour la couverture
        function openCoverModal() {
            document.getElementById('coverModal').style.display = 'flex';
        }

        function closeCoverModal() {
            document.getElementById('coverModal').style.display = 'none';
        }

        function previewCover(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                const preview = document.getElementById('coverPreview');
                
                reader.onload = function(e) {
                    if (preview.tagName === 'IMG') {
                        preview.src = e.target.result;
                    } else {
                        // Si c'est un div, le remplacer par une image
                        const img = document.createElement('img');
                        img.id = 'coverPreview';
                        img.src = e.target.result;
                        img.style.width = '100%';
                        img.style.height = '100%';
                        img.style.objectFit = 'cover';
                        preview.parentNode.replaceChild(img, preview);
                    }
                };
                
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = ['editModal', 'avatarModal', 'passwordModal', 'deleteModal', 'coverModal'];
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
                if (event.target === modal) {
                    eval('close' + modalId.charAt(0).toUpperCase() + modalId.slice(1) + '()');
                }
            });
        };
        
        // Close modals with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeEditModal();
                closeAvatarModal();
                closePasswordModal();
                closeDeleteModal();
                closeCoverModal();
            }
        });
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);
        
        // Form validation for email
        const emailInput = document.getElementById('email');
        if (emailInput) {
            emailInput.addEventListener('blur', function() {
                const email = this.value.trim();
                if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    this.style.borderColor = 'var(--danger)';
                } else {
                    this.style.borderColor = '#ddd';
                }
            });
        }
    </script>
</body>
</html>