<?php
// Active l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php'; // Connexion à la base de données

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../config/auth.php');
    exit();
}

// Fonction pour vérifier si une colonne existe
function columnExists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM $table LIKE ?");
        $stmt->execute([$column]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Fonction pour vérifier si une table existe
function tableExists($pdo, $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Récupérer les statistiques en temps réel
try {
    // Vérifier quelles tables existent
    $tables = [
        'users' => tableExists($pdo, 'users'),
        'groups' => tableExists($pdo, 'groups'),
        'posts' => tableExists($pdo, 'posts'),
        'comments' => tableExists($pdo, 'comments'),
        'group_members' => tableExists($pdo, 'group_members'),
        'reports' => tableExists($pdo, 'reports'),
        'activity_log' => tableExists($pdo, 'activity_log'),
        'friendships' => tableExists($pdo, 'friendships')
    ];
    
    // 1. Nombre total d'utilisateurs
    if ($tables['users']) {
        $has_is_active = columnExists($pdo, 'users', 'is_active');
        if ($has_is_active) {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE is_active = 1");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
        }
        $total_users = $stmt->fetch()['total'];
        
        // 2. Utilisateurs inscrits aujourd'hui
        if ($has_is_active) {
            $stmt = $pdo->query("SELECT COUNT(*) as today FROM users WHERE DATE(created_at) = CURDATE() AND is_active = 1");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as today FROM users WHERE DATE(created_at) = CURDATE()");
        }
        $today_users = $stmt->fetch()['today'];
    } else {
        $total_users = 0;
        $today_users = 0;
    }
    
    // 3. Nombre total de groupes
    if ($tables['groups']) {
        $has_is_active_groups = columnExists($pdo, 'groups', 'is_active');
        if ($has_is_active_groups) {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM groups WHERE is_active = 1");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM groups");
        }
        $total_groups = $stmt->fetch()['total'];
        
        // 4. Groupes créés ce mois
        if ($has_is_active_groups) {
            $stmt = $pdo->query("SELECT COUNT(*) as month FROM groups WHERE MONTH(created_at) = MONTH(CURDATE()) AND is_active = 1");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as month FROM groups WHERE MONTH(created_at) = MONTH(CURDATE())");
        }
        $month_groups = $stmt->fetch()['month'];
    } else {
        $total_groups = 0;
        $month_groups = 0;
    }
    
    // 5. Nombre total de publications
    if ($tables['posts']) {
        $has_deleted_at = columnExists($pdo, 'posts', 'deleted_at');
        if ($has_deleted_at) {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM posts WHERE deleted_at IS NULL");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM posts");
        }
        $total_posts = $stmt->fetch()['total'];
        
        // 6. Publications aujourd'hui
        if ($has_deleted_at) {
            $stmt = $pdo->query("SELECT COUNT(*) as today FROM posts WHERE DATE(created_at) = CURDATE() AND deleted_at IS NULL");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as today FROM posts WHERE DATE(created_at) = CURDATE()");
        }
        $today_posts = $stmt->fetch()['today'];
    } else {
        $total_posts = 0;
        $today_posts = 0;
    }
    
    // 7. Nombre total de commentaires
    if ($tables['comments']) {
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM comments");
        $total_comments = $stmt->fetch()['total'];
    } else {
        $total_comments = 0;
    }
    
    // 8. Signalements non traités
    if ($tables['reports']) {
        $has_status = columnExists($pdo, 'reports', 'status');
        if ($has_status) {
            $stmt = $pdo->query("SELECT COUNT(*) as pending FROM reports WHERE status = 'pending'");
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) as pending FROM reports");
        }
        $pending_reports = $stmt->fetch()['pending'];
    } else {
        $pending_reports = 0;
    }
    
    // 9. Dernières inscriptions (7 derniers jours)
    if ($tables['users']) {
        if ($has_is_active) {
            $stmt = $pdo->query("
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as count
                FROM users 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                AND is_active = 1
                GROUP BY DATE(created_at)
                ORDER BY date DESC
            ");
        } else {
            $stmt = $pdo->query("
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as count
                FROM users 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date DESC
            ");
        }
        $users_last_week = $stmt->fetchAll();
    } else {
        $users_last_week = [];
    }
    
    // 10. Dernières activités
    if ($tables['activity_log']) {
        $stmt = $pdo->query("
            SELECT 
                u.username,
                a.action,
                a.entity_type,
                a.created_at
            FROM activity_log a
            JOIN users u ON a.user_id = u.id
            ORDER BY a.created_at DESC
            LIMIT 10
        ");
        $recent_activities = $stmt->fetchAll();
    } else {
        $recent_activities = [];
    }
    
    // 11. Top 5 utilisateurs les plus actifs
    if ($tables['users'] && $tables['posts'] && $tables['comments']) {
        $where_clause = $has_is_active ? "WHERE u.is_active = 1" : "";
        $post_condition = $has_deleted_at ? "AND p.deleted_at IS NULL" : "";
        
        $query_top_users = "
            SELECT 
                u.username,
                u.profile_picture,
                COUNT(p.id) as post_count,
                COUNT(c.id) as comment_count
            FROM users u
            LEFT JOIN posts p ON u.id = p.user_id $post_condition
            LEFT JOIN comments c ON u.id = c.user_id
            $where_clause
            GROUP BY u.id
            ORDER BY (COUNT(p.id) + COUNT(c.id)) DESC
            LIMIT 5
        ";
        $stmt = $pdo->query($query_top_users);
        $top_users = $stmt->fetchAll();
    } else {
        $top_users = [];
    }
    
    // 12. Groupes les plus populaires
    if ($tables['groups'] && $tables['group_members'] && $tables['posts']) {
        // Vérifier si la colonne group_id existe dans posts
        $has_group_id = columnExists($pdo, 'posts', 'group_id');
        $has_status_gm = columnExists($pdo, 'group_members', 'status');
        
        $member_condition = $has_status_gm ? "AND gm.status = 'approved'" : "";
        $group_condition = $has_is_active_groups ? "WHERE g.is_active = 1" : "";
        $post_condition = $has_deleted_at ? "AND p.deleted_at IS NULL" : "";
        
        // Si posts n'a pas group_id, on ne peut pas compter les posts par groupe
        if ($has_group_id) {
            $query_popular_groups = "
                SELECT 
                    g.name,
                    g.id,
                    COUNT(DISTINCT gm.user_id) as member_count,
                    COUNT(DISTINCT p.id) as post_count
                FROM groups g
                LEFT JOIN group_members gm ON g.id = gm.group_id $member_condition
                LEFT JOIN posts p ON g.id = p.group_id $post_condition
                $group_condition
                GROUP BY g.id
                ORDER BY member_count DESC
                LIMIT 5
            ";
        } else {
            // Version sans compter les posts par groupe
            $query_popular_groups = "
                SELECT 
                    g.name,
                    g.id,
                    COUNT(DISTINCT gm.user_id) as member_count,
                    0 as post_count
                FROM groups g
                LEFT JOIN group_members gm ON g.id = gm.group_id $member_condition
                $group_condition
                GROUP BY g.id
                ORDER BY member_count DESC
                LIMIT 5
            ";
        }
        
        $stmt = $pdo->query($query_popular_groups);
        $popular_groups = $stmt->fetchAll();
    } else {
        $popular_groups = [];
    }
    
    // 13. Dernières amitiés (si table existe)
    if ($tables['friendships']) {
        $has_status_friends = columnExists($pdo, 'friendships', 'status');
        $status_condition = $has_status_friends ? "WHERE f.status = 'accepted'" : "";
        
        $stmt = $pdo->query("
            SELECT 
                u1.username as user1,
                u2.username as user2,
                f.created_at
            FROM friendships f
            JOIN users u1 ON f.user_id1 = u1.id
            JOIN users u2 ON f.user_id2 = u2.id
            $status_condition
            ORDER BY f.created_at DESC
            LIMIT 5
        ");
        $recent_friendships = $stmt->fetchAll();
    } else {
        $recent_friendships = [];
    }
    
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}

// Formater les dates en français
function formatDateFr($date) {
    $dateTime = new DateTime($date);
    $jours = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    $mois = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
    
    return $jours[$dateTime->format('w')] . ' ' . 
           $dateTime->format('d') . ' ' . 
           $mois[$dateTime->format('n')-1] . ' ' . 
           $dateTime->format('Y') . ' à ' . 
           $dateTime->format('H:i');
}

function formatRelativeTime($date) {
    $now = new DateTime();
    $dateTime = new DateTime($date);
    $interval = $now->diff($dateTime);
    
    if ($interval->y > 0) return "il y a " . $interval->y . " an" . ($interval->y > 1 ? "s" : "");
    if ($interval->m > 0) return "il y a " . $interval->m . " mois";
    if ($interval->d > 0) return "il y a " . $interval->d . " jour" . ($interval->d > 1 ? "s" : "");
    if ($interval->h > 0) return "il y a " . $interval->h . " heure" . ($interval->h > 1 ? "s" : "");
    if ($interval->i > 0) return "il y a " . $interval->i . " minute" . ($interval->i > 1 ? "s" : "");
    return "à l'instant";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Admin - Réseau Social</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #4a00e0;
            --secondary: #8e2de2;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fb;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-left h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .header-left p {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .admin-container {
            display: flex;
            min-height: calc(100vh - 80px);
        }
        
        .sidebar {
            width: 250px;
            background: white;
            padding: 1.5rem 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.05);
        }
        
        .sidebar-nav {
            list-style: none;
        }
        
        .nav-item {
            margin-bottom: 0.2rem;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 1.5rem;
            color: #555;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        
        .nav-link:hover, .nav-link.active {
            background: #f0f0ff;
            color: var(--primary);
            border-left-color: var(--primary);
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            padding: 2rem;
            overflow-y: auto;
        }
        
        .dashboard-title {
            margin-bottom: 2rem;
            color: var(--dark);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            border-top: 4px solid var(--primary);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card.success { border-top-color: var(--success); }
        .stat-card.info { border-top-color: var(--info); }
        .stat-card.warning { border-top-color: var(--warning); }
        .stat-card.danger { border-top-color: var(--danger); }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }
        
        .stat-card.success .stat-icon { background: var(--success); }
        .stat-card.info .stat-icon { background: var(--info); }
        .stat-card.warning .stat-icon { background: var(--warning); }
        .stat-card.danger .stat-icon { background: var(--danger); }
        .stat-card .stat-icon { background: var(--primary); }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .stat-change {
            font-size: 0.8rem;
            padding: 0.2rem 0.5rem;
            border-radius: 10px;
            background: #f0f0f0;
            display: inline-block;
            margin-top: 0.5rem;
        }
        
        .positive { color: var(--success); }
        .negative { color: var(--danger); }
        
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        @media (max-width: 1024px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .card-link {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            display: flex;
            align-items: flex-start;
            padding: 1rem 0;
            border-bottom: 1px solid #f5f5f5;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f0f0ff;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-user {
            font-weight: 600;
            color: var(--dark);
        }
        
        .activity-action {
            color: #666;
            margin: 0.2rem 0;
        }
        
        .activity-time {
            color: #999;
            font-size: 0.85rem;
        }
        
        .user-list {
            list-style: none;
        }
        
        .user-item {
            display: flex;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid #f5f5f5;
        }
        
        .user-item:last-child {
            border-bottom: none;
        }
        
        .user-avatar-small {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f0f0ff;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            font-weight: bold;
        }
        
        .user-info-small {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            color: var(--dark);
        }
        
        .user-stats {
            color: #666;
            font-size: 0.9rem;
        }
        
        .group-list {
            list-style: none;
        }
        
        .group-item {
            padding: 1rem 0;
            border-bottom: 1px solid #f5f5f5;
        }
        
        .group-item:last-child {
            border-bottom: none;
        }
        
        .group-name {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .group-meta {
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 0.9rem;
        }
        
        .chart-container {
            height: 300px;
            margin-top: 1rem;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .action-btn {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #555;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            border-color: var(--primary);
            background: #f0f0ff;
            color: var(--primary);
            transform: translateY(-3px);
        }
        
        .action-icon {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        
        .action-label {
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                order: 2;
            }
            
            .sidebar-nav {
                display: flex;
                overflow-x: auto;
                padding: 0.5rem;
            }
            
            .nav-item {
                flex-shrink: 0;
                margin-bottom: 0;
            }
            
            .nav-link {
                border-left: none;
                border-bottom: 3px solid transparent;
            }
            
            .nav-link:hover, .nav-link.active {
                border-left: none;
                border-bottom-color: var(--primary);
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-info {
            background-color: #d1ecf1;
            border-color: #bee5eb;
            color: #0c5460;
        }
        
        .table-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        
        .table-info ul {
            margin-left: 20px;
        }
        
        .table-info li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <!-- En-tête admin -->
    <header class="admin-header">
        <div class="header-left">
            <h1><i class="fas fa-crown"></i> Tableau de bord Admin</h1>
            <p>Gestion complète du réseau social</p>
        </div>
        <div class="header-right">
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['username'], 0, 2)); ?>
                </div>
                <div>
                    <div style="font-weight: 600;"><?php echo $_SESSION['username']; ?></div>
                    <div style="font-size: 0.85rem; opacity: 0.9;">Administrateur</div>
                </div>
            </div>
            <a href="../config/auth.php?action=logout" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Déconnexion
            </a>
        </div>
    </header>
    
    <div class="admin-container">
        <!-- Sidebar de navigation -->
        <nav class="sidebar">
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i> Tableau de bord
                    </a>
                </li>
                <li class="nav-item">
                    <a href="users.php" class="nav-link">
                        <i class="fas fa-users"></i> Utilisateurs
                        <span style="margin-left: auto; background: var(--primary); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                            <?php echo $total_users; ?>
                        </span>
                    </a>
                </li>
                <?php if ($tables['groups']): ?>
                <li class="nav-item">
                    <a href="groups.php" class="nav-link">
                        <i class="fas fa-users-cog"></i> Groupes
                        <span style="margin-left: auto; background: var(--info); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                            <?php echo $total_groups; ?>
                        </span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if ($tables['posts']): ?>
                <li class="nav-item">
                    <a href="posts.php" class="nav-link">
                        <i class="fas fa-newspaper"></i> Publications
                        <span style="margin-left: auto; background: var(--success); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                            <?php echo $total_posts; ?>
                        </span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if ($tables['comments']): ?>
                <li class="nav-item">
                    <a href="comments.php" class="nav-link">
                        <i class="fas fa-comments"></i> Commentaires
                        <span style="margin-left: auto; background: var(--warning); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                            <?php echo $total_comments; ?>
                        </span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if ($tables['reports']): ?>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-flag"></i> Signalements
                        <?php if ($pending_reports > 0): ?>
                        <span style="margin-left: auto; background: var(--danger); color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">
                            <?php echo $pending_reports; ?> nouveaux
                        </span>
                        <?php endif; ?>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i> Paramètres
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../index.php" class="nav-link">
                        <i class="fas fa-eye"></i> Voir le site
                    </a>
                </li>
            </ul>
        </nav>
        
        <!-- Contenu principal -->
        <main class="main-content">
            <h2 class="dashboard-title">Aperçu général</h2>
            
            <!-- Information sur les tables disponibles -->
            <div class="table-info">
                <strong><i class="fas fa-database"></i> Structure détectée :</strong>
                <ul>
                    <li><?php echo $tables['users'] ? '✓ Table users' : '✗ Table users (manquante)'; ?></li>
                    <li><?php echo $tables['groups'] ? '✓ Table groups' : '✗ Table groups (manquante)'; ?></li>
                    <li><?php echo $tables['posts'] ? '✓ Table posts' : '✗ Table posts (manquante)'; ?></li>
                    <li><?php echo $tables['comments'] ? '✓ Table comments' : '✗ Table comments (manquante)'; ?></li>
                    <li><?php echo $tables['friendships'] ? '✓ Table friendships' : '✗ Table friendships (manquante)'; ?></li>
                    <li><?php echo $tables['reports'] ? '✓ Table reports' : '✗ Table reports (manquante)'; ?></li>
                </ul>
                <a href="db_fix.php" style="color: var(--primary); font-size: 0.9rem;">
                    <i class="fas fa-tools"></i> Optimiser la structure de la base
                </a>
            </div>
            
            <!-- Cartes de statistiques -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-number"><?php echo $total_users; ?></div>
                            <div class="stat-label">Utilisateurs</div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> <?php echo $today_users; ?> nouveaux aujourd'hui
                    </div>
                </div>
                
                <?php if ($tables['groups']): ?>
                <div class="stat-card success">
                    <div class="stat-header">
                        <div>
                            <div class="stat-number"><?php echo $total_groups; ?></div>
                            <div class="stat-label">Groupes</div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users-cog"></i>
                        </div>
                    </div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> <?php echo $month_groups; ?> ce mois-ci
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($tables['posts']): ?>
                <div class="stat-card info">
                    <div class="stat-header">
                        <div>
                            <div class="stat-number"><?php echo $total_posts; ?></div>
                            <div class="stat-label">Publications totales</div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-newspaper"></i>
                        </div>
                    </div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> <?php echo $today_posts; ?> aujourd'hui
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($tables['reports']): ?>
                <div class="stat-card danger">
                    <div class="stat-header">
                        <div>
                            <div class="stat-number"><?php echo $pending_reports; ?></div>
                            <div class="stat-label">Signalements en attente</div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-flag"></i>
                        </div>
                    </div>
                    <div class="stat-change">
                        <?php if ($pending_reports > 0): ?>
                            Nécessite votre attention
                        <?php else: ?>
                            Aucun signalement
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Grille de contenu -->
            <div class="content-grid">
                <!-- Section gauche : Activités récentes et graphique -->
                <div>
                    <!-- Activités récentes -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Activités récentes</h3>
                            <?php if (!empty($recent_activities)): ?>
                            <a href="activity_log.php" class="card-link">Voir tout</a>
                            <?php endif; ?>
                        </div>
                        <ul class="activity-list">
                            <?php if (empty($recent_activities)): ?>
                                <li class="activity-item">
                                    <div class="activity-content">
                                        <p><i class="fas fa-info-circle"></i> Aucune activité récente trouvée</p>
                                    </div>
                                </li>
                            <?php else: ?>
                                <?php foreach ($recent_activities as $activity): ?>
                                    <li class="activity-item">
                                        <div class="activity-icon">
                                            <?php
                                            $icons = [
                                                'post' => 'fa-newspaper',
                                                'comment' => 'fa-comment',
                                                'like' => 'fa-heart',
                                                'friend' => 'fa-user-plus',
                                                'group' => 'fa-users',
                                                'message' => 'fa-envelope'
                                            ];
                                            $icon = $icons[$activity['entity_type']] ?? 'fa-bell';
                                            ?>
                                            <i class="fas <?php echo $icon; ?>"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-user"><?php echo htmlspecialchars($activity['username']); ?></div>
                                            <div class="activity-action"><?php echo htmlspecialchars($activity['action']); ?></div>
                                            <div class="activity-time"><?php echo formatRelativeTime($activity['created_at']); ?></div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <!-- Graphique des inscriptions -->
                    <?php if ($tables['users'] && !empty($users_last_week)): ?>
                    <div class="card" style="margin-top: 1.5rem;">
                        <div class="card-header">
                            <h3 class="card-title">Inscriptions sur 7 jours</h3>
                        </div>
                        <div class="chart-container">
                            <canvas id="registrationsChart"></canvas>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Section droite : Top utilisateurs et groupes -->
                <div>
                    <!-- Top utilisateurs -->
                    <?php if (!empty($top_users)): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Top utilisateurs</h3>
                            <a href="users.php" class="card-link">Voir tout</a>
                        </div>
                        <ul class="user-list">
                            <?php foreach ($top_users as $index => $user): ?>
                                <li class="user-item">
                                    <div class="user-avatar-small">
                                        <?php echo strtoupper(substr($user['username'], 0, 2)); ?>
                                    </div>
                                    <div class="user-info-small">
                                        <div class="user-name"><?php echo htmlspecialchars($user['username']); ?></div>
                                        <div class="user-stats">
                                            <?php echo $user['post_count']; ?> publications • 
                                            <?php echo $user['comment_count']; ?> commentaires
                                        </div>
                                    </div>
                                    <div style="font-weight: bold; color: var(--primary);">
                                        #<?php echo $index + 1; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Groupes populaires -->
                    <?php if (!empty($popular_groups)): ?>
                    <div class="card" style="margin-top: 1.5rem;">
                        <div class="card-header">
                            <h3 class="card-title">Groupes populaires</h3>
                            <a href="groups.php" class="card-link">Voir tout</a>
                        </div>
                        <ul class="group-list">
                            <?php foreach ($popular_groups as $group): ?>
                                <li class="group-item">
                                    <div class="group-name">
                                        <i class="fas fa-users" style="color: var(--info); margin-right: 0.5rem;"></i>
                                        <?php echo htmlspecialchars($group['name']); ?>
                                    </div>
                                    <div class="group-meta">
                                        <span><?php echo $group['member_count']; ?> membres</span>
                                        <span><?php echo $group['post_count']; ?> publications</span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Amitiés récentes -->
                    <?php if (!empty($recent_friendships)): ?>
                    <div class="card" style="margin-top: 1.5rem;">
                        <div class="card-header">
                            <h3 class="card-title">Amitiés récentes</h3>
                            <a href="friends.php" class="card-link">Voir tout</a>
                        </div>
                        <ul class="user-list">
                            <?php foreach ($recent_friendships as $friendship): ?>
                                <li class="user-item">
                                    <div class="user-avatar-small">
                                        <i class="fas fa-user-friends"></i>
                                    </div>
                                    <div class="user-info-small">
                                        <div class="user-name">
                                            <?php echo htmlspecialchars($friendship['user1']); ?> et <?php echo htmlspecialchars($friendship['user2']); ?>
                                        </div>
                                        <div class="user-stats">
                                            <?php echo formatRelativeTime($friendship['created_at']); ?>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Actions rapides -->
            <div class="quick-actions">
                <a href="users.php?action=add" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="action-label">Ajouter un utilisateur</div>
                </a>
                
                <?php if ($tables['posts']): ?>
                <a href="posts.php?action=moderate" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="action-label">Modérer les publications</div>
                </a>
                <?php endif; ?>
                
                <?php if ($tables['reports'] && $pending_reports > 0): ?>
                <a href="reports.php" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-flag"></i>
                    </div>
                    <div class="action-label">Gérer les signalements</div>
                </a>
                <?php endif; ?>
                
                <a href="settings.php" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <div class="action-label">Paramètres du site</div>
                </a>
                
                <a href="../index.php" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-external-link-alt"></i>
                    </div>
                    <div class="action-label">Voir le site public</div>
                </a>
                
                <a href="db_fix.php" class="action-btn">
                    <div class="action-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <div class="action-label">Optimiser la base</div>
                </a>
            </div>
        </main>
    </div>
    
    <?php if ($tables['users'] && !empty($users_last_week)): ?>
    <script>
        // Graphique des inscriptions
        const ctx = document.getElementById('registrationsChart');
        if (ctx) {
            // Préparer les données pour le graphique
            const dates = [];
            const counts = [];
            
            <?php 
            // Créer un tableau pour les 7 derniers jours
            $chartData = [];
            for ($i = 6; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-$i days"));
                $chartData[$date] = 0;
            }
            
            // Remplir avec les données réelles
            foreach ($users_last_week as $data) {
                if (isset($chartData[$data['date']])) {
                    $chartData[$data['date']] = $data['count'];
                }
            }
            
            // Convertir pour JavaScript
            $jsDates = json_encode(array_keys($chartData));
            $jsCounts = json_encode(array_values($chartData));
            ?>
            
            const registrationChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo $jsDates; ?>,
                    datasets: [{
                        label: 'Inscriptions',
                        data: <?php echo $jsCounts; ?>,
                        borderColor: '#4a00e0',
                        backgroundColor: 'rgba(74, 0, 224, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }
    </script>
    <?php endif; ?>
    
    <script>
        // Animation des cartes de statistiques
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.boxShadow = '0 8px 15px rgba(0,0,0,0.1)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.boxShadow = '0 4px 6px rgba(0,0,0,0.05)';
            });
        });
    </script>
</body>
</html>